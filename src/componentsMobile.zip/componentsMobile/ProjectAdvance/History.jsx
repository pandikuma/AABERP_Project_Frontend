import React from 'react';
import Filter from '../Images/Filter.png'

const History = () => {
  return (
    <div className="relative w-full h-screen bg-white max-w-[360px] mx-auto flex flex-col scrollbar-none overflow-hidden" style={{ fontFamily: "'Manrope', sans-serif" }}>
      {/* Date and Category Section */}
      <div className="px-4 pt-2">
        <div className="flex items-center justify-between border-b border-[#E0E0E0] pb-2">
          <button className="text-[12px] font-semibold text-black leading-normal">
            #Week
          </button>
          <button className="text-[12px] font-semibold text-black leading-normal">
            Category
          </button>
        </div>
      </div>
      {/* Filter */}
      <div className="flex-shrink-0 px-4 pt-2">
        <div className="flex items-center gap-2 flex-wrap">
          <button type="button" className="flex items-center gap-1 text-[13px] font-semibold text-[#9E9E9E] leading-normal cursor-pointer">
            <img src={Filter} alt="Filter" className="w-[12px] h-[11px]" />
            Filter
          </button>
        </div>
      </div>
      {/* Cards List - Scrollable */}
      <div className="overflow-y-auto no-scrollbar mx-auto scrollbar-none scrollbar-hide px-4 mt-1" style={{ height: 'calc(100vh - 180px - 80px)', maxHeight: 'calc(100vh - 180px - 80px)' }}
        onClick={() => {
          // Handle click outside cards if needed
        }}
      >
        {/* Cards - matching PurchaseOrder structure exactly */}
        {/* Replace this section with your data mapping: {filteredData.map((item, index) => ( */}
        <div
          className="relative overflow-hidden shadow-lg border border-[#E0E0E0] border-opacity-30 bg-[#F8F8F8] rounded-[8px] min-w-[330px]"
          style={{
            height: '95px'
          }}
        >
          {/* Card Content */}
          <div className="flex-1 bg-white rounded-[8px] h-full px-3 py-3 transition-all duration-300 ease-out">
            <div className="flex items-start justify-between gap-2">
              {/* Left: Details */}
              <div className=" min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <button className="text-[12px] font-semibold text-black leading-snug cursor-pointer hover:text-blue-600 hover:underline text-left">
                    {/* ID/Reference Number - e.g., "AD - 09/08/2025 - 34" */}
                  </button>
                </div>
                <p className="text-[12px] font-semibold text-black leading-snug break-words mb-0.5" style={{ wordBreak: 'break-word', overflowWrap: 'break-word' }}>
                  {/* Primary Name - e.g., "Sriram Paints" */}
                </p>
                <p className="text-[11px] font-medium text-[#777777] leading-snug break-words" style={{ wordBreak: 'break-word', overflowWrap: 'break-word' }}>
                  {/* Secondary Name/Location - e.g., "Ramar - Krishnankovil" */}
                </p>
                <span className="text-[11px] font-medium text-[#777777] leading-snug mb-0">
                  {/* Date/Time - e.g., "09/08/2025 • 10:24 AM" */}
                </span>
              </div>
              {/* Right: Payment Status Badge and Amount - Always visible */}
              <div className="flex-shrink-0 flex flex-col items-end gap-1">
                {/* Payment Method Badge */}
                <span className="px-2 py-0.5 rounded-full text-[10px] font-medium flex items-center gap-1">
                  {/* Payment Method - e.g., "Cash", "Net Banking", "G-Pay" */}
                </span>
                {/* Amount */}
                <p className="text-[12px] font-semibold text-black block leading-snug mt-5">
                  {/* Amount - e.g., "₹5,000" */}
                </p>
              </div>
            </div>
          </div>
        </div>
        {/* ))} */}
      </div>
    </div>
  );
};
  export default History;
