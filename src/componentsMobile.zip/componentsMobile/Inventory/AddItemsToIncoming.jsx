import React, { useState, useEffect, useRef } from 'react';
import SelectVendorModal from '../PurchaseOrder/SelectVendorModal';
import { fetchUserModulePermissions } from '../utils/fetchUserModulePermissions';

const AddItemsToIncoming = ({ isOpen, onClose, onAdd, initialData = {}, selectedCategory = '', onCategoryChange, onRefreshItemName, onRefreshModel, onRefreshBrand, onRefreshType }) => {
  const [formData, setFormData] = useState({
    itemName: initialData.itemName || '',
    model: initialData.model || '',
    brand: initialData.brand || '',
    type: initialData.type || '',
    quantity: initialData.quantity || '',
    category: initialData.category || selectedCategory || '',
  });

  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [showItemNameModal, setShowItemNameModal] = useState(false);
  const [showModelModal, setShowModelModal] = useState(false);
  const [showTypeModal, setShowTypeModal] = useState(false);
  const [showBrandModal, setShowBrandModal] = useState(false);
  const [quantityError, setQuantityError] = useState('');

  // Resolve module permissions (Create/Edit/Delete) for mobile create actions.
  const [modulePermissions, setModulePermissions] = useState([]);
  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem('user') || '{}');
      fetchUserModulePermissions(stored?.userRoles || [], 'Inventory')
        .then(setModulePermissions)
        .catch(() => setModulePermissions([]));
    } catch {
      setModulePermissions([]);
    }
  }, []);

  const canCreate = modulePermissions.includes('Create');

  // State for PO item names from API
  const [poItemName, setPoItemName] = useState([]);

  // State for PO model from API
  const [poModel, setPoModel] = useState([]);

  // State for PO brand from API
  const [poBrand, setPoBrand] = useState([]);

  // State for PO type from API
  const [poType, setPoType] = useState([]);

  // State for categories (with IDs) from API
  const [categoryOptions, setCategoryOptions] = useState([]);
  // Category options as strings for dropdown
  const [categoryOptionsStrings, setCategoryOptionsStrings] = useState([]);

  // Store options for each field (could be loaded from localStorage or API)
  const [itemNameOptions, setItemNameOptions] = useState([]);
  const [modelOptions, setModelOptions] = useState([]);
  const [brandOptions, setBrandOptions] = useState([]);
  const [typeOptions, setTypeOptions] = useState([]); // Default types until API loads

  // Track previous initialData to prevent unnecessary form resets
  const previousInitialDataRef = useRef(null);

  // Fetch PO item names from API
  useEffect(() => {
    fetchPoItemName();
  }, []);

  const fetchPoItemName = async () => {
    try {
      const response = await fetch('https://backendaab.in/aabuildersDash/api/po_itemNames/getAll');
      if (response.ok) {
        const data = await response.json();
        setPoItemName(data);
        // Options will be filtered by category in useEffect
      } else {
        console.log('Error fetching tile area names.');
        setPoItemName([]);
      }
    } catch (error) {
      console.error('Error:', error);
      setPoItemName([]);
    }
  };

  // Fetch PO model from API
  useEffect(() => {
    fetchPoModel();
  }, []);

  const fetchPoModel = async () => {
    try {
      const response = await fetch('https://backendaab.in/aabuildersDash/api/po_model/getAll');
      if (response.ok) {
        const data = await response.json();
        setPoModel(data);
        // Options will be filtered by category in useEffect
      } else {
        console.log('Error fetching model names.');
        setPoModel([]);
      }
    } catch (error) {
      console.error('Error:', error);
      setPoModel([]);
    }
  };

  // Fetch PO brand from API
  useEffect(() => {
    fetchPoBrand();
  }, []);

  const fetchPoBrand = async () => {
    try {
      const response = await fetch('https://backendaab.in/aabuildersDash/api/po_brand/getAll');
      if (response.ok) {
        const data = await response.json();
        setPoBrand(data);
        // Options will be filtered by category in useEffect
      } else {
        console.log('Error fetching brand names.');
        setPoBrand([]);
      }
    } catch (error) {
      console.error('Error:', error);
      setPoBrand([]);
    }
  };

  // Fetch PO type from API
  useEffect(() => {
    fetchPoType();
  }, []);

  const fetchPoType = async () => {
    try {
      const response = await fetch('https://backendaab.in/aabuildersDash/api/po_type/getAll');
      if (response.ok) {
        const data = await response.json();
        setPoType(data);
        // Options will be filtered by category in useEffect
      } else {
        console.log('Error fetching type names.');
        setPoType([]);
      }
    } catch (error) {
      console.error('Error:', error);
      setPoType([]);
    }
  };
  useEffect(() => {
    const fetchPoCategory = async () => {
      try {
        const response = await fetch('https://backendaab.in/aabuildersDash/api/po_category/getAll');
        if (response.ok) {
          const data = await response.json();
          const options = (data || []).map(item => ({
            value: item.category || '',
            label: item.category || '',
            id: item.id || null,
          }));
          setCategoryOptions(options);
          // Also set string options for dropdown
          const categoryStrings = options.map(item => item.label || item.value).filter(Boolean);
          setCategoryOptionsStrings(categoryStrings);
        } else {
          console.log('Error fetching categories, using empty list.');
          setCategoryOptions([]);
          setCategoryOptionsStrings([]);
        }
      } catch (error) {
        console.error('Error fetching categories:', error);
        setCategoryOptions([]);
        setCategoryOptionsStrings([]);
      }
    };
    fetchPoCategory();
  }, []);
  // Save options to localStorage when they change
  const saveOptions = (field, newOptions) => {
    localStorage.setItem(`${field}Options`, JSON.stringify(newOptions));
  };
  // Filter options based on selected category
  useEffect(() => {
    const currentCategory = formData.category || selectedCategory || '';
    // Helper function to extract name from item based on field type
    const extractName = (item, nameFields) => {
      if (typeof item === 'string') return item;
      for (const field of nameFields) {
        if (item[field] && typeof item[field] === 'string' && item[field].trim() !== '') {
          return item[field].trim();
        }
      }
      return '';
    };
    // Helper function to filter items by category
    const filterByCategory = (items, nameFields, categoryField = 'category') => {
      if (!Array.isArray(items) || items.length === 0) return [];

      if (!currentCategory) {
        // If no category selected, don't show any options.
        // This enforces: user picks Category first, then sees filtered lists.
        return [];
      }
      // Filter items that match the selected category
      return items
        .filter(item => {
          if (typeof item === 'string') return false; // Skip string items if category filtering
          const itemCategory = item[categoryField] || '';
          return itemCategory.toString().toLowerCase().trim() === currentCategory.toLowerCase().trim();
        })
        .map(item => extractName(item, nameFields))
        .filter(name => name !== '');
    };
    // Filter item names
    if (poItemName && poItemName.length > 0) {
      const filteredItemNames = filterByCategory(poItemName, ['itemName', 'poItemName', 'name', 'item_name'], 'category');
      // Merge with saved names from localStorage
      const savedItemNames = localStorage.getItem('itemNameOptions');
      const savedNames = savedItemNames ? JSON.parse(savedItemNames) : [];
      const allItemNames = [...new Set([...filteredItemNames, ...savedNames])];
      setItemNameOptions(allItemNames);
    } else {
      // If no API data, load from localStorage
      const savedItemNames = localStorage.getItem('itemNameOptions');
      if (savedItemNames) {
        setItemNameOptions(JSON.parse(savedItemNames));
      }
    }
    // Filter models
    if (poModel && poModel.length > 0) {
      const filteredModels = filterByCategory(poModel, ['model', 'poModel', 'modelName', 'name'], 'category');
      const savedModels = localStorage.getItem('modelOptions');
      const savedModelNames = savedModels ? JSON.parse(savedModels) : [];
      const allModels = [...new Set([...filteredModels, ...savedModelNames])];
      setModelOptions(allModels);
    } else {
      const savedModels = localStorage.getItem('modelOptions');
      if (savedModels) {
        setModelOptions(JSON.parse(savedModels));
      }
    }

    // Filter brands
    if (poBrand && poBrand.length > 0) {
      const filteredBrands = filterByCategory(poBrand, ['brand', 'poBrand', 'brandName', 'name'], 'category');
      const savedBrands = localStorage.getItem('brandOptions');
      const savedBrandNames = savedBrands ? JSON.parse(savedBrands) : [];
      const allBrands = [...new Set([...filteredBrands, ...savedBrandNames])];
      setBrandOptions(allBrands);
    } else {
      const savedBrands = localStorage.getItem('brandOptions');
      if (savedBrands) {
        setBrandOptions(JSON.parse(savedBrands));
      }
    }

    // Filter types
    if (poType && poType.length > 0) {
      // Try multiple type field names
      const filteredTypes1 = filterByCategory(poType, ['typeColor'], 'category');
      const filteredTypes2 = filterByCategory(poType, ['type', 'poType', 'typeName', 'name'], 'category');
      const filteredTypesCombined = [...new Set([...filteredTypes1, ...filteredTypes2])];
      const savedTypes = localStorage.getItem('typeOptions');
      const savedTypeNames = savedTypes ? JSON.parse(savedTypes) : [];
      const allTypes = [...new Set([...filteredTypesCombined, ...savedTypeNames])];
      setTypeOptions(allTypes);
    } else {
      const savedTypes = localStorage.getItem('typeOptions');
      if (savedTypes) {
        setTypeOptions(JSON.parse(savedTypes));
      }
    }
  }, [formData.category, selectedCategory, poItemName, poModel, poBrand, poType]);

  // Keep form data in sync when an item is opened for editing
  // Only update when initialData actually changes (not just object reference)
  useEffect(() => {
    // Create a string representation of initialData for comparison
    const currentInitialDataStr = JSON.stringify({
      itemName: initialData?.itemName || '',
      model: initialData?.model || '',
      brand: initialData?.brand || '',
      type: initialData?.type || '',
      quantity: initialData?.quantity || '',
      category: initialData?.category || '',
    });

    const previousInitialDataStr = previousInitialDataRef.current;

    // Only update formData if initialData actually changed
    if (currentInitialDataStr !== previousInitialDataStr) {
      // Check if initialData has any meaningful values (editing mode)
      const hasInitialData = initialData && (
        initialData.itemName ||
        initialData.model ||
        initialData.brand ||
        initialData.type ||
        initialData.quantity ||
        initialData.category
      );

      if (hasInitialData) {
        // Editing mode: update formData with initialData values
        setFormData({
          itemName: initialData.itemName || '',
          model: initialData.model || '',
          brand: initialData.brand || '',
          type: initialData.type || '',
          quantity: initialData.quantity || '',
          category: initialData.category || selectedCategory || '',
        });
      }
      // If no initialData (new item mode), don't reset formData - preserve user's input

      // Update ref to track current initialData
      previousInitialDataRef.current = currentInitialDataStr;
    }

    // Handle category updates separately (only if it actually changed)
    if (selectedCategory) {
      setFormData(prev => {
        // Only update if category actually changed
        if (prev.category !== selectedCategory) {
          return { ...prev, category: selectedCategory };
        }
        return prev;
      });
    }
  }, [
    initialData?.itemName,
    initialData?.model,
    initialData?.brand,
    initialData?.type,
    initialData?.quantity,
    initialData?.category,
    selectedCategory
  ]);

  if (!isOpen) return null;

  const handleQuantityChange = (e) => {
    const value = e.target.value;
    setFormData({ ...formData, quantity: value });

    if (value && isNaN(value)) {
      setQuantityError('Please Enter Valid Quantity');
    } else {
      setQuantityError('');
    }
  };

  const handleCategorySelect = (category) => {
    setFormData({ ...formData, category });
    // Update parent component to persist category
    if (onCategoryChange) {
      onCategoryChange(category);
    }
    setShowCategoryModal(false);
  };

  // Handler for adding new category
  const handleAddNewCategory = async (newCategory) => {
    if (!newCategory || !newCategory.trim()) {
      return;
    }
    if (!canCreate) {
      alert("You don't have permission to create categories.");
      return;
    }
    try {
      const response = await fetch('https://backendaab.in/aabuildersDash/api/po_category/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ category: newCategory.trim() }),
      });
      if (response.ok) {
        console.log('Category saved successfully!');
        // Reload categories from API
        const fetchResponse = await fetch('https://backendaab.in/aabuildersDash/api/po_category/getAll');
        if (fetchResponse.ok) {
          const data = await fetchResponse.json();
          const options = (data || []).map(item => ({
            value: item.category || '',
            label: item.category || '',
            id: item.id || null,
          }));
          setCategoryOptions(options);
          const categoryStrings = options.map(item => item.label || item.value).filter(Boolean);
          setCategoryOptionsStrings(categoryStrings);
        }
        if (!categoryOptionsStrings.includes(newCategory.trim())) {
          setCategoryOptionsStrings([...categoryOptionsStrings, newCategory.trim()]);
        }
      } else {
        console.log('Error saving category.');
        // Still add to local options for immediate use
        if (!categoryOptionsStrings.includes(newCategory.trim())) {
          setCategoryOptionsStrings([...categoryOptionsStrings, newCategory.trim()]);
        }
      }
    } catch (error) {
      console.error('Error:', error);
      console.log('Error saving category.');
      // Still add to local options for immediate use
      if (!categoryOptionsStrings.includes(newCategory.trim())) {
        setCategoryOptionsStrings([...categoryOptionsStrings, newCategory.trim()]);
      }
    }
  };

  // Helper: find an id from an array of objects by matching any of the provided name fields
  const findIdByLabel = (list, value, nameFields = []) => {
    if (!value || !Array.isArray(list)) return null;
    const target = value.toLowerCase().trim();
    const match = list.find(item =>
      nameFields.some(field => (item?.[field] || '').toString().toLowerCase().trim() === target)
    );
    return match ? (match.id || match._id || null) : null;
  };

  const handleFieldSelect = (field, value) => {
    // Check if category is required for this field
    const fieldsRequiringCategory = ['itemName', 'model', 'brand', 'type'];
    const currentCategory = formData.category || selectedCategory;

    if (fieldsRequiringCategory.includes(field) && !currentCategory) {
      const fieldNames = {
        itemName: 'Item Name',
        model: 'Model',
        brand: 'Brand',
        type: 'Type'
      };
      alert(`Please select a category first before selecting ${fieldNames[field]}.`);
      return; // Don't allow selection without category
    }

    setFormData({ ...formData, [field]: value });

    // Add to options if it's a new value
    const optionSetters = {
      itemName: setItemNameOptions,
      model: setModelOptions,
      brand: setBrandOptions,
      type: setTypeOptions,
    };

    const optionArrays = {
      itemName: itemNameOptions,
      model: modelOptions,
      brand: brandOptions,
      type: typeOptions,
    };

    if (!optionArrays[field].includes(value)) {
      const newOptions = [...optionArrays[field], value];
      optionSetters[field](newOptions);
      saveOptions(field, newOptions);
    }
  };

  // API handlers for saving new items (same as InputData.jsx)
  const handleSubmitItemName = async (itemName, selectedCategory) => {
    if (!canCreate) {
      alert("You don't have permission to create item names.");
      return;
    }
    const categoryToUse = selectedCategory || formData.category || '';

    const payload = {
      itemName: itemName,
      category: categoryToUse,
      groupName: '',
      otherPOEntityList: [], // Always empty when saving new item name
    };

    try {
      const response = await fetch('https://backendaab.in/aabuildersDash/api/po_itemNames/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error('Failed to submit data');
      }
      const data = await response.json();
      // Reload item names from API
      await fetchPoItemName();
      // Also refresh parent component's state
      if (onRefreshItemName) {
        await onRefreshItemName();
      }
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  };

  const handleSubmitModel = async (model, selectedCategory) => {
    if (!canCreate) {
      alert("You don't have permission to create models.");
      return;
    }
    const categoryToUse = selectedCategory || formData.category || '';
    const categoryOption = categoryOptions.find(cat =>
      cat.label === categoryToUse || cat.value === categoryToUse
    );
    const categoryId = categoryOption?.value || categoryOption?.id || null;

    const newModelData = {
      model: model,
      category: categoryId,
    };

    try {
      const response = await fetch('https://backendaab.in/aabuildersDash/api/po_model/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newModelData),
      });

      if (response.ok) {
        console.log('Model saved successfully!');
        // Reload models from API
        await fetchPoModel();
        // Also refresh parent component's state
        if (onRefreshModel) {
          await onRefreshModel();
        }
      } else {
        throw new Error('Failed to save model');
      }
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  };

  const handleSubmitBrand = async (brand, selectedCategory) => {
    if (!canCreate) {
      alert("You don't have permission to create brands.");
      return;
    }
    const categoryToUse = selectedCategory || formData.category || '';
    const categoryOption = categoryOptions.find(cat =>
      cat.label === categoryToUse || cat.value === categoryToUse
    );
    const categoryId = categoryOption?.value || categoryOption?.id || null;

    const newBrandData = {
      brand,
      category: categoryId
    };

    try {
      const response = await fetch('https://backendaab.in/aabuildersDash/api/po_brand/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newBrandData),
      });

      if (response.ok) {
        console.log('Brand saved successfully!');
        // Reload brands from API
        await fetchPoBrand();
        // Also refresh parent component's state
        if (onRefreshBrand) {
          await onRefreshBrand();
        }
      } else {
        throw new Error('Failed to save brand');
      }
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  };

  const handleSubmitType = async (typeColor, selectedCategory) => {
    if (!canCreate) {
      alert("You don't have permission to create types.");
      return;
    }
    const categoryToUse = selectedCategory || formData.category || '';
    const categoryOption = categoryOptions.find(cat =>
      cat.label === categoryToUse || cat.value === categoryToUse
    );
    const categoryId = categoryOption?.value || categoryOption?.id || null;

    const newTypeData = {
      typeColor,
      category: categoryId
    };

    try {
      const response = await fetch('https://backendaab.in/aabuildersDash/api/po_type/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newTypeData),
      });

      if (response.ok) {
        console.log('Type saved successfully!');
        // Reload types from API
        await fetchPoType();
        // Also refresh parent component's state
        if (onRefreshType) {
          await onRefreshType();
        }
      } else {
        throw new Error('Failed to save type');
      }
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  };

  const handleFieldAddNew = async (field, value) => {
    // Get current category
    const currentCategory = formData.category || selectedCategory || '';

    // Check if category is required for this field
    const fieldsRequiringCategory = ['itemName', 'model', 'brand', 'type'];
    if (fieldsRequiringCategory.includes(field) && !currentCategory) {
      const fieldNames = {
        itemName: 'Item Name',
        model: 'Model',
        brand: 'Brand',
        type: 'Type'
      };
      alert(`Please select a category first before adding new ${fieldNames[field]}.`);
      return;
    }

    // Map field names to API handlers
    const apiHandlers = {
      itemName: handleSubmitItemName,
      model: handleSubmitModel,
      brand: handleSubmitBrand,
      type: handleSubmitType,
    };

    // Call API handler if it exists for this field
    const apiHandler = apiHandlers[field];
    if (apiHandler) {
      try {
        await apiHandler(value, currentCategory);
        // After successful API call, add to local state
        handleFieldSelect(field, value);
      } catch (error) {
        console.error(`Error saving ${field}:`, error);
        alert(`Failed to save ${field}. Please try again.`);
        // Still add to local state even if API fails (fallback behavior)
        handleFieldSelect(field, value);
      }
    } else {
      // No API handler, just add to local state
      handleFieldSelect(field, value);
    }
  };

  const handleAdd = () => {
    if (!formData.quantity || isNaN(formData.quantity)) {
      setQuantityError('Please Enter Valid Quantity');
      return;
    }

    // Resolve IDs for the selected values
    // Important: when editing, initialData contains the old values.
    // We must resolve IDs from current formData selections first; only fall back to initialData when the user didn't change that field.
    const norm = (v) => (v ?? '').toString().toLowerCase().trim();

    const itemNameChanged = norm(formData.itemName) !== norm(initialData?.itemName);
    const modelChanged = norm(formData.model) !== norm(initialData?.model);
    const brandChanged = norm(formData.brand) !== norm(initialData?.brand);
    const typeChanged = norm(formData.type) !== norm(initialData?.type);
    const categoryChanged = norm(formData.category) !== norm(initialData?.category);

    const resolvedItemIdFromForm =
      formData.itemName
        ? findIdByLabel(poItemName, formData.itemName, ['itemName', 'poItemName', 'name', 'item_name'])
        : null;
    const resolvedModelIdFromForm =
      formData.model
        ? findIdByLabel(poModel, formData.model, ['model', 'poModel', 'modelName', 'name'])
        : null;
    const resolvedBrandIdFromForm =
      formData.brand
        ? findIdByLabel(poBrand, formData.brand, ['brand', 'poBrand', 'brandName', 'name'])
        : null;
    const resolvedTypeIdFromForm =
      formData.type
        ? findIdByLabel(poType, formData.type, ['type', 'poType', 'typeName', 'name', 'typeColor'])
        : null;
    const resolvedCategoryIdFromForm =
      formData.category
        ? findIdByLabel(categoryOptions, formData.category, ['label', 'name', 'categoryName', 'category'])
        : null;

    const resolvedItemId =
      resolvedItemIdFromForm ?? (!itemNameChanged ? (initialData?.itemId ?? null) : null);
    const resolvedModelId =
      resolvedModelIdFromForm ?? (!modelChanged ? (initialData?.modelId ?? null) : null);
    const resolvedBrandId =
      resolvedBrandIdFromForm ?? (!brandChanged ? (initialData?.brandId ?? null) : null);
    const resolvedTypeId =
      resolvedTypeIdFromForm ?? (!typeChanged ? (initialData?.typeId ?? null) : null);

    let resolvedCategoryId =
      resolvedCategoryIdFromForm ?? (!categoryChanged ? (initialData?.categoryId ?? null) : null);
    if (!resolvedCategoryId && categoryOptions.length > 0) {
      resolvedCategoryId = categoryOptions[0].id || null;
    }

    const isEditMode =
      Boolean(initialData) &&
      (initialData.itemId !== undefined || initialData.itemName !== undefined);

    onAdd({
      ...formData,
      itemId: resolvedItemId || null,
      modelId: resolvedModelId || null,
      brandId: resolvedBrandId || null,
      typeId: resolvedTypeId || null,
      categoryId: resolvedCategoryId || null,
    });
    // Clear all fields after adding, but preserve category
    const categoryToPreserve = formData.category || selectedCategory;
    setFormData({
      itemName: '',
      model: '',
      brand: '',
      type: '',
      quantity: '',
      category: categoryToPreserve, // Preserve current selection
    });
    setQuantityError('');
    // Don't close the popup - let user close manually or continue adding items
  };

  const handleBackdropClick = (e) => {
    // Close modal if clicking on the backdrop (not on the modal content)
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const SelectField = ({ label, required, value, placeholder, onOpen }) => {
    return (
      <div className="relative">
        <p className="text-[13px] font-medium text-black mb-0.5 leading-normal">
          {label}{required ? <span className="text-[#eb2f8e]">*</span> : null}
        </p>
        <div
          role="button"
          tabIndex={0}
          onClick={onOpen}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              onOpen();
            }
          }}
          className="w-full h-[32px] border border-[rgba(0,0,0,0.16)] rounded pl-[12px] pr-[32px] text-[12px] font-medium bg-white flex items-center cursor-pointer"
          style={{
            boxSizing: 'border-box',
            color: value ? '#000' : '#9E9E9E'
          }}
        >
          <span className="truncate">{value || placeholder}</span>
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
            <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M1 1L6 6L11 1" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-[100] flex items-end justify-center"
        style={{ fontFamily: "'Manrope', sans-serif" }}
        onClick={handleBackdropClick}
      >
        <div
          className="bg-white w-full h-[370px] rounded-tl-[16px] rounded-tr-[16px] relative z-50"
          onClick={(e) => e.stopPropagation()}
          style={{
            // Keep the sheet anchored even when mobile keyboard opens (avoid 100vh shrink jumps)
            transform: 'translateZ(0)'
          }}
        >
          {/* Header with Title and Category */}
          <div className="flex items-center justify-between px-[24px] pt-[20px] mb-3">
            {/* Title on the left */}
            <p className="text-[16px] font-medium text-black leading-normal">
              Add Items
            </p>
            {/* Category label on the right */}
            <button
              onClick={() => setShowCategoryModal(true)}
              className="text-[16px] font-medium text-black decoration-solid"
              style={{ textUnderlinePosition: 'from-font' }}
            >
              {(formData.category || selectedCategory) || 'Category'}
            </button>
          </div>
          {/* Form fields - All fields are enabled and can be used independently of category selection */}
          <div className="px-[24px] ">
            {/* Item Name - Can be selected without category */}
            <div className="space-y-[6px]">
              <SelectField
                label="Item Name"
                required={true}
                value={formData.itemName}
                placeholder={formData.category || selectedCategory ? "12A Switch" : "Select Category first"}
                onOpen={() => {
                  if (!(formData.category || selectedCategory)) {
                    setShowCategoryModal(true);
                    return;
                  }
                  setShowItemNameModal(true);
                }}
              />
              {/* Model - Can be selected without category */}
              <SelectField
                label="Model"
                required={true}
                value={formData.model}
                placeholder={formData.category || selectedCategory ? "Natural Cream" : "Select Category first"}
                onOpen={() => {
                  if (!(formData.category || selectedCategory)) {
                    setShowCategoryModal(true);
                    return;
                  }
                  setShowModelModal(true);
                }}
              />
              {/* Brand - Can be selected without category */}
              <div className="w-full relative">
                <SelectField
                  label="Type"
                  required={true}
                  value={formData.type}
                  placeholder={formData.category || selectedCategory ? "Flip Type" : "Select Category first"}
                  onOpen={() => {
                    if (!(formData.category || selectedCategory)) {
                      setShowCategoryModal(true);
                      return;
                    }
                    setShowTypeModal(true);
                  }}
                />
              </div>
              {/* Type and Quantity row */}
              <div className="flex gap-[12px]">
                {/* Type - Can be selected without category */}
                <div className="w-full relative">
                  <SelectField
                    label="Brand"
                    required={true}
                    value={formData.brand}
                    placeholder={formData.category || selectedCategory ? "Kundan" : "Select Category first"}
                    onOpen={() => {
                      if (!(formData.category || selectedCategory)) {
                        setShowCategoryModal(true);
                        return;
                      }
                      setShowBrandModal(true);
                    }}
                  />
                </div>
                {/* Quantity */}
                <div className="w-[100px] relative">
                  <p className="text-[13px] font-medium text-black mb-0.5 leading-normal">
                    Quantity<span className="text-[#eb2f8e]">*</span>
                  </p>
                  <div className="relative">
                    <input
                      type="text"
                      value={formData.quantity}
                      onChange={handleQuantityChange}
                      className={`w-[100px] h-[32px] border rounded px-[12px] text-[12px] font-medium bg-white focus:outline-none ${quantityError ? 'border-[#e06256] text-black' : 'border-[#d6d6d6] text-black'
                        }`}
                      style={{ fontFamily: "'Manrope', sans-serif" }}
                      placeholder="Enter"
                    />
                    {quantityError && (
                      <p className="absolute -bottom-5 left-0 text-[10px] text-[#f57368] leading-normal">
                        {quantityError}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
            {/* Buttons */}
            <div className="mt-5 mb-3 flex gap-[16px]">
              <button
                onClick={onClose}
                className="w-full h-[40px] border border-[#949494] rounded-[8px] text-[14px] font-bold text-[#363636] bg-white leading-normal"
              >
                Cancel
              </button>
              <button
                onClick={handleAdd}
                className="w-full h-[40px] bg-black border border-[#f4ede2] rounded-[8px] text-[14px] font-bold text-white leading-normal"
              >
                Add
              </button>
            </div>
          </div>
        </div>
      </div>

      <SelectVendorModal
        isOpen={showCategoryModal}
        onClose={() => setShowCategoryModal(false)}
        onSelect={(value) => {
          handleCategorySelect(value);
          setShowCategoryModal(false);
        }}
        selectedValue={formData.category || selectedCategory}
        options={categoryOptionsStrings}
        fieldName="Category"
        onAddNew={handleAddNewCategory}
      />

      <SelectVendorModal
        isOpen={showItemNameModal}
        onClose={() => setShowItemNameModal(false)}
        onSelect={(value) => {
          handleFieldSelect('itemName', value);
          setShowItemNameModal(false);
        }}
        selectedValue={formData.itemName}
        options={itemNameOptions}
        fieldName="Item Name"
        onAddNew={(value) => handleFieldAddNew('itemName', value)}
      />

      <SelectVendorModal
        isOpen={showModelModal}
        onClose={() => setShowModelModal(false)}
        onSelect={(value) => {
          handleFieldSelect('model', value);
          setShowModelModal(false);
        }}
        selectedValue={formData.model}
        options={modelOptions}
        fieldName="Model"
        onAddNew={(value) => handleFieldAddNew('model', value)}
      />

      <SelectVendorModal
        isOpen={showTypeModal}
        onClose={() => setShowTypeModal(false)}
        onSelect={(value) => {
          handleFieldSelect('type', value);
          setShowTypeModal(false);
        }}
        selectedValue={formData.type}
        options={typeOptions}
        fieldName="Type"
        onAddNew={(value) => handleFieldAddNew('type', value)}
      />

      <SelectVendorModal
        isOpen={showBrandModal}
        onClose={() => setShowBrandModal(false)}
        onSelect={(value) => {
          handleFieldSelect('brand', value);
          setShowBrandModal(false);
        }}
        selectedValue={formData.brand}
        options={brandOptions}
        fieldName="Brand"
        onAddNew={(value) => handleFieldAddNew('brand', value)}
      />
    </>
  );
};

export default AddItemsToIncoming;

