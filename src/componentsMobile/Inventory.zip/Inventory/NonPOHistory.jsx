import React, { useState, useEffect, useRef } from 'react';
import SelectVendorModal from '../PurchaseOrder/SelectVendorModal';
import Edit from '../Images/edit1.png';
import Delete from '../Images/delete.png';

const NonPOHistory = ({ onTabChange }) => {
  const [nonPORecords, setNonPORecords] = useState([]);
  const [filteredRecords, setFilteredRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [vendorData, setVendorData] = useState([]);
  const [siteData, setSiteData] = useState([]);
  const [showFilterSheet, setShowFilterSheet] = useState(false);
  const [filterData, setFilterData] = useState({
    projectName: '',
    stockingLocation: '',
    date: '',
    entryNo: '',
    category: ''
  });
  const [projectNameOpen, setProjectNameOpen] = useState(false);
  const [stockingLocationOpen, setStockingLocationOpen] = useState(false);
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [categoryOptions, setCategoryOptions] = useState([]);
  const [categoryOptionsStrings, setCategoryOptionsStrings] = useState([]);
  const [projectNameSearch, setProjectNameSearch] = useState('');
  const [stockingLocationSearch, setStockingLocationSearch] = useState('');
  const [expandedItemId, setExpandedItemId] = useState(null);
  const [swipeStates, setSwipeStates] = useState({});
  const expandedItemIdRef = useRef(expandedItemId);
  const cardRefs = useRef({});

  // Fetch vendor data
  useEffect(() => {
    const fetchVendors = async () => {
      try {
        const response = await fetch('https://backendaab.in/aabuilderDash/api/vendor_Names/getAll');
        if (response.ok) {
          const data = await response.json();
          setVendorData(data);
        }
      } catch (error) {
        console.error('Error fetching vendors:', error);
      }
    };
    fetchVendors();
  }, []);

  // Fetch site data
  useEffect(() => {
    const fetchSites = async () => {
      try {
        const response = await fetch("https://backendaab.in/aabuilderDash/api/project_Names/getAll", {
          method: "GET",
          credentials: "include",
          headers: {
            "Content-Type": "application/json"
          }
        });
        if (response.ok) {
          const data = await response.json();
          setSiteData(data);
        }
      } catch (error) {
        console.error('Error fetching sites:', error);
      }
    };
    fetchSites();
  }, []);

  // Fetch category options from API
  useEffect(() => {
    const fetchPoCategory = async () => {
      try {
        const response = await fetch('https://backendaab.in/aabuildersDash/api/po_category/getAll');
        if (response.ok) {
          const data = await response.json();
          const options = (data || []).map(item => ({
            value: item.category || '',
            label: item.category || '',
            id: item.id || null,
          }));
          setCategoryOptions(options);
          // Also set string options for dropdown
          const categoryStrings = options.map(item => item.label || item.value).filter(Boolean);
          setCategoryOptionsStrings(categoryStrings);
        } else {
          console.log('Error fetching categories, using empty list.');
          setCategoryOptions([]);
          setCategoryOptionsStrings([]);
        }
      } catch (error) {
        console.error('Error fetching categories:', error);
        setCategoryOptions([]);
        setCategoryOptionsStrings([]);
      }
    };
    fetchPoCategory();
  }, []);

  // Fetch and process non-PO incoming records
  useEffect(() => {
    const fetchNonPORecords = async () => {
      try {
        setLoading(true);
        const response = await fetch('https://backendaab.in/aabuildersDash/api/inventory/getIncoming', {
          method: 'GET',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json'
          }
        });

        if (!response.ok) {
          throw new Error('Network response was not ok');
        }

        const inventoryData = await response.json();

        // Filter for non-PO records (no purchase_no or purchase_no is 'NO_PO') and exclude deleted
        const nonPOItems = inventoryData.filter(item => {
          const isDeleted = item.delete_status || item.deleteStatus;
          const purchaseNo = item.purchase_no || item.purchaseNo || item.purchase_number || '';
          // Check if purchase_no is empty/null or equals 'NO_PO' (case-insensitive)
          const isNonPO = !purchaseNo ||
            String(purchaseNo).trim() === '' ||
            String(purchaseNo).toUpperCase() === 'NO_PO';
          return !isDeleted && isNonPO;
        });

        // Process each non-PO record
        const processedRecords = nonPOItems.map((record) => {
          // Get vendor name
          const vendorId = record.vendor_id || record.vendorId;
          const vendor = vendorData.find(v => v.id === vendorId);
          const vendorName = vendor ? vendor.vendorName : 'Unknown Vendor';

          // Get stocking location name
          const stockingLocationId = record.stocking_location_id || record.stockingLocationId;
          const site = siteData.find(s => s.id === stockingLocationId);
          const stockingLocation = site ? site.siteName : 'Unknown Location';

          // Calculate total items and quantity
          const inventoryItems = record.inventoryItems || record.inventory_items || [];
          const numberOfItems = inventoryItems.length;
          const totalQuantity = inventoryItems.reduce((sum, item) => {
            return sum + Math.abs(item.quantity || 0);
          }, 0);
          const totalAmount = inventoryItems.reduce((sum, item) => {
            return sum + Math.abs(item.amount || 0);
          }, 0);

          // Format date
          const itemDate = record.date || record.created_at || record.createdAt;
          const dateObj = new Date(itemDate);
          const formattedDate = dateObj.toLocaleDateString('en-GB', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
          });
          const formattedTime = dateObj.toLocaleTimeString('en-GB', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
          });

          // Get entry number
          const entryNumber = record.eno || record.ENO || record.entry_number || record.entryNumber || record.id || '';

          return {
            ...record,
            entryNumber,
            vendorName,
            stockingLocation,
            numberOfItems,
            totalQuantity,
            totalAmount,
            formattedDate,
            formattedTime,
            isToday: formattedDate === new Date().toLocaleDateString('en-GB', {
              day: '2-digit',
              month: '2-digit',
              year: 'numeric'
            })
          };
        });

        // Sort by date (newest first)
        processedRecords.sort((a, b) => {
          const dateA = new Date(a.date || a.created_at || a.createdAt);
          const dateB = new Date(b.date || b.created_at || b.createdAt);
          return dateB - dateA;
        });

        setNonPORecords(processedRecords);
      } catch (error) {
        console.error('Error fetching non-PO records:', error);
        setNonPORecords([]);
      } finally {
        setLoading(false);
      }
    };

    if (vendorData.length > 0 && siteData.length > 0) {
      fetchNonPORecords();
    }
  }, [vendorData, siteData]);

  // Filter records based on search query
  useEffect(() => {
    let filtered = nonPORecords;

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(record => {
        return (
          record.vendorName?.toLowerCase().includes(query) ||
          record.stockingLocation?.toLowerCase().includes(query) ||
          String(record.entryNumber)?.includes(query)
        );
      });
    }

    setFilteredRecords(filtered);
  }, [nonPORecords, searchQuery]);

  // Close dropdowns when filter sheet closes
  useEffect(() => {
    if (!showFilterSheet) {
      setProjectNameOpen(false);
      setStockingLocationOpen(false);
      setShowCategoryModal(false);
      setProjectNameSearch('');
      setStockingLocationSearch('');
    }
  }, [showFilterSheet]);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!showFilterSheet) return;

      const target = event.target;
      const isProjectNameDropdown = target.closest('[data-dropdown="projectName"]');
      const isStockingLocationDropdown = target.closest('[data-dropdown="stockingLocation"]');

      if (projectNameOpen && !isProjectNameDropdown) {
        setProjectNameOpen(false);
      }
      if (stockingLocationOpen && !isStockingLocationDropdown) {
        setStockingLocationOpen(false);
      }
    };

    if (showFilterSheet) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }
  }, [projectNameOpen, stockingLocationOpen, showFilterSheet]);

  // Update ref when expandedItemId changes
  useEffect(() => {
    expandedItemIdRef.current = expandedItemId;
  }, [expandedItemId]);

  // Swipe handlers
  const minSwipeDistance = 50;

  const handleTouchStart = (e, itemId) => {
    const touch = e.touches ? e.touches[0] : { clientX: e.clientX };
    setSwipeStates(prev => ({
      ...prev,
      [itemId]: {
        startX: touch.clientX,
        currentX: touch.clientX,
        isSwiping: false
      }
    }));
  };

  const handleTouchMove = (e, itemId) => {
    const touch = e.touches ? e.touches[0] : { clientX: e.clientX };
    const state = swipeStates[itemId];
    if (!state) return;
    const deltaX = touch.clientX - state.startX;
    const isExpanded = expandedItemIdRef.current === itemId;
    if (deltaX < 0 || (isExpanded && deltaX > 0)) {
      setSwipeStates(prev => ({
        ...prev,
        [itemId]: {
          ...prev[itemId],
          currentX: touch.clientX,
          isSwiping: true
        }
      }));
    }
  };

  const handleTouchEnd = (itemId) => {
    const state = swipeStates[itemId];
    if (!state) return;
    const deltaX = state.currentX - state.startX;
    const absDeltaX = Math.abs(deltaX);
    if (absDeltaX >= minSwipeDistance) {
      if (deltaX < 0) {
        setExpandedItemId(itemId);
      } else {
        setExpandedItemId(null);
      }
    }
    setSwipeStates(prev => {
      const newState = { ...prev };
      delete newState[itemId];
      return newState;
    });
  };

  // Set up non-passive touch event listeners
  useEffect(() => {
    const cleanupFunctions = [];

    Object.keys(cardRefs.current).forEach(itemId => {
      const cardElement = cardRefs.current[itemId];
      if (!cardElement) return;

      const touchMoveHandler = (e) => {
        const state = swipeStates[itemId];
        if (!state) return;
        const touch = e.touches[0];
        const deltaX = touch.clientX - state.startX;
        const isExpanded = expandedItemIdRef.current === itemId;
        if (deltaX < 0 || (isExpanded && deltaX > 0)) {
          e.preventDefault();
        }
      };

      cardElement.addEventListener('touchmove', touchMoveHandler, { passive: false });

      cleanupFunctions.push(() => {
        cardElement.removeEventListener('touchmove', touchMoveHandler);
      });
    });

    return () => {
      cleanupFunctions.forEach(cleanup => cleanup());
    };
  }, [filteredRecords, swipeStates]);

  // Global mouse handlers for desktop support
  useEffect(() => {
    if (filteredRecords.length === 0) return;

    const globalMouseMoveHandler = (e) => {
      setSwipeStates(prev => {
        let hasChanges = false;
        const newState = { ...prev };

        filteredRecords.forEach(record => {
          const state = prev[record.id || record._id];
          if (!state) return;
          const deltaX = e.clientX - state.startX;
          const isExpanded = expandedItemIdRef.current === (record.id || record._id);
          if (deltaX < 0 || (isExpanded && deltaX > 0)) {
            newState[record.id || record._id] = {
              ...state,
              currentX: e.clientX,
              isSwiping: true
            };
            hasChanges = true;
          }
        });

        return hasChanges ? newState : prev;
      });
    };

    const globalMouseUpHandler = () => {
      setSwipeStates(prev => {
        let hasChanges = false;
        const newState = { ...prev };

        filteredRecords.forEach(record => {
          const state = prev[record.id || record._id];
          if (!state) return;
          const deltaX = state.currentX - state.startX;
          const absDeltaX = Math.abs(deltaX);
          if (absDeltaX >= minSwipeDistance) {
            if (deltaX < 0) {
              setExpandedItemId(record.id || record._id);
            } else {
              setExpandedItemId(null);
            }
          } else {
            if (expandedItemIdRef.current === (record.id || record._id)) {
              setExpandedItemId(null);
            }
          }
          delete newState[record.id || record._id];
          hasChanges = true;
        });

        return hasChanges ? newState : prev;
      });
    };

    document.addEventListener('mousemove', globalMouseMoveHandler);
    document.addEventListener('mouseup', globalMouseUpHandler);

    return () => {
      document.removeEventListener('mousemove', globalMouseMoveHandler);
      document.removeEventListener('mouseup', globalMouseUpHandler);
    };
  }, [filteredRecords]);

  // Handle edit
  const handleEdit = async (record) => {
    try {
      let inventoryData = record;

      // Check if inventoryItems are present
      const hasInventoryItems = inventoryData?.inventoryItems || inventoryData?.inventory_items;

      // If inventoryItems are missing, try to fetch them from the backend
      if (!hasInventoryItems || (Array.isArray(inventoryData?.inventoryItems) && inventoryData.inventoryItems.length === 0) ||
        (Array.isArray(inventoryData?.inventory_items) && inventoryData.inventory_items.length === 0)) {
        if (inventoryData?.id) {
          try {
            const response = await fetch(`https://backendaab.in/aabuildersDash/api/inventory/edit_with_history/${inventoryData.id}`, {
              method: 'GET',
              credentials: 'include',
              headers: {
                'Content-Type': 'application/json'
              }
            });

            if (response.ok) {
              const detailedData = await response.json();
              if (detailedData.inventoryItems || detailedData.inventory_items) {
                const items = detailedData.inventoryItems || detailedData.inventory_items;
                inventoryData = {
                  ...inventoryData,
                  inventoryItems: items,
                  inventory_items: items
                };
              }
            }
          } catch (fetchError) {
            console.error('Error fetching inventory details:', fetchError);
          }
        }
      }

      // Ensure inventoryItems are explicitly set
      if (inventoryData?.inventoryItems || inventoryData?.inventory_items) {
        const items = inventoryData.inventoryItems || inventoryData.inventory_items;
        inventoryData = {
          ...inventoryData,
          inventoryItems: items,
          inventory_items: items
        };
      }

      // Mark as edit mode
      inventoryData.isEditMode = true;

      // Store inventory item data in localStorage
      if (inventoryData) {
        localStorage.setItem('editingInventory', JSON.stringify(inventoryData));
      }
      // Dispatch custom event for incoming component to listen
      window.dispatchEvent(new CustomEvent('editInventory', { detail: inventoryData }));
      // Navigate to incoming tab for editing
      if (onTabChange) {
        onTabChange('incoming');
      }
      setExpandedItemId(null);
    } catch (error) {
      console.error('Error in handleEdit:', error);
      const inventoryData = record;
      inventoryData.isEditMode = true;
      localStorage.setItem('editingInventory', JSON.stringify(inventoryData));
      window.dispatchEvent(new CustomEvent('editInventory', { detail: inventoryData }));
      if (onTabChange) {
        onTabChange('incoming');
      }
      setExpandedItemId(null);
    }
  };

  // Handle delete
  const handleDelete = async (recordId) => {
    if (!window.confirm('Are you sure you want to delete this record?')) {
      setExpandedItemId(null);
      return;
    }

    try {
      const response = await fetch(`https://backendaab.in/aabuildersDash/api/inventory/delete/${recordId}`, {
        method: 'PUT',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        // Remove from local state
        setNonPORecords(prev => prev.filter(record => (record.id || record._id) !== recordId));
        alert('Record deleted successfully');
      } else {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to delete record');
      }
    } catch (error) {
      console.error('Error deleting record:', error);
      alert(`Error deleting record: ${error.message}`);
    }
    setExpandedItemId(null);
  };

  // Handler for adding new category
  const handleAddNewCategory = async (newCategory) => {
    if (!newCategory || !newCategory.trim()) {
      return;
    }
    try {
      const response = await fetch('https://backendaab.in/aabuildersDash/api/po_category/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ category: newCategory.trim() }),
      });
      if (response.ok) {
        console.log('Category saved successfully!');
        // Reload categories from API
        const fetchResponse = await fetch('https://backendaab.in/aabuildersDash/api/po_category/getAll');
        if (fetchResponse.ok) {
          const data = await fetchResponse.json();
          const options = (data || []).map(item => ({
            value: item.category || '',
            label: item.category || '',
            id: item.id || null,
          }));
          setCategoryOptions(options);
          const categoryStrings = options.map(item => item.label || item.value).filter(Boolean);
          setCategoryOptionsStrings(categoryStrings);
        }
        if (!categoryOptionsStrings.includes(newCategory.trim())) {
          setCategoryOptionsStrings([...categoryOptionsStrings, newCategory.trim()]);
        }
      } else {
        console.log('Error saving category.');
        // Still add to local options for immediate use
        if (!categoryOptionsStrings.includes(newCategory.trim())) {
          setCategoryOptionsStrings([...categoryOptionsStrings, newCategory.trim()]);
        }
      }
    } catch (error) {
      console.error('Error:', error);
      console.log('Error saving category.');
      // Still add to local options for immediate use
      if (!categoryOptionsStrings.includes(newCategory.trim())) {
        setCategoryOptionsStrings([...categoryOptionsStrings, newCategory.trim()]);
      }
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-90px-80px)] overflow-hidden bg-white">
      {/* Search Bar */}
      <div className="flex-shrink-0 px-4 pt-3 pb-2">
        <div className="relative">
          <input
            type="text"
            placeholder="Search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-[40px] pl-10 pr-4 border border-gray-300 rounded-full text-[14px] bg-white focus:outline-none focus:border-gray-400"
          />
          <svg
            className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
      </div>

      {/* Filter Button */}
      <div className="flex-shrink-0 px-4 pb-3">
        <div className="flex items-center gap-2 min-w-0">
          <button
            onClick={() => setShowFilterSheet(true)}
            type="button"
            className="flex items-center gap-2 text-[14px] font-medium text-gray-700 flex-shrink-0"
          >
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
              {/* Top horizontal line */}
              <line x1="2" y1="5" x2="16" y2="5" stroke={(filterData.projectName || filterData.stockingLocation || filterData.date || filterData.entryNo || filterData.category) ? "#9E9E9E" : "#9E9E9E"} strokeWidth="1.5" strokeLinecap="round" />
              {/* Top vertical line intersecting center */}
              <line x1="9" y1="3" x2="9" y2="7" stroke={(filterData.projectName || filterData.stockingLocation || filterData.date || filterData.entryNo || filterData.category) ? "#9E9E9E" : "#9E9E9E"} strokeWidth="1.5" strokeLinecap="round" />
              {/* Top arrows pointing left and right */}
              <path d="M7 4L9 5L11 4" stroke={(filterData.projectName || filterData.stockingLocation || filterData.date || filterData.entryNo || filterData.category) ? "#9E9E9E" : "#9E9E9E"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              <path d="M7 6L9 5L11 6" stroke={(filterData.projectName || filterData.stockingLocation || filterData.date || filterData.entryNo || filterData.category) ? "#9E9E9E" : "#9E9E9E"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              {/* Bottom horizontal line */}
              <line x1="2" y1="13" x2="16" y2="13" stroke={(filterData.projectName || filterData.stockingLocation || filterData.date || filterData.entryNo || filterData.category) ? "#9E9E9E" : "#9E9E9E"} strokeWidth="1.5" strokeLinecap="round" />
              {/* Bottom vertical line intersecting center */}
              <line x1="9" y1="11" x2="9" y2="15" stroke={(filterData.projectName || filterData.stockingLocation || filterData.date || filterData.entryNo || filterData.category) ? "#9E9E9E" : "#9E9E9E"} strokeWidth="1.5" strokeLinecap="round" />
              {/* Bottom arrows pointing left and right */}
              <path d="M7 12L9 13L11 12" stroke={(filterData.projectName || filterData.stockingLocation || filterData.date || filterData.entryNo || filterData.category) ? "#9E9E9E" : "#9E9E9E"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              <path d="M7 14L9 13L11 14" stroke={(filterData.projectName || filterData.stockingLocation || filterData.date || filterData.entryNo || filterData.category) ? "#9E9E9E" : "#9E9E9E"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            </svg>
            {!(filterData.projectName || filterData.stockingLocation || filterData.date || filterData.entryNo || filterData.category) && (
              <span className="text-[12px] font-medium text-black">Filter</span>
            )}
          </button>
          {/* Active Filter Tags - Next to Filter button */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar scrollbar-none min-w-0 scrollbar-hide" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
            {(filterData.projectName || filterData.stockingLocation || filterData.date || filterData.entryNo || filterData.category) && (
              <div className="flex items-center gap-2 flex-nowrap">
                {filterData.projectName && (
                  <div className="flex items-center gap-1.5 border px-2.5 py-1.5 rounded-full flex-shrink-0">
                    <span className="text-[11px] font-medium text-black">Project</span>
                    <button
                      onClick={() => setFilterData({ ...filterData, projectName: '' })}
                      className="w-4 h-4 flex items-center justify-center hover:bg-gray-300 rounded-full transition-colors"
                    >
                      <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7 3L3 7M3 3L7 7" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </button>
                  </div>
                )}
                {filterData.stockingLocation && (
                  <div className="flex items-center gap-1.5 border px-2.5 py-1.5 rounded-full flex-shrink-0">
                    <span className="text-[11px] font-medium text-black">Location</span>
                    <button
                      onClick={() => setFilterData({ ...filterData, stockingLocation: '' })}
                      className="w-4 h-4 flex items-center justify-center hover:bg-gray-300 rounded-full transition-colors"
                    >
                      <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7 3L3 7M3 3L7 7" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </button>
                  </div>
                )}
                {filterData.date && (
                  <div className="flex items-center gap-1.5 border px-2.5 py-1.5 rounded-full flex-shrink-0">
                    <span className="text-[11px] font-medium text-black">Date</span>
                    <button
                      onClick={() => setFilterData({ ...filterData, date: '' })}
                      className="w-4 h-4 flex items-center justify-center hover:bg-gray-300 rounded-full transition-colors"
                    >
                      <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7 3L3 7M3 3L7 7" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </button>
                  </div>
                )}
                {filterData.entryNo && (
                  <div className="flex items-center gap-1.5 border px-2.5 py-1.5 rounded-full flex-shrink-0">
                    <span className="text-[11px] font-medium text-black">Entry.No</span>
                    <button
                      onClick={() => setFilterData({ ...filterData, entryNo: '' })}
                      className="w-4 h-4 flex items-center justify-center hover:bg-gray-300 rounded-full transition-colors"
                    >
                      <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7 3L3 7M3 3L7 7" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </button>
                  </div>
                )}
                {filterData.category && (
                  <div className="flex items-center gap-1.5 border px-2.5 py-1.5 rounded-full flex-shrink-0">
                    <span className="text-[11px] font-medium text-black">Category</span>
                    <button
                      onClick={() => setFilterData({ ...filterData, category: '' })}
                      className="w-4 h-4 flex items-center justify-center hover:bg-gray-300 rounded-full transition-colors"
                    >
                      <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7 3L3 7M3 3L7 7" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Records List */}
      <div className="flex-1 overflow-y-auto px-4 scrollbar-hide no-scrollbar scrollbar-none">
        {loading ? (
          <div className="flex items-center justify-center py-">
            <p className="text-gray-500">Loading...</p>
          </div>
        ) : filteredRecords.length === 0 ? (
          <div className="flex items-center justify-center py-">
            <p className="text-gray-500">No non-PO records found</p>
          </div>
        ) : (
          <div>
            {filteredRecords.map((record) => {
              const recordId = record.id || record._id;
              const isExpanded = expandedItemId === recordId;
              const swipeState = swipeStates[recordId];
              let swipeOffset = 0;
              if (swipeState && swipeState.isSwiping) {
                const deltaX = swipeState.currentX - swipeState.startX;
                if (deltaX < 0) {
                  swipeOffset = Math.max(-110, Math.min(0, deltaX));
                } else {
                  swipeOffset = Math.min(0, Math.max(0, deltaX));
                }
              } else if (isExpanded) {
                swipeOffset = -110;
              } else {
                swipeOffset = 0;
              }

              return (
                <div key={recordId} className="relative overflow-hidden shadow-lg border border-[#E0E0E0] border-opacity-30 bg-gray-50 rounded-[8px] h-[100px]">
                  {/* History Card */}
                  <div
                    ref={(el) => {
                      if (el) {
                        cardRefs.current[recordId] = el;
                      } else {
                        delete cardRefs.current[recordId];
                      }
                    }}
                    className="flex-1 bg-white rounded-[8px] h-full px-3 py-3 transition-all duration-300 ease-out"
                    style={{
                      transform: `translateX(${swipeOffset}px)`,
                      touchAction: 'pan-y',
                      userSelect: (swipeState && swipeState.isSwiping) ? 'none' : 'auto',
                      WebkitUserSelect: (swipeState && swipeState.isSwiping) ? 'none' : 'auto',
                      MozUserSelect: (swipeState && swipeState.isSwiping) ? 'none' : 'auto',
                      msUserSelect: (swipeState && swipeState.isSwiping) ? 'none' : 'auto'
                    }}
                    onTouchStart={(e) => handleTouchStart(e, recordId)}
                    onTouchMove={(e) => handleTouchMove(e, recordId)}
                    onTouchEnd={() => handleTouchEnd(recordId)}
                    onMouseDown={(e) => handleTouchStart(e, recordId)}
                  >
                    <div className=" justify-between items-start">
                      {/* Left Side */}
                      <div className="flex items-center justify-between mb-1">
                        <div>
                          <span className="text-[12px] font-semibold text-black">
                            #{record.entryNumber}
                          </span>
                          <span className="text-[12px] font-semibold text-black">
                            , {record.vendorName}
                          </span>
                        </div>
                        <p className="text-[12px] text-gray-600 mb-1">
                          No. of Items - {record.numberOfItems}
                        </p>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-[12px] text-gray-600 mb-1">
                          {record.stockingLocation}
                        </p>
                        <p className="text-[12px] font-semibold text-[#BF9853]">
                          Quantity - {record.totalQuantity}
                        </p>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-[12px] text-gray-500">
                          {record.created_date_time && new Date(record.created_date_time).toLocaleString('en-GB', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                            hour12: true
                          })}
                        </p>
                        <p className="text-[12px] font-semibold text-black">
                          ₹{record.totalAmount?.toLocaleString('en-IN') || '0'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons - Behind the card on the right, revealed on swipe */}
                  <div
                    className="absolute right-0 top-0 flex gap-2 flex-shrink-0 z-0"
                    style={{
                      opacity: isExpanded || (swipeState && swipeState.isSwiping && swipeOffset < -20) ? 1 : 0,
                      transform: swipeOffset < 0
                        ? `translateX(${Math.max(0, 110 + swipeOffset)}px)`
                        : 'translateX(110px)',
                      transition: 'opacity 0.2s ease-out',
                      pointerEvents: isExpanded ? 'auto' : 'none'
                    }}
                  >
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEdit(record);
                      }}
                      className="action-button w-[48px] h-[95px] bg-[#007233] rounded-[6px] flex items-center justify-center gap-1.5 hover:bg-[#22a882] transition-colors shadow-sm"
                      title="Edit"
                    >
                      <img src={Edit} alt="Edit" className="w-[18px] h-[18px]" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(recordId);
                      }}
                      className="action-button w-[48px] h-[95px] bg-[#E4572E] flex rounded-[6px] items-center justify-center gap-1.5 hover:bg-[#cc4d26] transition-colors shadow-sm"
                      title="Delete"
                    >
                      <img src={Delete} alt="Delete" className="w-[18px] h-[18px]" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Filter Bottom Sheet */}
      {showFilterSheet && (
        <>
          {/* Overlay */}
          <div
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={() => setShowFilterSheet(false)}
          />

          {/* Bottom Sheet */}
          <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-[360px] bg-white rounded-t-[20px] z-50 shadow-lg">
            {/* Header */}
            <div className="flex-shrink-0">
              <div className="flex justify-between items-center px-6 mt-3">
                <h2 className="text-md font-semibold">
                  Select Filters
                </h2>

                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setShowCategoryModal(true)}
                    className="text-[16px] font-semibold text-black decoration-solid"
                    style={{ textUnderlinePosition: 'from-font' }}
                  >
                    {filterData.category || 'Category'}
                  </button>
                </div>
              </div>
            </div>
            {/* Filter Form */}
            <div className="px-6 py-4 space-y-1 overflow-y-hidden overflow-x-hidden flex-1" style={{ maxHeight: 'calc(80vh - 140px)' }}>
              {/* Project Name */}
              <div className="relative" data-dropdown="projectName">
                <label className="block text-sm font-medium mb-0.5">
                  Project Name
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Select Project"
                    value={projectNameOpen ? projectNameSearch : (filterData.projectName ? siteData.find(s => s.id === filterData.projectName)?.siteName || '' : '')}
                    onChange={(e) => {
                      setProjectNameSearch(e.target.value);
                      setProjectNameOpen(true);
                      setStockingLocationOpen(false);
                    }}
                    onFocus={() => {
                      setProjectNameOpen(true);
                      setStockingLocationOpen(false);
                      if (!projectNameOpen) {
                        setProjectNameSearch('');
                      }
                    }}
                    className="w-full h-[32px] px-3 border border-gray-300 rounded-[8px] focus:outline-none text-black focus:border-gray-400 bg-white placeholder:text-[12px]"
                    style={{ paddingRight: filterData.projectName ? '60px' : '40px' }}
                  />
                  {filterData.projectName && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setFilterData({ ...filterData, projectName: '' });
                        setProjectNameOpen(false);
                        setProjectNameSearch('');
                      }}
                      className="absolute right-8 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 3L3 9M3 3L9 9" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </button>
                  )}
                  <svg
                    onClick={(e) => {
                      e.stopPropagation();
                      setProjectNameOpen(!projectNameOpen);
                      if (!projectNameOpen) {
                        setProjectNameSearch('');
                      }
                    }}
                    className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 cursor-pointer transition-transform ${projectNameOpen ? 'rotate-180' : ''}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                  {projectNameOpen && (
                    <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 shadow-lg max-h-48 overflow-hidden">
                      <div className="overflow-y-auto max-h-48">
                        <button
                          type="button"
                          onClick={() => {
                            setFilterData({ ...filterData, projectName: '' });
                            setProjectNameOpen(false);
                            setProjectNameSearch('');
                          }}
                          className={`w-full h-[34px] px-4 py-2 text-left text-sm hover:bg-gray-100 ${!filterData.projectName ? 'bg-gray-100' : ''}`}
                        >
                          Select Project
                        </button>
                        {siteData
                          .filter(site =>
                            site.siteName?.toLowerCase().includes(projectNameSearch.toLowerCase())
                          )
                          .map((site) => (
                            <button
                              key={site.id}
                              type="button"
                              onClick={() => {
                                setFilterData({ ...filterData, projectName: site.id });
                                setProjectNameOpen(false);
                                setProjectNameSearch('');
                              }}
                              className={`w-full px-4 py-2 text-left text-sm hover:bg-gray-100 ${filterData.projectName === site.id ? 'bg-gray-100' : ''}`}
                            >
                              {site.siteName}
                            </button>
                          ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Stocking Location */}
              <div className="relative" data-dropdown="stockingLocation">
                <label className="block text-sm font-medium mb-0.5 mt-2">
                  Stocking Location
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="AA Stock Room A"
                    value={stockingLocationOpen ? stockingLocationSearch : (filterData.stockingLocation ? siteData.find(s => s.id === filterData.stockingLocation)?.siteName || '' : '')}
                    onChange={(e) => {
                      setStockingLocationSearch(e.target.value);
                      setStockingLocationOpen(true);
                      setProjectNameOpen(false);
                    }}
                    onFocus={() => {
                      setStockingLocationOpen(true);
                      setProjectNameOpen(false);
                      if (!stockingLocationOpen) {
                        setStockingLocationSearch('');
                      }
                    }}
                    className="w-full h-[32px] px-4 py-2 border border-gray-300 rounded-[8px] text-black focus:outline-none focus:border-gray-400 bg-white placeholder:text-[12px]"
                    style={{ paddingRight: filterData.stockingLocation ? '60px' : '40px' }}
                  />
                  {filterData.stockingLocation && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setFilterData({ ...filterData, stockingLocation: '' });
                        setStockingLocationOpen(false);
                        setStockingLocationSearch('');
                      }}
                      className="absolute right-8 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 3L3 9M3 3L9 9" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </button>
                  )}
                  <svg
                    onClick={(e) => {
                      e.stopPropagation();
                      setStockingLocationOpen(!stockingLocationOpen);
                      if (!stockingLocationOpen) {
                        setStockingLocationSearch('');
                      }
                    }}
                    className={`absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 cursor-pointer transition-transform ${stockingLocationOpen ? 'rotate-180' : ''}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                  {stockingLocationOpen && (
                    <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 shadow-lg overflow-hidden" style={{ maxHeight: '200px', bottom: 'auto', top: '100%' }}>
                      <div className="overflow-y-auto" style={{ maxHeight: '100px' }}>
                        <button
                          type="button"
                          onClick={() => {
                            setFilterData({ ...filterData, stockingLocation: '' });
                            setStockingLocationOpen(false);
                            setStockingLocationSearch('');
                          }}
                          className={`w-full px-4 py-2 text-left text-sm hover:bg-gray-100 ${!filterData.stockingLocation ? 'bg-gray-100' : ''}`}
                        >
                          AA Stock Room A
                        </button>
                        {siteData
                          .filter(site =>
                            site.siteName?.toLowerCase().includes(stockingLocationSearch.toLowerCase())
                          )
                          .map((site) => (
                            <button
                              key={site.id}
                              type="button"
                              onClick={() => {
                                setFilterData({ ...filterData, stockingLocation: site.id });
                                setStockingLocationOpen(false);
                                setStockingLocationSearch('');
                              }}
                              className={`w-full px-4 py-2 text-left text-sm hover:bg-gray-100 ${filterData.stockingLocation === site.id ? 'bg-gray-100' : ''}`}
                            >
                              {site.siteName}
                            </button>
                          ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Date and Entry No */}
              <div className="grid grid-cols-2 gap-4" style={{ overflow: 'visible' }}>
                <div className="relative">
                  <label className="block text-sm font-medium mb-0.5 mt-2">
                    Date
                  </label>
                  <input
                    type="date"
                    value={filterData.date}
                    onChange={(e) => setFilterData({ ...filterData, date: e.target.value })}
                    className="w-full h-[32px] px-4 py-2 border border-gray-300 rounded-[8px] text-black focus:outline-none focus:border-gray-400 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-0.5 mt-2">
                    Entry.No
                  </label>
                  <input
                    type="text"
                    placeholder="Enter"
                    value={filterData.entryNo}
                    onChange={(e) => setFilterData({ ...filterData, entryNo: e.target.value })}
                    className="w-full h-[32px] px-4 py-2 border border-gray-300 rounded-[8px] text-black focus:outline-none focus:border-gray-400 bg-white placeholder:text-[12px]"
                  />
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex-shrink-0 flex gap-3 px-6 py-4">
              <button
                onClick={() => setShowFilterSheet(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => setShowFilterSheet(false)}
                className="flex-1 px-4 py-2 bg-black text-white rounded-lg font-medium hover:bg-gray-900"
              >
                Save
              </button>
            </div>
          </div>
        </>
      )}

      <SelectVendorModal
        isOpen={showCategoryModal}
        onClose={() => setShowCategoryModal(false)}
        onSelect={(value) => {
          setFilterData({ ...filterData, category: value });
          setShowCategoryModal(false);
        }}
        selectedValue={filterData.category}
        options={categoryOptionsStrings}
        fieldName="Category"
        onAddNew={handleAddNewCategory}
      />
    </div>
  );
};

export default NonPOHistory;

