import React, { useEffect, useMemo, useState } from 'react';
import Filter from '../Images/Filter.png';
import CloseIcon from '../Images/Close F.svg'
import DatePickerModal from '../PurchaseOrder/DatePickerModal';

const Chip = ({ label, tone = 'neutral', onClick }) => {
	const toneStyles =
		tone === 'success'
			? { bg: '#E2F9E1', text: '#4CAF50', border: '#E2F9E1' }
			: tone === 'warn'
				? { bg: '#FFD39E', text: '#111827', border: '#FFD39E' }
					: { bg: '#FAF6ED', text: '#111827', border: '#D1D5DB' };

	if (typeof onClick === 'function') {
		return (
			<button
				type="button"
				onClick={onClick}
				className="px-[8px] py-[2px] rounded-full text-[10px] font-medium inline-flex items-center gap-[4px] border cursor-pointer"
				style={{ background: toneStyles.bg, color: toneStyles.text, borderColor: toneStyles.border }}
			>
				{tone === 'success' && (
					<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M10.25 2.75L4.75 8.25L1.75 5.25" stroke="#4CAF50" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
					</svg>
				)}
				{label}
			</button>
		);
	}

	return (
		<span
			className={`px-[8px] py-[2px] rounded-full text-[10px] font-medium inline-flex items-center gap-[4px] border`}
			style={{ background: toneStyles.bg, color: toneStyles.text, borderColor: toneStyles.border }}
		>
			{tone === 'success' && (
				<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M10.25 2.75L4.75 8.25L1.75 5.25" stroke="#4CAF50" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
				</svg>
			)}
			{label}
		</span>
	);
};

const PendingBillMobile = ({ username, userRoles = [] }) => {
	const resolveActiveBranchId = () => {
		try {
			const selectedBranchId = localStorage.getItem("selectedBranchId");
			const user = JSON.parse(localStorage.getItem("user") || "{}");
			const fallbackBranchId = user?.branchId ?? user?.branch_id ?? user?.brachId;
			const resolved = Number(selectedBranchId || fallbackBranchId);
			return Number.isFinite(resolved) && resolved > 0 ? resolved : null;
		} catch {
			return null;
		}
	};
	const [activeBranchId, setActiveBranchId] = useState(() => resolveActiveBranchId());

	const withBranchUrl = (baseUrl) => {
		try {
			const url = new URL(baseUrl);
			if (activeBranchId !== null && activeBranchId !== undefined && activeBranchId !== "") {
				url.searchParams.set("branchId", String(activeBranchId));
			}
			return url.toString();
		} catch {
			return baseUrl;
		}
	};

	const fetchWithBranch = (input, init) => {
		if (typeof input === 'string') {
			return window.fetch(withBranchUrl(input), init);
		}
		return window.fetch(input, init);
	};

	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);
	const [apiData, setApiData] = useState([]);
	const [vendorMap, setVendorMap] = useState({});
	const [expensesData, setExpensesData] = useState([]);
	const [allBillEntries, setAllBillEntries] = useState([]);
	const [expenseMatchStatus, setExpenseMatchStatus] = useState({});
	const [paymentStatuses, setPaymentStatuses] = useState({});
	const [paidTodayBills, setPaidTodayBills] = useState({});
	const [query, setQuery] = useState('');
	const [showVerifyModal, setShowVerifyModal] = useState(false);
	const [selectedVerifyBill, setSelectedVerifyBill] = useState(null);
	const [verifyBoxes, setVerifyBoxes] = useState([]);
	const [rangeStart, setRangeStart] = useState('');
	const [rangeEnd, setRangeEnd] = useState('');
	const [showAddSheet, setShowAddSheet] = useState(false);
	const [addForm, setAddForm] = useState({
		vendorId: '',
		receivedDate: '',
		noOfBills: '',
		totalAmount: ''
	});
	const [showVendorPicker, setShowVendorPicker] = useState(false);
	const [vendorPickerQuery, setVendorPickerQuery] = useState('');
	const [showReceivedDatePicker, setShowReceivedDatePicker] = useState(false);

	const getVendorNameById = (vendorId) => {
		if (!vendorId && vendorId !== 0) return '-';
		return vendorMap[vendorId] || vendorMap[String(vendorId)] || '-';
	};

	const formatIndianCurrency = (amount) => {
		const n = Number(amount || 0);
		if (!Number.isFinite(n)) return '₹0';
		return `₹${n.toLocaleString('en-IN')}`;
	};

	const formatRelativeDateLabel = (input) => {
		if (!input) return '';
		try {
			const d0 = new Date(input);
			if (isNaN(d0.getTime())) return '';
			const now = new Date();
			const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
			const yesterday = new Date(today);
			yesterday.setDate(yesterday.getDate() - 1);
			const dateOnly = new Date(d0.getFullYear(), d0.getMonth(), d0.getDate());
			if (dateOnly.getTime() === today.getTime()) return 'Today';
			if (dateOnly.getTime() === yesterday.getTime()) return 'Yesterday';
			const dd = String(d0.getDate()).padStart(2, '0');
			const mm = String(d0.getMonth() + 1).padStart(2, '0');
			const yyyy = d0.getFullYear();
			return `${dd}/${mm}/${yyyy}`;
		} catch {
			return '';
		}
	};

	const formatBillArrival = (input) => {
		if (!input) return '';
		const d = new Date(input);
		if (isNaN(d.getTime())) return '';
		const dd = String(d.getDate()).padStart(2, '0');
		const mm = String(d.getMonth() + 1).padStart(2, '0');
		const yyyy = d.getFullYear();
		const HH = String(d.getHours()).padStart(2, '0');
		const MM = String(d.getMinutes()).padStart(2, '0');
		const SS = String(d.getSeconds()).padStart(2, '0');
		const rel = formatRelativeDateLabel(input) || '';
		return `${rel} • ${dd}/${mm}/${yyyy}, ${HH}:${MM}:${SS}`;
	};

	const getBillVerificationStatus = (item) => {
		const verifications = item?.billVerifications || item?.bill_verifications || [];
		if (!Array.isArray(verifications) || verifications.length === 0) return 'Verify';
		const allVerified = verifications.every(v => v?.is_verified === true || v?.status === 'VERIFIED');
		const anyVerified = verifications.some(v => v?.is_verified === true || v?.status === 'VERIFIED');
		if (allVerified) return '✓ Verified';
		if (anyVerified) return 'Verified';
		return 'Verify';
	};

	const openVerifyModal = (bill) => {
		setSelectedVerifyBill(bill || null);
		const noOfBills = Number(bill?.no_of_bills ?? bill?.noOfBills ?? 0) || 0;
		const extraBills = Number(bill?.extra_bills ?? bill?.extraBills ?? 0) || 0;
		const total = Math.max(0, noOfBills + extraBills);
		setVerifyBoxes(new Array(total).fill(''));
		setRangeStart('');
		setRangeEnd('');
		setShowVerifyModal(true);
	};

	const openAddSheet = () => {
		setAddForm({
			vendorId: '',
			receivedDate: '',
			noOfBills: '',
			totalAmount: ''
		});
		setVendorPickerQuery('');
		setShowVendorPicker(false);
		setShowAddSheet(true);
	};

	const closeAddSheet = () => {
		setShowAddSheet(false);
		setShowReceivedDatePicker(false);
		setShowVendorPicker(false);
		setVendorPickerQuery('');
	};

	const toDdMmYyyySlashes = (yyyyMmDd) => {
		if (!yyyyMmDd) return '';
		const parts = String(yyyyMmDd).split('-');
		if (parts.length !== 3) return '';
		const [yyyy, mm, dd] = parts;
		if (!dd || !mm || !yyyy) return '';
		return `${String(dd).padStart(2, '0')}/${String(mm).padStart(2, '0')}/${String(yyyy)}`;
	};

	const getReceivedDateInitialForModal = () => {
		const v = addForm.receivedDate;
		if (!v) return '';
		if (String(v).includes('/')) return v; // already DD/MM/YYYY
		if (String(v).includes('-')) return toDdMmYyyySlashes(v); // YYYY-MM-DD
		return '';
	};

	const vendorOptionsForSheet = useMemo(() => {
		const seen = new Set();
		const entries = Object.entries(vendorMap || {});
		const unique = [];
		for (const [id, name] of entries) {
			const key = String(id);
			if (!key || key === 'undefined' || key === 'null') continue;
			if (!name) continue;
			if (seen.has(key)) continue;
			seen.add(key);
			unique.push({ id: key, name: String(name) });
		}
		unique.sort((a, b) => a.name.localeCompare(b.name));
		return unique;
	}, [vendorMap]);

	const selectedVendorNameForSheet = useMemo(() => {
		if (!addForm.vendorId) return '';
		const hit = vendorOptionsForSheet.find(v => String(v.id) === String(addForm.vendorId));
		return hit?.name || '';
	}, [addForm.vendorId, vendorOptionsForSheet]);

	const filteredVendorOptionsForSheet = useMemo(() => {
		const q = (vendorPickerQuery || '').trim().toLowerCase();
		if (!q) return vendorOptionsForSheet;
		return vendorOptionsForSheet.filter(v => (v.name || '').toLowerCase().includes(q));
	}, [vendorOptionsForSheet, vendorPickerQuery]);

	const getEntryStatusText = (item) => {
		const baseStatus = item?.entry_status || item?.entryStatus || 'Entry';
		const matchStatus = expenseMatchStatus[item?.id];
		if (matchStatus === 'complete_match') return '✓ Entered';
		if (matchStatus === 'partial_match') return 'Entered';
		return baseStatus;
	};

	useEffect(() => {
		const syncBranch = () => {
			const nextBranchId = resolveActiveBranchId();
			setActiveBranchId((prevBranchId) => (prevBranchId === nextBranchId ? prevBranchId : nextBranchId));
		};
		syncBranch();
		window.addEventListener('branchSelectionChanged', syncBranch);
		return () => window.removeEventListener('branchSelectionChanged', syncBranch);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	useEffect(() => {
		let isMounted = true;

		const fetchVendorNames = async () => {
			try {
				const res = await fetchWithBranch('https://backendaab.in/aabuilderDash/api/vendor_Names/getAll', {
					method: 'GET',
					credentials: 'include',
					headers: { 'Content-Type': 'application/json' }
				});
				if (!res.ok) return;
				const data = await res.json();
				const map = {};
				(Array.isArray(data) ? data : []).forEach(v => {
					const id = v?.id ?? v?._id;
					const name = v?.vendorName ?? v?.vendor_name ?? v?.label ?? '';
					if (id != null && name) {
						map[id] = name;
						map[String(id)] = name;
					}
				});
				if (isMounted) setVendorMap(map);
			} catch {
				// ignore
			}
		};

		const fetchTrackerData = async () => {
			setLoading(true);
			setError(null);
			try {
				const res = await fetchWithBranch('https://backendaab.in/aabuildersDash/api/vendor-payments/trackers', {
					method: 'GET',
					credentials: 'include',
					headers: { 'Content-Type': 'application/json' }
				});
				const text = await res.text();
				let data = [];
				try {
					data = JSON.parse(text);
				} catch (e) {
					data = [];
				}
				if (isMounted) setApiData(Array.isArray(data) ? data : []);
			} catch (e) {
				if (isMounted) setError('Failed to load');
			} finally {
				if (isMounted) setLoading(false);
			}
		};

		const fetchAllBillEntries = async () => {
			try {
				const res = await fetchWithBranch('https://backendaab.in/aabuildersDash/api/bill-entry/getAll', {
					method: 'GET',
					credentials: 'include',
					headers: { 'Content-Type': 'application/json' }
				});
				if (!res.ok) return;
				const data = await res.json();
				if (isMounted) setAllBillEntries(Array.isArray(data) ? data : []);
			} catch {
				// ignore
			}
		};

		const fetchExpensesData = async () => {
			try {
				const res = await fetchWithBranch('https://backendaab.in/aabuilderDash/expenses_form/get_form', {
					method: 'GET',
					credentials: 'include',
					headers: { 'Content-Type': 'application/json' }
				});
				if (!res.ok) return;
				const data = await res.json();
				if (isMounted) setExpensesData(Array.isArray(data) ? data : []);
			} catch {
				// ignore
			}
		};

		// Clear branch-specific data first to avoid stale display during branch switch (same as desktop)
		if (isMounted) {
			setApiData([]);
			setAllBillEntries([]);
			setPaymentStatuses({});
			setPaidTodayBills({});
		}

		// Kick off all lookups in parallel
		fetchVendorNames();
		fetchTrackerData();
		fetchAllBillEntries();
		fetchExpensesData();
		return () => {
			isMounted = false;
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [activeBranchId]);

	useEffect(() => {
		const computeExpenseMatchStatus = () => {
			const matchStatus = {};
			const billMap = {};
			apiData.forEach(bill => {
				const id = bill?.id;
				if (id != null) billMap[id] = bill;
			});

			const groupedBillEntries = {};
			allBillEntries.forEach(be => {
				const trackerId = be?.vendor_payments_tracker_id ?? be?.vendorPaymentsTrackerId;
				if (!trackerId) return;
				if (!groupedBillEntries[trackerId]) groupedBillEntries[trackerId] = [];
				groupedBillEntries[trackerId].push(be);
			});

			Object.keys(groupedBillEntries).forEach(trackerId => {
				const bill = billMap[trackerId];
				if (!bill) return;

				const vendorName = getVendorNameById(bill?.vendor_id ?? bill?.vendorId) || bill?.vendor_name;
				const billAmount = parseFloat(bill?.total_amount ?? bill?.totalAmount) || 0;
				if (!vendorName || billAmount <= 0) {
					matchStatus[trackerId] = 'no_match';
					return;
				}

				const billEntriesForTracker = groupedBillEntries[trackerId] || [];
				const enteredDates = [...new Set(billEntriesForTracker.map(be => be?.entered_date ?? be?.enteredDate).filter(Boolean))];
				if (enteredDates.length === 0) {
					matchStatus[trackerId] = 'no_match';
					return;
				}

				const billEnteredDates = enteredDates.map(date => {
					try {
						return new Date(date).toISOString().split('T')[0];
					} catch {
						return null;
					}
				}).filter(Boolean);

				const dateMatchedExpenses = expensesData.filter(expense => {
					const expenseDate = new Date(expense?.timestamp ?? expense?.date);
					if (isNaN(expenseDate.getTime())) return false;
					const iso = expenseDate.toISOString().split('T')[0];
					return billEnteredDates.includes(iso);
				});

				const vendorMatchedExpenses = dateMatchedExpenses.filter(expense => expense?.vendor === vendorName);
				const matchingExpenses = vendorMatchedExpenses.filter(expense => {
					const at = String(expense?.accountType ?? '').trim();
					return at === 'Bill Payments' || at === 'Bill Refund' || at === 'Bill Payments + Claim';
				});

				const totalExpenseAmount = matchingExpenses.reduce((sum, expense) => sum + (parseFloat(expense?.amount) || 0), 0);
				const adjustmentAmount = parseFloat(bill?.adjustment_amount ?? bill?.adjustmentAmount) || 0;
				const adjustedBillAmount = billAmount - adjustmentAmount;
				if (matchingExpenses.length === 0) {
					matchStatus[trackerId] = 'no_match';
				} else if (Math.abs(totalExpenseAmount - adjustedBillAmount) < 0.01) {
					matchStatus[trackerId] = 'complete_match';
				} else if (totalExpenseAmount > 0) {
					matchStatus[trackerId] = 'partial_match';
				} else {
					matchStatus[trackerId] = 'no_match';
				}
			});

			setExpenseMatchStatus(matchStatus);
		};

		if (apiData.length > 0 && expensesData.length > 0 && allBillEntries.length > 0) {
			computeExpenseMatchStatus();
		}
	}, [apiData, expensesData, allBillEntries, vendorMap]);

	useEffect(() => {
		const getPaymentStatus = async (item) => {
			try {
				const response = await fetchWithBranch(`https://backendaab.in/aabuildersDash/api/vendor-bill-tracker/get/${item?.id}`, {
					method: 'GET',
					credentials: 'include',
					headers: { 'Content-Type': 'application/json' }
				});
				if (!response.ok) return { status: 'To Pay', lastPaymentDate: null, paidToday: false };
				const paymentDetails = await response.json();
				if (!paymentDetails || paymentDetails.length === 0) return { status: 'To Pay', lastPaymentDate: null, paidToday: false };

				const totalPaid = paymentDetails.reduce((sum, payment) => {
					const amount = parseFloat(payment?.amount) || 0;
					const carryForwardAmount = parseFloat(payment?.carry_forward_amount) || 0;
					return sum + amount + carryForwardAmount;
				}, 0);

				const totalDiscount = paymentDetails.reduce((sum, payment) => sum + (payment?.discount_amount || 0), 0);
				const actualAmount = parseFloat(item?.total_amount ?? item?.totalAmount) || 0;
				const remainingAmount = Math.max(0, actualAmount - totalPaid - totalDiscount);

				let lastPaymentDate = null;
				if (paymentDetails.length > 0) {
					const dates = paymentDetails
						.map(p => p?.date)
						.filter(Boolean)
						.sort((a, b) => new Date(b) - new Date(a));
					if (dates.length > 0) lastPaymentDate = dates[0];
				}

				const today = new Date();
				today.setHours(0, 0, 0, 0);
				const todayEnd = new Date(today);
				todayEnd.setHours(23, 59, 59, 999);
				let paidToday = false;
				for (const payment of paymentDetails) {
					const ts = payment?.timestamp ?? payment?.created_at;
					if (ts) {
						const paymentTimestamp = new Date(ts);
						if (paymentTimestamp >= today && paymentTimestamp <= todayEnd) {
							paidToday = true;
							break;
						}
					}
					const dp = payment?.date;
					if (dp) {
						const paymentDate = new Date(dp);
						paymentDate.setHours(0, 0, 0, 0);
						if (paymentDate.getTime() === today.getTime()) {
							paidToday = true;
							break;
						}
					}
				}

				if (remainingAmount === 0) return { status: '✓ Paid', lastPaymentDate, paidToday };
				if (totalPaid > 0) return { status: 'Paid', lastPaymentDate, paidToday };
				return { status: 'To Pay', lastPaymentDate, paidToday };
			} catch {
				return { status: 'To Pay', lastPaymentDate: null, paidToday: false };
			}
		};

		const fetchPaymentStatuses = async () => {
			if (apiData.length === 0) return;
			const statuses = await Promise.all(apiData.map(async item => {
				const result = await getPaymentStatus(item);
				return { id: item?.id, status: result?.status, paidToday: result?.paidToday };
			}));
			const map = {};
			const paidTodayMap = {};
			statuses.forEach(s => {
				if (s?.id != null) {
					map[s.id] = s.status;
					paidTodayMap[s.id] = !!s.paidToday;
				}
			});
			setPaymentStatuses(map);
			setPaidTodayBills(paidTodayMap);
		};

		fetchPaymentStatuses();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [apiData, activeBranchId]);

	// Desktop behavior: hide fully paid rows unless paid today; keep To Pay + Paid
	const visibleRows = useMemo(() => {
		return apiData.filter((item) => {
			const status = paymentStatuses[item?.id] || 'To Pay';
			const hasPaidToday = paidTodayBills[item?.id] || false;
			if (status === 'To Pay') return true;
			if (status === 'Paid') return true;
			if (hasPaidToday) return true;
			return false; // hide only fully paid bills
		});
	}, [apiData, paymentStatuses, paidTodayBills]);

	const filtered = useMemo(() => {
		if (!query) return visibleRows;
		const q = query.toLowerCase();
		return visibleRows.filter((row) => {
			const id = row?.vendor_id ?? row?.vendorId;
			const name = getVendorNameById(id);
			return (name || '').toLowerCase().includes(q);
		});
	}, [visibleRows, query, vendorMap]);
	return (
		<div className="w-full flex flex-col" style={{ height: 'calc(100vh - 182px)', overflow: 'hidden' }}>
			{/* Date / Vendor row */}
			<div className="flex items-center justify-between mt-[2px] border-b border-[#E0E0E0] pb-[8px]">
				<p className="text-[12px] font-semibold text-[#111827]">Date</p>
				<p className="text-[12px] font-semibold text-[#111827]">Vendor</p>
			</div>
			{/* Search */}
			<div className=" mt-[10px]">
				<div className="w-full h-[36px] rounded-[24px] bg-white border border-[#E5E7EB] flex items-center px-[12px]">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none">
						<circle cx="11" cy="11" r="7" stroke="#9CA3AF" strokeWidth="1.5" />
						<path d="M20 20L17 17" stroke="#9CA3AF" strokeWidth="1.5" strokeLinecap="round" />
					</svg>
					<input
						value={query}
						onChange={(e) => setQuery(e.target.value)}
						placeholder="Search"
						className="ml-[8px] flex-1 outline-none text-[12px] font-semibold text-[#111827] placeholder-[#9CA3AF]"
						style={{ background: 'transparent' }}
					/>
				</div>
			</div>
			{/* Filter and Download Row (match ToolsTracker History layout) */}
			<div className="flex justify-between items-center gap-[4px] px-0 mt-[6px] flex-shrink-0">
				<div className="flex items-center gap-[4px] min-w-0">
					<button type="button" className="flex items-center gap-[4px] px-[6px] py-[2px] flex-shrink-0">
						<img src={Filter} alt="Filter" className="w-[13px] h-[11px]" />
						<span className="text-[12px] font-medium text-black flex-shrink-0">Filter</span>
					</button>
				</div>
			</div>
			{/* List */}
			<div
				className="flex-1 overflow-y-auto no-scrollbar scrollbar-none pb-4"
			>
				{loading && <p className="text-[12px] text-center text-[#6B7280]">Loading…</p>}
				{!loading && filtered.length === 0 && <p className="text-[12px] text-center text-[#6B7280]">No data</p>}
				{filtered.map((row, idx) => {
					const vendorName = getVendorNameById(row?.vendor_id ?? row?.vendorId) || 'Vendor';
					const amount = row?.total_amount ?? row?.totalAmount ?? 0;
					const noOfBills = row?.no_of_bills ?? row?.noOfBills ?? 0;
					const extraBills = row?.extra_bills ?? row?.extraBills ?? 0;
					const billsCount = extraBills > 0 ? `${noOfBills} & ${extraBills}` : (noOfBills || '-');
					const subLine = formatBillArrival(row?.bill_arrival_date ?? row?.billArrivalDate);

					const verificationStatus = getBillVerificationStatus(row);
					const entryStatusText = getEntryStatusText(row);
					const paymentStatus = paymentStatuses[row?.id] || 'To Pay';

					const statusLeft =
						verificationStatus === '✓ Verified' ? (
							<Chip label="Verified" tone="success" />
						) : verificationStatus === 'Verified' ? (
							<Chip label="Verified" tone="warn" />
						) : (
							<Chip label="To Verify" tone="neutral" onClick={() => openVerifyModal(row)} />
						);

					const statusMid = (entryStatusText === 'Entered' || entryStatusText === '✓ Entered') ? (
						<Chip label="Entered" tone={entryStatusText === '✓ Entered' ? 'success' : 'warn'} />
					) : (
						<Chip label="To Entry" tone="neutral" />
					);

					const statusRight =
						paymentStatus === '✓ Paid' ? (
							<Chip label="Paid" tone="success" />
						) : paymentStatus === 'Paid' ? (
							<Chip label="Paid" tone="warn" />
						) : (
							<Chip label="To Pay" tone="neutral" />
						);

					return (
						<div
							key={idx}
							className="relative overflow-hidden shadow-lg border border-[#E0E0E0] border-opacity-30 bg-[#F8F8F8] rounded-[8px] w-full"
						>
							{/* Inner card (matches PO History card) */}
							<div className="bg-white rounded-[8px] h-full px-[12px] py-[12px] transition-all duration-300 ease-out flex flex-col">
								<div className="flex items-start justify-between gap-[8px]">
									<div className="min-w-0">
										<p
											className="text-[12px] font-semibold text-black leading-snug break-words mb-0.5"
											style={{ wordBreak: 'break-word', overflowWrap: 'break-word' }}
										>
											{vendorName || 'N/A'}
										</p>
										<p
											className="text-[11px] font-medium text-[#777777] leading-snug break-words"
											style={{ wordBreak: 'break-word', overflowWrap: 'break-word' }}
										>
											{subLine || ''}
										</p>
									</div>
									<div className="flex-shrink-0 flex flex-col items-end gap-[4px]">
										<p className="text-[12px] font-semibold text-black leading-snug">
											₹{amount?.toLocaleString?.('en-IN') || amount || '0'}
										</p>
										<p className="text-[11px] font-medium text-[#777777] leading-snug">
											No. of bills: {billsCount ?? '-'}
										</p>
									</div>
								</div>

								<div className="flex items-center gap-[8px] flex-wrap mt-[8px]">
									{statusLeft}
									{statusMid}
									{statusRight}
								</div>
							</div>
						</div>
					);
				})}
			</div>
			{/* Verify Modal (mobile) */}
			{showVerifyModal && (
				<div className="fixed inset-0 z-[999] bg-white">
					<div className="w-full max-w-[360px] mx-auto min-h-screen bg-white">
						{/* Top bar */}
						<div className="pt-[16px] px-[14px]">
							<div className="flex items-start justify-between gap-[10px]">
								<div className="flex items-center gap-[10px]">
									<button
										type="button"
										onClick={() => { setShowVerifyModal(false); setSelectedVerifyBill(null); }}
										className="w-[28px] h-[28px] flex items-center justify-center"
										aria-label="Back"
									>
										<svg width="18" height="18" viewBox="0 0 24 24" fill="none">
											<path d="M15 18L9 12L15 6" stroke="#111827" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
										</svg>
									</button>
									<div className="min-w-0">
										<p className="text-[14px] font-semibold text-black leading-tight">Enter PO Number</p>
										<p className="text-[11px] font-medium text-[#777777] leading-tight mt-[2px] truncate max-w-[240px]">
											{(() => {
												const d = selectedVerifyBill?.bill_arrival_date ?? selectedVerifyBill?.billArrivalDate;
												const vendorName = getVendorNameById(selectedVerifyBill?.vendor_id ?? selectedVerifyBill?.vendorId) || '';
												const dateStr = d ? new Date(d).toLocaleDateString('en-GB') : '';
												return `${dateStr}${vendorName ? ` - ${vendorName}` : ''}`;
											})()}
										</p>
									</div>
								</div>
								<div className="text-right flex-shrink-0">
									<p className="text-[11px] font-semibold text-black leading-tight">Last PO: -</p>
									<p className="text-[10px] font-medium text-[#777777] leading-tight mt-[2px]">
										({verifyBoxes.length} Bills Verified)
									</p>
								</div>
							</div>
						</div>

						{/* Content */}
						<div className="px-[14px] pt-[10px] pb-[96px]">
							<div className="flex items-center justify-between">
								<p className="text-[12px] font-semibold text-black">Fill Range</p>
								<button type="button" className="text-[12px] font-semibold text-black flex items-center gap-[6px]">
									Send Request
									<svg width="14" height="14" viewBox="0 0 24 24" fill="none">
										<path d="M3 21h18" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
										<path d="M14 4l6 6" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
										<path d="M16 2l6 6L8 22H2v-6L16 2z" stroke="#111827" strokeWidth="2" strokeLinejoin="round" />
									</svg>
								</button>
							</div>

							<div className="mt-[10px] rounded-[10px] border border-[#E5E7EB] p-[10px]">
								<div className="flex items-center gap-[10px]">
									<input
										value={rangeStart}
										onChange={(e) => setRangeStart(e.target.value.replace(/[^0-9]/g, ''))}
										placeholder=""
										className="w-[72px] h-[30px] border border-[#D1D5DB] rounded-[6px] text-[12px] font-semibold text-center outline-none"
									/>
									<input
										value={rangeEnd}
										onChange={(e) => setRangeEnd(e.target.value.replace(/[^0-9]/g, ''))}
										placeholder=""
										className="w-[72px] h-[30px] border border-[#D1D5DB] rounded-[6px] text-[12px] font-semibold text-center outline-none"
									/>
									<button
										type="button"
										className="ml-auto text-[12px] font-semibold text-black"
									>
										Fill Range
									</button>
								</div>

								<div className="grid grid-cols-4 gap-[10px] mt-[12px]">
									{verifyBoxes.map((_, i) => (
										<div
											key={i}
											className="h-[34px] rounded-[4px] border border-[#D1D5DB] bg-white flex items-center justify-center"
										>
											{/* empty boxes only (no numbers) */}
										</div>
									))}
								</div>
							</div>

							<div className="mt-[12px] grid grid-cols-2 gap-[10px]">
								<button type="button" className="h-[36px] rounded-[8px] border border-[#D1D5DB] bg-white text-[12px] font-semibold text-black">
									Check PO
								</button>
								<button type="button" className="h-[36px] rounded-[8px] border border-[#D1D5DB] bg-white text-[12px] font-semibold text-black">
									Make Duplicate
								</button>
							</div>

							<button type="button" className="mt-[10px] w-full h-[40px] rounded-[8px] bg-black text-white text-[13px] font-semibold">
								Submit
							</button>
						</div>
					</div>
				</div>
			)}
			{/* Floating action button */}
			<button
				type="button"
				onClick={openAddSheet}
				className="fixed right-[20px] bottom-[92px] w-[48px] h-[48px] rounded-full bg-black flex items-center justify-center shadow-lg"
				aria-label="Add"
			>
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none">
					<path d="M12 5V19" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
					<path d="M5 12H19" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
				</svg>
			</button>

			{/* Add bottom sheet (mobile) */}
			{showAddSheet && (
				<div className={`fixed inset-0 ${showReceivedDatePicker ? 'z-[40]' : 'z-[999]'} flex items-end justify-center`}>
					<button
						type="button"
						className="absolute inset-0 bg-black/40"
						aria-label="Close"
						onClick={closeAddSheet}
					/>
					<div className="relative w-full bg-white rounded-t-[18px] px-[16px] pt-[14px] pb-[16px]">
						<div className="flex items-center justify-between">
							<p className="text-[14px] font-semibold text-black">Enter Bill Details</p>
							<button
								type="button"
								onClick={closeAddSheet}
								className="w-[28px] h-[28px] flex items-center justify-center"
								aria-label="Close"
							>
								<span className="text-[20px] leading-none font-semibold text-[#E4572E]">×</span>
							</button>
						</div>

						<div className="mt-[10px] flex flex-col gap-[10px]">
							<div>
								<p className="text-[12px] font-semibold text-black mb-[6px]">Vendor Name</p>
								<div className="relative">
									<div
										role="button"
										tabIndex={0}
										onClick={() => setShowVendorPicker(true)}
										onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') setShowVendorPicker(true); }}
										className="w-full h-[38px] rounded-[6px] border border-[#D1D5DB] bg-white px-[12px] pr-[34px] text-[12px] font-medium flex items-center cursor-pointer"
										style={{ color: selectedVendorNameForSheet ? '#111827' : '#9E9E9E' }}
									>
										<span className="truncate">{selectedVendorNameForSheet || 'Select Vendor'}</span>
									</div>
									{selectedVendorNameForSheet ? (
										<button
											type="button"
											onClick={(e) => {
												e.stopPropagation();
												setAddForm((p) => ({ ...p, vendorId: '' }));
											}}
											className="absolute right-2 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors"
											aria-label="Clear"
										>
											<img src={CloseIcon} alt="Close" className="w-[12px] h-[12px]" />
										</button>
									) : (
										<div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
											<svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
												<path d="M1 1L6 6L11 1" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
											</svg>
										</div>
									)}
								</div>
							</div>

							<div>
								<p className="text-[12px] font-semibold text-black mb-[6px]">Received Date</p>
								<div className="relative">
									<div
										role="button"
										tabIndex={0}
										onClick={() => setShowReceivedDatePicker(true)}
										onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') setShowReceivedDatePicker(true); }}
										className="w-full h-[38px] rounded-[6px] border border-[#D1D5DB] bg-white px-[12px] pr-[34px] text-[12px] font-medium flex items-center cursor-pointer"
										style={{ color: addForm.receivedDate ? '#111827' : '#9E9E9E' }}
									>
										<span className="truncate">
											{addForm.receivedDate ? String(addForm.receivedDate).replaceAll('/', '-') : 'dd-mm-yyyy'}
										</span>
									</div>
									<div className="pointer-events-none absolute right-[10px] top-1/2 -translate-y-1/2">
										<svg width="16" height="16" viewBox="0 0 24 24" fill="none">
											<path d="M7 10h10" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
											<path d="M7 14h7" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
											<path d="M8 3v3" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
											<path d="M16 3v3" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
											<path d="M5 6h14a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z" stroke="#111827" strokeWidth="2" strokeLinejoin="round" />
										</svg>
									</div>
								</div>
							</div>

							<div className="grid grid-cols-2 gap-[10px]">
								<div>
									<p className="text-[12px] font-semibold text-black mb-[6px]">No. of Bills</p>
									<input
										type="number"
										value={addForm.noOfBills}
										onChange={(e) => setAddForm((p) => ({ ...p, noOfBills: e.target.value }))}
										placeholder="Enter Bill Count"
										className="w-full h-[38px] rounded-[6px] border border-[#D1D5DB] bg-white px-[12px] text-[12px] font-medium text-[#111827] outline-none"
									/>
								</div>
								<div>
									<p className="text-[12px] font-semibold text-black mb-[6px]">Total Amount</p>
									<input
										type="number"
										value={addForm.totalAmount}
										onChange={(e) => setAddForm((p) => ({ ...p, totalAmount: e.target.value }))}
										placeholder="Enter Amount"
										className="w-full h-[38px] rounded-[6px] border border-[#D1D5DB] bg-white px-[12px] text-[12px] font-medium text-[#111827] outline-none"
									/>
								</div>
							</div>

							<div className="mt-[4px] grid grid-cols-2 gap-[12px]">
								<button
									type="button"
									onClick={closeAddSheet}
									className="h-[40px] rounded-[10px] border border-[#D1D5DB] bg-white text-[13px] font-semibold text-black"
								>
									Cancel
								</button>
								<button
									type="button"
									onClick={closeAddSheet}
									className="h-[40px] rounded-[10px] bg-black text-[13px] font-semibold text-white"
								>
									Submit
								</button>
							</div>
						</div>
					</div>

					{/* Vendor picker popup (same behavior style as ToolsTracker dropdown popup) */}
					{showVendorPicker && (
						<div
							className="fixed inset-0 bg-black bg-opacity-50 z-[1002] flex items-center justify-center p-4"
							onClick={(e) => {
								if (e.target === e.currentTarget) {
									setShowVendorPicker(false);
									setVendorPickerQuery('');
								}
							}}
						>
							<div
								className="bg-white w-full max-w-[360px] mx-auto rounded-t-[20px] rounded-b-[20px] shadow-lg max-h-[80vh] flex flex-col"
								onClick={(e) => e.stopPropagation()}
								onMouseDown={(e) => e.stopPropagation()}
							>
								<div className="flex justify-between items-center px-6 pt-[24px]">
									<p className="text-[16px] font-semibold text-black">Select Vendor</p>
									<button
										type="button"
										onClick={() => { setShowVendorPicker(false); setVendorPickerQuery(''); }}
										className="text-red-500 text-[20px] font-semibold hover:opacity-80 transition-opacity"
										aria-label="Close"
									>
										<span className="text-[20px] leading-none font-semibold text-[#E4572E]">×</span>
									</button>
								</div>
								<div className="px-6 pt-[4px] pb-[6px]">
									<div className="relative">
										<input
											type="text"
											value={vendorPickerQuery}
											onChange={(e) => setVendorPickerQuery(e.target.value)}
											placeholder="Search"
											className="w-full h-[32px] pl-[30px] pr-4 border border-[rgba(0,0,0,0.16)] rounded-[8px] text-[12px] font-medium text-black placeholder:text-[#9E9E9E] bg-white focus:outline-none"
											autoFocus
										/>
										<div className="absolute left-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
											<svg width="12" height="12" viewBox="0 0 24 24" fill="none">
												<circle cx="11" cy="11" r="7" stroke="#9CA3AF" strokeWidth="1.5" />
												<path d="M20 20L17 17" stroke="#9CA3AF" strokeWidth="1.5" strokeLinecap="round" />
											</svg>
										</div>
									</div>
								</div>
								<div className="flex-1 overflow-y-auto no-scrollbar scrollbar-none mb-4 px-6 min-h-[65vh]">
									<div className="shadow-md rounded-lg overflow-hidden">
										{filteredVendorOptionsForSheet.length > 0 ? (
											<div className="space-y-0">
												{filteredVendorOptionsForSheet.map((v) => (
													<button
														key={v.id}
														type="button"
														onClick={() => {
															setAddForm((p) => ({ ...p, vendorId: v.id }));
															setShowVendorPicker(false);
															setVendorPickerQuery('');
														}}
														className={`w-full px-[16px] flex items-center gap-3 transition-colors ${String(addForm.vendorId) === String(v.id) ? 'bg-[#FFF9E6]' : 'hover:bg-[#F5F5F5]'}`}
														style={{ minHeight: '44px', maxHeight: '44px', height: '44px' }}
													>
														<p className="text-[12px] font-medium text-black text-left">{v.name}</p>
													</button>
												))}
											</div>
										) : (
											<div className="flex flex-col items-center justify-center py-4">
												<p className="text-[14px] font-medium text-[#9E9E9E] text-center">
													{vendorPickerQuery ? 'No options found' : 'No options available'}
												</p>
											</div>
										)}
									</div>
								</div>
							</div>
						</div>
					)}
				</div>
			)}

			{/* Received Date picker (same as ToolsTracker wheel modal) */}
			<div className="bpt-received-date-picker">
				<style>{`
					/* Keep the date picker overlay above the app header/tabs (don't let header float above it) */
					.bpt-received-date-picker .fixed.inset-0.z-50 { z-index: 1200 !important; }
				`}</style>
				<DatePickerModal
					isOpen={showReceivedDatePicker}
					onClose={() => setShowReceivedDatePicker(false)}
					onConfirm={(formattedDate) => {
						setAddForm((p) => ({ ...p, receivedDate: formattedDate }));
						setShowReceivedDatePicker(false);
					}}
					initialDate={getReceivedDateInitialForModal()}
				/>
			</div>
		</div>
	);
};

export default PendingBillMobile;

