import React, { useState } from 'react';

const AMCTab = ({ username, userRoles = [] }) => {
    

    return (
        <div className="bg-white rounded-lg shadow-sm">
            
        </div>
    );
};

export default AMCTab;
