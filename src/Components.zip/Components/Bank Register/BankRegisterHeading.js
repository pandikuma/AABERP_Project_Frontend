import React, { useState, useEffect } from 'react'
import '../Heading.css';
import BillPayment from './BillPayment';
import BankRegister6View from './BankRegisterPayments';
import BankRegisterHistory from './BankRegisterHistory';
import BankRegisterReconcile from './BankRegisterReconcile';

const BANK_REGISTER_MODULE_TABS = ['billpayment', 'bankregister6', 'bankregisterhistory', 'bankregisterreconcile'];
const BANK_REGISTER_DEFAULT_TAB = 'billpayment';

const getInitialBankRegisterTab = () => {
    const savedTab = localStorage.getItem('activePaintTab');
    if (savedTab && BANK_REGISTER_MODULE_TABS.includes(savedTab)) {
        return savedTab;
    }
    return BANK_REGISTER_DEFAULT_TAB;
};

const BankRegisterHeading = ({ username, userRoles = [] }) => {
    const [activeTab, setActiveTab] = useState(() => getInitialBankRegisterTab());
    const [visitedTabs, setVisitedTabs] = useState(() => new Set([getInitialBankRegisterTab()]));

    useEffect(() => {
        localStorage.setItem('activePaintTab', activeTab);
    }, [activeTab]);

    useEffect(() => {
        setVisitedTabs((prev) => new Set(prev).add(activeTab));
    }, [activeTab]);

    return (
        <div className="bg-[#FAF6ED] bank-register-heading-scope">
            <div className="topbar-title expense-entry-tabs w-full max-w-full overflow-x-auto no-scrollbar">
                <h2
                    className={`link whitespace-nowrap ${activeTab === 'billpayment' ? 'active' : ''}`}
                    onClick={() => setActiveTab('billpayment')}
                >
                    Bank Payment
                </h2>
                <h2
                    className={`link whitespace-nowrap ${activeTab === 'bankregister6' ? 'active' : ''}`}
                    onClick={() => setActiveTab('bankregister6')}
                >
                    Bank Payments
                </h2>
                <h2
                    className={`link whitespace-nowrap ${activeTab === 'bankregisterhistory' ? 'active' : ''}`}
                    onClick={() => setActiveTab('bankregisterhistory')}
                >
                    History
                </h2>
                <h2
                    className={`link whitespace-nowrap ${activeTab === 'bankregisterreconcile' ? 'active' : ''}`}
                    onClick={() => setActiveTab('bankregisterreconcile')}
                >
                    Reconcile
                </h2>
            </div>
            <div className="content">
                {visitedTabs.has('billpayment') && (
                    <div className={activeTab === 'billpayment' ? '' : 'hidden'}>
                        <BillPayment username={username} userRoles={userRoles} />
                    </div>
                )}
                {visitedTabs.has('bankregister6') && (
                    <div className={activeTab === 'bankregister6' ? '' : 'hidden'}>
                        <BankRegister6View />
                    </div>
                )}
                {visitedTabs.has('bankregisterhistory') && (
                    <div className={activeTab === 'bankregisterhistory' ? '' : 'hidden'}>
                        <BankRegisterHistory />
                    </div>
                )}
                {visitedTabs.has('bankregisterreconcile') && (
                    <div className={activeTab === 'bankregisterreconcile' ? '' : 'hidden'}>
                        <BankRegisterReconcile />
                    </div>
                )}
            </div>
        </div>
    )
}

export default BankRegisterHeading
