import React, { useState, createContext, useContext } from 'react';
import Select from 'react-select';
import DateRangePicker from './DateRangePicker';
import CustomDateField from './CustomDateField';
import edit from '../Images/Edit.svg';
import history from '../Images/History.svg';
import remove from '../Images/Delete.svg';
import CalendarIcon from '../Images/Calendoricon.png';

export const BLANK_VALUE = 'BLANK';
const BLANK_LABEL = 'Blank';
export const blankOption = { value: BLANK_VALUE, label: BLANK_LABEL };

const noop = () => {};

const TableContext = createContext(null);

export function TableProvider({ value, children }) {
    return (
        <TableContext.Provider value={value}>
            {children}
        </TableContext.Provider>
    );
}

export function buildEntryCheckTableContext({
    currentItems,
    showFilters,
    filterRowRef,
    totalAmount,
    timestampStartDate,
    setTimestampStartDate,
    timestampEndDate,
    setTimestampEndDate,
    showTimestampDateRangePicker,
    setShowTimestampDateRangePicker,
    selectedExpenseDate,
    setSelectedExpenseDate,
    projectNameOptions,
    selectedSiteName,
    setSelectedSiteName,
    vendorOptions,
    selectedVendor,
    setSelectedVendor,
    contractorOptions,
    selectedContractor,
    setSelectedContractor,
    selectedQuantity,
    setSelectedQuantity,
    selectedDescription,
    setSelectedDescription,
    categoryOptions,
    selectedCategory,
    setSelectedCategory,
    accountTypeOptions,
    selectedAccountType,
    setSelectedAccountType,
    branchFilterOptions,
    selectedBranch,
    setSelectedBranch,
    enoOptions,
    selectedEno,
    setSelectedEno,
    customStyles,
    formatDate,
    formatDateOnly,
    getBranchName,
    billArrivalFilterRef,
}) {
    const normalizedAccountTypeOptions = Array.isArray(accountTypeOptions) && accountTypeOptions.length > 0 && typeof accountTypeOptions[0] === 'string'
        ? accountTypeOptions.map((type) => ({ value: type, label: type }))
        : accountTypeOptions;

    return {
        currentItems,
        showFilters,
        filterRowRef,
        totalAmount,
        sortField: null,
        sortDirection: 'asc',
        handleSort: noop,
        timestampStartDate,
        setTimestampStartDate,
        timestampEndDate,
        setTimestampEndDate,
        showDateRangePicker: showTimestampDateRangePicker,
        setShowDateRangePicker: setShowTimestampDateRangePicker,
        selectedDate: selectedExpenseDate,
        setSelectedDate: setSelectedExpenseDate,
        siteOptions: projectNameOptions,
        selectedSiteName,
        setSelectedSiteName,
        vendorOptions,
        selectedVendor,
        setSelectedVendor,
        contractorOptions,
        selectedContractor,
        setSelectedContractor,
        staffOptions: [],
        selectedStaff: '',
        setSelectedStaff: noop,
        selectedQuantity,
        setSelectedQuantity,
        selectedDescription,
        setSelectedDescription,
        categoryOptions,
        selectedCategory,
        setSelectedCategory,
        accountTypeOptions: normalizedAccountTypeOptions,
        selectedAccountType,
        setSelectedAccountType,
        machineToolsOptions: [],
        selectedMachineTools: '',
        setSelectedMachineTools: noop,
        sourceOptions: [],
        selectedSource: '',
        setSelectedSource: noop,
        branchFilterOptions,
        selectedBranch,
        setSelectedBranch,
        enteredByOptions: [],
        selectedEnteredBy: '',
        setSelectedEnteredBy: noop,
        enoOptions,
        selectedEno,
        setSelectedEno,
        selectedBillArrival: '',
        setSelectedBillArrival: noop,
        billArrivalFilterRef,
        setBillArrivalCalendarPos: noop,
        setShowBillArrivalCalendar: noop,
        customStyles,
        formatDate,
        formatDateOnly,
        getDisplaySiteName: (expense) => expense.siteName,
        getDisplayVendorName: (expense) => expense.vendor,
        getDisplayContractorName: (expense) => expense.contractor,
        getDisplayStaffName: () => '',
        getMachineToolsItemIdDisplay: () => '',
        getBranchName,
        formatBillArrivalDisplay: () => '',
        handleEditClick: noop,
        handleDelete: noop,
        fetchAuditDetails: noop,
        username: '',
    };
}

export function Table({ showActivityColumn = true }) {
    const [expandedCells, setExpandedCells] = useState({});
    const toggleExpandedCell = (cellKey) => {
        setExpandedCells((prev) => ({
            ...prev,
            [cellKey]: !prev[cellKey],
        }));
    };

    const {
        currentItems,
        showFilters,
        filterRowRef,
        totalAmount,
        sortField,
        sortDirection,
        handleSort,
        timestampStartDate,
        setTimestampStartDate,
        timestampEndDate,
        setTimestampEndDate,
        showDateRangePicker,
        setShowDateRangePicker,
        selectedDate,
        setSelectedDate,
        siteOptions,
        selectedSiteName,
        setSelectedSiteName,
        vendorOptions,
        selectedVendor,
        setSelectedVendor,
        contractorOptions,
        selectedContractor,
        setSelectedContractor,
        staffOptions,
        selectedStaff,
        setSelectedStaff,
        selectedQuantity,
        setSelectedQuantity,
        selectedDescription,
        setSelectedDescription,
        categoryOptions,
        selectedCategory,
        setSelectedCategory,
        accountTypeOptions,
        selectedAccountType,
        setSelectedAccountType,
        machineToolsOptions,
        selectedMachineTools,
        setSelectedMachineTools,
        sourceOptions,
        selectedSource,
        setSelectedSource,
        branchFilterOptions,
        selectedBranch,
        setSelectedBranch,
        enteredByOptions,
        selectedEnteredBy,
        setSelectedEnteredBy,
        enoOptions,
        selectedEno,
        setSelectedEno,
        selectedBillArrival,
        setSelectedBillArrival,
        billArrivalFilterRef,
        setBillArrivalCalendarPos,
        setShowBillArrivalCalendar,
        customStyles,
        formatDate,
        formatDateOnly,
        getDisplaySiteName,
        getDisplayVendorName,
        getDisplayContractorName,
        getDisplayStaffName,
        getMachineToolsItemIdDisplay,
        getBranchName,
        formatBillArrivalDisplay,
        handleEditClick,
        handleDelete,
        fetchAuditDetails,
        username,
    } = useContext(TableContext);

    return (
        <table className="table-fixed w-full min-w-[1920px] border-collapse">
            <thead className="sticky top-0 z-10 bg-white ">
                <tr className="bg-[#FAF6ED] h-[40px] text-[16px] font-bold text-center">
                    <th className="pl-[12px] w-[178px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('timestamp')}>
                        Timestamp {sortField === 'timestamp' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="w-[120px] pr-[1px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('date')}>
                        Date {sortField === 'date' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[298px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('siteName')}>
                        Project Name {sortField === 'siteName' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[218px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('vendor')}>
                        Vendor Name {sortField === 'vendor' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[218px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('contractor')}>
                        Contractor Name {sortField === 'contractor' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[218px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('staff')}>
                        Staff Name {sortField === 'staff' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[78px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('quantity')}>
                        Quantity {sortField === 'quantity' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[120px] font-bold text-right cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('amount')}>
                        Amount {sortField === 'amount' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[9px] pr-[1px] w-[198px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('comments')}>
                        Description {sortField === 'comments' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[158px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('category')}>
                        Category {sortField === 'category' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[158px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('machineTools')}>
                        Machine Tools {sortField === 'machineTools' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[158px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('accountType')}>
                        A/C Type {sortField === 'accountType' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[120px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('paymentMode')}>
                        Mode {sortField === 'paymentMode' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[158px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('source')}>
                        Source From {sortField === 'source' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[158px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('branch')}>
                        Branch {sortField === 'branch' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[158px] font-bold text-left cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('enteredBy')}>
                        Entered By {sortField === 'enteredBy' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[120px] font-bold text-right cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('eno')}>
                        Entry No {sortField === 'eno' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="pl-[1px] pr-[1px] w-[120px] font-bold text-right cursor-pointer hover:bg-gray-200 select-none" onClick={() => handleSort('billArrivalDate')}>
                        Bill Arrival {sortField === 'billArrivalDate' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    {showActivityColumn && (
                        <th className="pl-[9px] pr-[1px] w-[70px] font-bold text-center">Activity</th>
                    )}
                    <th className="pl-[6px] pr-[12px] w-[70px] font-bold text-center">File</th>
                </tr>
                {showFilters && (
                    <tr ref={filterRowRef} className="bg-[#eeeeee] h-[40px]">
                        <th className="">
                            <div className="relative pl-[10px] [&>button]:!border-2 [&>button]:!border-[rgba(191,152,83,0.2)] [&>button]:!rounded-lg [&>button]:!shadow-none [&>button:hover]:!border-[rgba(191,152,83,0.4)] [&>button:focus]:!outline-none [&>button:focus]:!ring-0 [&>button:focus]:!shadow-[0_0_0_1px_rgba(191,152,83,0.4)] [&>button:focus-visible]:!outline-none [&>button:focus-visible]:!ring-0 [&>button:focus-visible]:!shadow-[0_0_0_1px_rgba(191,152,83,0.4)]">
                                <button
                                    type="button"
                                    onClick={() => setShowDateRangePicker(true)}
                                    className="w-[158px] box-border h-[36px] pl-[12px] pr-[3px] py-0 text-sm font-normal bg-white text-left flex items-center justify-between"
                                >
                                    <span className={`text-[14px] font-medium truncate flex-1 text-left ${timestampStartDate && timestampEndDate ? 'text-black font-normal' : 'text-[#A6A5A6] font-normal'}`}>
                                        {timestampStartDate ? (timestampEndDate ? `${timestampStartDate} – ${timestampEndDate}` : `From ${timestampStartDate}`) : 'Timestamp'}
                                    </span>
                                    <img src={CalendarIcon} alt="Calendar" className="w-[16px] h-[16px] text-gray-400 flex-shrink-0 mr-[6px] ml-[3px]" />
                                </button>
                                <DateRangePicker
                                    isOpen={showDateRangePicker}
                                    onClose={() => setShowDateRangePicker(false)}
                                    startDate={timestampStartDate}
                                    endDate={timestampEndDate}
                                    variant="dropdown"
                                    onApply={(from, to) => {
                                        setTimestampStartDate(from);
                                        setTimestampEndDate(to);
                                    }}
                                />
                            </div>
                        </th>
                        <th className=" pr-[1px]">
                            <div className="w-[120px]">
                                <CustomDateField
                                    value={selectedDate}
                                    onChange={setSelectedDate}
                                    placeholder="Date"
                                    alwaysOpenBelow
                                    className={` [&>button]:!border-2 [&>button]:!border-[rgba(191,152,83,0.2)] [&>button]:!rounded-lg [&>button]:!shadow-none [&>button]:!text-[14px] ${selectedDate ? '[&>button]:!text-black [&>button]:!font-normal' : '[&>button]:!text-[#d3d5db] [&>button]:!font-normal'} [&>button:hover]:!border-[rgba(191,152,83,0.4)] [&>button:focus]:!outline-none [&>button:focus]:!ring-0 [&>button:focus]:!shadow-[0_0_0_1px_rgba(191,152,83,0.4)] [&>button:focus-visible]:!outline-none [&>button:focus-visible]:!ring-0 [&>button:focus-visible]:!shadow-[0_0_0_1px_rgba(191,152,83,0.4)]`}
                                />
                            </div>
                        </th>
                        <th className="pl-[1px] pr-[1px]">
                            <Select
                                className="w-[298px]"
                                options={siteOptions}
                                value={selectedSiteName ? (selectedSiteName === BLANK_VALUE ? blankOption : { value: selectedSiteName, label: selectedSiteName }) : null}
                                onChange={(selectedOption) => setSelectedSiteName(selectedOption ? selectedOption.value : '')}
                                placeholder="Project Name"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={customStyles}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px]">
                            <Select
                                className="w-[218px]"
                                options={vendorOptions}
                                value={selectedVendor ? (selectedVendor === BLANK_VALUE ? blankOption : { value: selectedVendor, label: selectedVendor }) : null}
                                onChange={(selectedOption) => setSelectedVendor(selectedOption ? selectedOption.value : '')}
                                placeholder="Vendor Name"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={customStyles}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px]">
                            <Select
                                className="w-[218px]"
                                options={contractorOptions}
                                value={selectedContractor ? (selectedContractor === BLANK_VALUE ? blankOption : { value: selectedContractor, label: selectedContractor }) : null}
                                onChange={(selectedOption) => setSelectedContractor(selectedOption ? selectedOption.value : '')}
                                placeholder="Contractor Name"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={customStyles}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px]">
                            <Select
                                className="w-[218px]"
                                options={staffOptions}
                                value={selectedStaff ? (selectedStaff === BLANK_VALUE ? blankOption : { value: selectedStaff, label: selectedStaff }) : null}
                                onChange={(selectedOption) => setSelectedStaff(selectedOption ? selectedOption.value : '')}
                                placeholder="Staff Name"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={customStyles}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px]">
                            <input
                                type="text"
                                value={selectedQuantity}
                                onChange={(e) => setSelectedQuantity(e.target.value)}
                                placeholder="Quantity"
                                className="w-[78px] h-[36px] box-border rounded-lg border-2 border-[rgba(191,152,83,0.2)] bg-white px-2 text-[14px] font-normal text-black placeholder:text-[#A6A5A6] outline-none hover:border-[rgba(191,152,83,0.4)] focus:border-[rgba(191,152,83,0.4)] focus:shadow-[0_0_0_1px_rgba(191,152,83,0.4)]"
                            />
                        </th>
                        <th className="text-[14px] w-[120px] text-right font-bold ">
                            ₹{Number(totalAmount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </th>
                        <th className="pl-[9px] pr-[1px]">
                            <input
                                type="text"
                                value={selectedDescription}
                                onChange={(e) => setSelectedDescription(e.target.value)}
                                placeholder="Description"
                                className="w-[190px] h-[36px] box-border rounded-lg border-2 border-[rgba(191,152,83,0.2)] bg-white px-3 text-[14px] font-normal text-black placeholder:text-[#A6A5A6] outline-none hover:border-[rgba(191,152,83,0.4)] focus:border-[rgba(191,152,83,0.4)] focus:shadow-[0_0_0_1px_rgba(191,152,83,0.4)]"
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px]">
                            <Select
                                className="w-[158px]"
                                options={categoryOptions}
                                value={selectedCategory ? (selectedCategory === BLANK_VALUE ? blankOption : { value: selectedCategory, label: selectedCategory }) : null}
                                onChange={(selectedOption) => setSelectedCategory(selectedOption ? selectedOption.value : '')}
                                placeholder="Category"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={customStyles}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px]">
                            <Select
                                className="w-[158px]"
                                options={machineToolsOptions}
                                value={selectedMachineTools ? machineToolsOptions.find(opt => opt.value === String(selectedMachineTools)) : null}
                                onChange={(selectedOption) => setSelectedMachineTools(selectedOption ? selectedOption.value : '')}
                                placeholder="Machine Tools"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={customStyles}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px]">
                            <Select
                                className="w-[158px]"
                                options={accountTypeOptions}
                                value={selectedAccountType ? { value: selectedAccountType, label: selectedAccountType } : null}
                                onChange={(selectedOption) => setSelectedAccountType(selectedOption ? selectedOption.value : '')}
                                placeholder="A/C Type"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={customStyles}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px]"></th>
                        <th className="pl-[1px] pr-[1px]">
                            <Select
                                className="w-[158px]"
                                options={sourceOptions}
                                value={selectedSource ? (selectedSource === BLANK_VALUE ? blankOption : { value: selectedSource, label: selectedSource }) : null}
                                onChange={(selectedOption) => setSelectedSource(selectedOption ? selectedOption.value : '')}
                                placeholder="Source From"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={customStyles}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px]">
                            <Select
                                className="w-[158px]"
                                options={branchFilterOptions}
                                value={selectedBranch ? branchFilterOptions.find(opt => opt.value === String(selectedBranch)) : null}
                                onChange={(selectedOption) => setSelectedBranch(selectedOption ? selectedOption.value : '')}
                                placeholder="Branch"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={customStyles}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px]">
                            <Select
                                className="w-[158px]"
                                options={enteredByOptions}
                                value={selectedEnteredBy ? (selectedEnteredBy === BLANK_VALUE ? blankOption : { value: selectedEnteredBy, label: selectedEnteredBy }) : null}
                                onChange={(selectedOption) => setSelectedEnteredBy(selectedOption ? selectedOption.value : '')}
                                placeholder="Entered By"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={customStyles}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px] text-right">
                            <Select
                                className="w-[120px]"
                                options={enoOptions.map((eno) => (String(eno) === BLANK_VALUE ? blankOption : { value: String(eno), label: String(eno) }))}
                                value={selectedEno ? (String(selectedEno) === BLANK_VALUE ? blankOption : { value: String(selectedEno), label: String(selectedEno) }) : null}
                                onChange={(selectedOption) => setSelectedEno(selectedOption ? selectedOption.value : '')}
                                placeholder="Entry No"
                                menuPlacement="bottom"
                                noOptionsMessage={() => null}
                                styles={{
                                    ...customStyles,
                                    control: (provided, state) => ({
                                        ...(typeof customStyles.control === 'function' ? customStyles.control(provided, state) : provided),
                                        textAlign: 'right',
                                    }),
                                    valueContainer: (provided) => ({
                                        ...(typeof customStyles.valueContainer === 'function' ? customStyles.valueContainer(provided) : provided),
                                        justifyContent: 'flex-end',
                                        paddingLeft: '2px',
                                        paddingRight: '12px',
                                    }),
                                    singleValue: (provided) => ({
                                        ...(typeof customStyles.singleValue === 'function' ? customStyles.singleValue(provided) : provided),
                                        textAlign: 'right',
                                    }),
                                    input: (provided) => ({
                                        ...(typeof customStyles.input === 'function' ? customStyles.input(provided) : provided),
                                        textAlign: 'right',
                                    }),
                                    placeholder: (provided) => ({
                                        ...(typeof customStyles.placeholder === 'function' ? customStyles.placeholder(provided) : provided),
                                        textAlign: 'right',
                                    }),
                                    option: (provided, state) => ({
                                        ...(typeof customStyles.option === 'function' ? customStyles.option(provided, state) : provided),
                                        textAlign: 'right',
                                        justifyContent: 'flex-end',
                                        paddingRight: '12px',
                                    }),
                                }}
                            />
                        </th>
                        <th className="pl-[1px] pr-[1px] text-right">
                            <div
                                className="w-[98px]"
                                ref={billArrivalFilterRef}
                                onMouseDown={(e) => {
                                    if (!e.target.closest('[aria-label="Open calendar"]')) return;
                                    e.preventDefault();
                                    e.stopPropagation();
                                    const rect = billArrivalFilterRef.current?.getBoundingClientRect();
                                    if (!rect) return;
                                    setBillArrivalCalendarPos({ top: rect.bottom, left: rect.right });
                                    setShowBillArrivalCalendar(true);
                                }}
                            >
                                <CustomDateField
                                    value={selectedBillArrival}
                                    onChange={setSelectedBillArrival}
                                    placeholder="Bill Arrival"
                                    alwaysOpenBelow
                                    anchor="right"
                                    className={` [&>div:first-child]:!w-[120px] [&>div:first-child]:!h-[36px] [&>div.absolute]:!hidden [&>button]:!border-2 [&>button]:!border-[rgba(191,152,83,0.2)] [&>button]:!rounded-lg [&>button]:!shadow-none [&>button]:!text-[14px] ${selectedBillArrival ? '[&>button]:!text-black [&>button]:!font-normal' : '[&>button]:!text-[#d3d5db] [&>button]:!font-normal'} [&>button:hover]:!border-[rgba(191,152,83,0.4)] [&>button:focus]:!outline-none [&>button:focus]:!ring-0 [&>button:focus]:!shadow-[0_0_0_1px_rgba(191,152,83,0.4)] [&>button:focus-visible]:!outline-none [&>button:focus-visible]:!ring-0 [&>button:focus-visible]:!shadow-[0_0_0_1px_rgba(191,152,83,0.4)]`}
                                />
                            </div>
                        </th>
                        {showActivityColumn && <th></th>}
                        <th></th>
                    </tr>
                )}
            </thead>
            <tbody>
                {currentItems.map((expense, index) => (
                    <tr key={expense.id} className="odd:bg-white even:bg-[#FAF6ED] text-[14px] font-semibold h-[40px]">
                        <td className="pl-[12px] w-[168px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-timestamp`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-timestamp`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={formatDate(expense.timestamp)}
                            >
                                {formatDate(expense.timestamp)}
                            </span>
                        </td>
                        <td className="w-[120px] pr-[1px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-date`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-date`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={formatDateOnly(expense.date)}
                            >
                                {formatDateOnly(expense.date)}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[298px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-site`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-site`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={getDisplaySiteName(expense)}
                            >
                                {getDisplaySiteName(expense)}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[218px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-vendor`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-vendor`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={getDisplayVendorName(expense)}
                            >
                                {getDisplayVendorName(expense)}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[218px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-contractor`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-contractor`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={getDisplayContractorName(expense)}
                            >
                                {getDisplayContractorName(expense)}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[218px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-staff`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-staff`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={getDisplayStaffName(expense)}
                            >
                                {getDisplayStaffName(expense)}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[78px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-quantity`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-quantity`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={String(expense.quantity ?? '')}
                            >
                                {expense.quantity}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[98px] text-right">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-amount`)}
                                className={`block w-full cursor-pointer text-right ${expandedCells[`${expense.id ?? index}-amount`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={`₹${Number(expense.amount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                            >
                                ₹{Number(expense.amount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                        </td>
                        <td className="text-left pl-[9px] pr-[1px] w-[198px] px-1">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-comments`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-comments`]
                                    ? 'whitespace-normal break-words'
                                    : 'truncate whitespace-nowrap overflow-hidden'
                                    }`}
                                title={expense.comments || ''}
                            >
                                {expense.comments || ''}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[158px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-category`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-category`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={expense.category || ''}
                            >
                                {expense.category}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[158px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-machineTools`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-machineTools`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={getMachineToolsItemIdDisplay(expense.machineTools) || ''}
                            >
                                {getMachineToolsItemIdDisplay(expense.machineTools)}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[158px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-accountType`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-accountType`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={expense.accountType || ''}
                            >
                                {expense.accountType}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[120px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-paymentMode`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-paymentMode`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={expense.paymentMode || ''}
                            >
                                {expense.paymentMode || ''}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[158px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-source`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-source`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={expense.source || ''}
                            >
                                {expense.source}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[158px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-branch`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-branch`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={getBranchName(expense.branch_id ?? expense.branchId ?? '') || ''}
                            >
                                {getBranchName(expense.branch_id ?? expense.branchId ?? '') || ''}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[158px] text-left ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-enteredBy`)}
                                className={`block w-full cursor-pointer ${expandedCells[`${expense.id ?? index}-enteredBy`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={expense.enteredBy || 'Sivaprakasm'}
                            >
                                {expense.enteredBy || 'Sivaprakasm'}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[120px] text-right ">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-eno`)}
                                className={`block w-full cursor-pointer text-right ${expandedCells[`${expense.id ?? index}-eno`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={String(expense.eno ?? '')}
                            >
                                {expense.eno}
                            </span>
                        </td>
                        <td className="pl-[1px] pr-[1px] w-[120px] text-right whitespace-nowrap">
                            <span
                                onClick={() => toggleExpandedCell(`${expense.id ?? index}-billArrival`)}
                                className={`block w-full cursor-pointer text-right ${expandedCells[`${expense.id ?? index}-billArrival`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                                title={formatBillArrivalDisplay(expense) || ''}
                            >
                                {formatBillArrivalDisplay(expense)}
                            </span>
                        </td>
                        {showActivityColumn && (
                            <td className=" flex pl-[9px] pr-[1px] w-[70px] justify-between py-2 gap-[8px]">
                                <button onClick={() => handleEditClick(expense)} className="rounded-full transition duration-200">
                                    <img
                                        src={edit}
                                        alt="Edit"
                                        className=" w-4 h-6 transform hover:scale-110 hover:brightness-110 transition duration-200 "
                                    />
                                </button>
                                <button className="">
                                    <img
                                        src={remove}
                                        alt='delete'
                                        onClick={() => handleDelete(expense.id, username)}
                                        className='  w-4 h-4 transform hover:scale-110 hover:brightness-110 transition duration-200 ' />
                                </button>
                                <button onClick={() => fetchAuditDetails(expense.id)} className="rounded-full transition duration-200" >
                                    <img
                                        src={history}
                                        alt="history"
                                        className=" w-4 h-5 transform hover:scale-110 hover:brightness-110 transition duration-200 "
                                    />
                                </button>
                            </td>
                        )}
                        <td className="pl-[6px] pr-[12px] w-[70px] text-center">
                            {expense.billCopy ? (
                                <a
                                    href={expense.billCopy}
                                    className="text-red-500 underline "
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    View
                                </a>
                            ) : (
                                <span></span>
                            )}
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
}
