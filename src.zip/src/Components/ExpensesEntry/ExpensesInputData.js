import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { notifyOrbitModuleDataChanged } from '../../utils/orbitProjectDataSync';
import search from '../Images/search.png';
import imports from '../Images/Import.svg';
import cross from '../Images/cross.png';
import edit from '../Images/Edit.svg';
import Add from '../Images/+Add.svg';
import deleteIcon from '../Images/Delete.svg';
const DTableView = ({ username, userRoles = [] }) => {
  const [isSiteNamesOpen, setIsSiteNamesOpen] = useState(false);
  const [isMachineToolsOpen, setIsMachineToolsOpen] = useState(false);
  const [isAccountTypesOpen, setAccountTypesOpen] = useState(false);
  const [isVendorNameOpens, setIsVendorNameOpens] = useState(false);
  const [isContractorNameOpens, setContractorNameOpens] = useState(false);
  const [isEditSiteNameOpen, setIsEditSiteNameOpen] = useState(false);
  const [isEditWeeklyTypeOpen, setIsEditWeeklyTypeOpen] = useState(false);
  const [isWeeklyTypeOpen, setIsWeeklyTypeOpen] = useState(false);
  const [editSiteName, setEditSiteName] = useState('');
  const [editSiteNo, setEditSiteNo] = useState('');
  const [editVendorName, setEditVendorName] = useState('');
  const [editContractorName, setEditContractorName] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editAccountType, setEditAccountType] = useState('');
  const [editWeeklyType, setEditWeeklyType] = useState('');
  const [editMachineTool, setEditMachineTool] = useState('');
  const [isVendorEditOpen, setIsVendorEditOpen] = useState(false);
  const [isContractorEditOpen, setIsContractorEditOpen] = useState(false);
  const [isCategoriesEditOpen, setIsCategoriesEditOpen] = useState(false);
  const [isAccountTypeEditOpen, setIsAccountTypeEditOpen] = useState(false);
  const [isMachineToolsEditOpen, setIsMachineToolsEditOpen] = useState(false);
  const [isSiteNoInitialized, setIsSiteNoInitialized] = useState(false);
  const [isCategoryOpens, setIsCategoryOpens] = useState(false);
  const openSiteNames = () => setIsSiteNamesOpen(true);
  const closeSiteNames = () => setIsSiteNamesOpen(false);
  const openMachineTools = () => setIsMachineToolsOpen(true);
  const closeMachineTools = () => setIsMachineToolsOpen(false);
  const openvendorNames = () => setIsVendorNameOpens(true);
  const closevendorNames = () => setIsVendorNameOpens(false);
  const openContractorNames = () => setContractorNameOpens(true);
  const closeContractorNames = () => setContractorNameOpens(false);
  const openAccountTypes = () => setAccountTypesOpen(true);
  const closeAccountTypes = () => setAccountTypesOpen(false);
  const openWeeklyTypes = () => setIsWeeklyTypeOpen(true);
  const closeWeeklyTypes = () => setIsWeeklyTypeOpen(false);
  const openCategory = () => setIsCategoryOpens(true);
  const closeCategory = () => setIsCategoryOpens(false);
  const [file, setFile] = useState(null);
  const [siteNameSearch, setSiteNameSearch] = useState("");
  const [vendorNameSearch, setVendorNameSearch] = useState("");
  const [contractorNameSearch, setContractorNameSearch] = useState("");
  const [expensesCategorySearch, setExpensesCategorySearch] = useState("");
  const [machineToolsSearch, setMachineToolsSearch] = useState("");
  const [accountTypeSearch, setAccountTypeSearch] = useState("");
  const [weeklyTypeSearch, setWeeklyTypeSearch] = useState('');
  const [siteName, setSiteName] = useState('');
  const [machineTool, setMachineTool] = useState('');
  const [accountType, setAccountType] = useState('');
  const [vendorName, setVendorName] = useState('');
  const [weeklyType, setWeeklyType] = useState('');
  const [contractorName, setContractorName] = useState('');
  const [category, setCategory] = useState('');
  const [siteNo, setSiteNo] = useState('');
  const [siteNames, setSiteNames] = useState([]);
  const [vendorNames, setVendorNames] = useState([]);
  const [contractorNames, setContractorNames] = useState([]);
  const [expensesCategory, setExpensesCategory] = useState([]);
  const [machineToolsOptions, setMachineToolsOptions] = useState([]);
  const [expensesAccountType, setExpensesAccountType] = useState([]);
  const [weeklyTypes, setWeeklyTypes] = useState([]);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [isSiteNamesModelOpens, setIsSiteNamesModelOpens] = useState(false);
  const [isVendorNameModelOpens, setIsVendorNameModelOpens] = useState(false);
  const [isContractorNameModelOpens, setIsContractorNameModelOpens] = useState(false);
  const [isCategoryModelOpens, setIsCategoryModelOpens] = useState(false);
  const [isMachineToolsModelOpen, setIsMachineToolsModelOpen] = useState(false);
  const [isAccountTypesModelOpen, setIsAccountTypesModelOpen] = useState(false);
  const [selectedSiteId, setSelectedSiteId] = useState(null);
  const [selectedVendorId, setSelectedVendorId] = useState(null);
  const [selectedContractorId, setSelectedContractorId] = useState(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const [selectedMachineId, setSelectedMachineId] = useState(null);
  const [selectedAccountTypeId, setSelectedAccountTypeId] = useState(null);
  const [selectedWeeklyTypeId, setSelectedWeeklyTypeId] = useState(null);
  const [message, setMessage] = useState('');
  console.log(message);
  const openSiteNamesModals = () => setIsSiteNamesModelOpens(true);
  const openVendorNamesModals = () => setIsVendorNameModelOpens(true);
  const openContractorNamesModals = () => setIsContractorNameModelOpens(true);
  const openCategoryModels = () => setIsCategoryModelOpens(true);
  const openAccountTypesModels = () => setIsAccountTypesModelOpen(true);
  const closeAccountTypesModels = () => setIsAccountTypesModelOpen(false);
  const openMachineToolsModels = () => setIsMachineToolsModelOpen(true);
  const closeSiteNamesModals = () => setIsSiteNamesModelOpens(false);
  const closeVendorNamesModals = () => setIsVendorNameModelOpens(false);
  const closeContractorNamesModals = () => setIsContractorNameModelOpens(false);
  const closeCategoryModels = () => setIsCategoryModelOpens(false);
  const closeMachineToolModels = () => setIsMachineToolsModelOpen(false);
  const [userPermissions, setUserPermissions] = useState([]);
  const moduleName = "Expense Entry";
  useEffect(() => {
    const fetchUserRoles = async () => {
      try {
        const response = await axios.get("https://backendaab.in/demoAabuilderDash/api/user_roles/all");
        const allRoles = response.data;
        const userRoleNames = userRoles.map(r => r.roles);
        const matchedRoles = allRoles.filter(role =>
          userRoleNames.includes(role.userRoles)
        );
        const models = matchedRoles.flatMap(role => role.userModels || []);
        const matchedModel = models.find(role => role.models === moduleName);
        const permissions = matchedModel?.permissions?.[0]?.userPermissions || [];
        setUserPermissions(permissions);
      } catch (error) {
        console.error("Error fetching user roles:", error);
      }
    };
    if (userRoles.length > 0) {
      fetchUserRoles();
    }
  }, [userRoles]);
  const openEditSiteNamePopup = (item) => {
    setEditSiteName(item.siteName);
    setEditSiteNo(item.siteNo);
    setSelectedSiteId(item.id);
    setIsEditSiteNameOpen(true);
  };
  const closeEditSiteNamePopup = () => {
    setIsEditSiteNameOpen(false);
    setEditSiteName('');
    setEditSiteNo('');
    setSelectedSiteId(null);
  };
  const openEditVendorPopup = (item) => {
    setEditVendorName(item.vendorName);
    setSelectedVendorId(item.id);
    setIsVendorEditOpen(true);
  };
  const closeEditVendorPopup = () => {
    setIsVendorEditOpen(false);
    setEditVendorName('');
    setSelectedVendorId(null);
  };
  const openEditContractorPopup = (item) => {
    setEditContractorName(item.contractorName);
    setSelectedContractorId(item.id);
    setIsContractorEditOpen(true);
  }
  const closeEditContractorPopup = () => {
    setIsContractorEditOpen(false);
    setEditContractorName('');
    setSelectedContractorId(null);
  }
  const openEditCategoryPopup = (item) => {
    setEditCategory(item.category);
    setSelectedCategoryId(item.id);
    setIsCategoriesEditOpen(true);
  }
  const closeEditCategoryPopup = () => {
    setIsCategoriesEditOpen(false);
    setEditCategory('');
    setSelectedCategoryId('');
  }
  const openEditAccountTypePopup = (item) => {
    setEditAccountType(item.accountType);
    setSelectedAccountTypeId(item.id);
    setIsAccountTypeEditOpen(true);
  }
  const openEditWeeklyTypePopup = (item) => {
    setEditWeeklyType(item.type);
    setSelectedWeeklyTypeId(item.id)
    setIsEditWeeklyTypeOpen(true);
  }
  const closeEditAccountTypePopup = () => {
    setIsAccountTypeEditOpen(false);
    setEditAccountType('');
    setSelectedAccountTypeId('');
  }
  const closeEditWeeklyTypePopup = () => {
    setIsEditWeeklyTypeOpen(false);
    setEditWeeklyType('');
    setSelectedWeeklyTypeId('');
  }
  const openEditMachineToolsPopup = (item) => {
    setEditMachineTool(item.machineTool);
    setSelectedMachineId(item.id);
    setIsMachineToolsEditOpen(true);
  }
  const closeEditMachineToolsPopup = () => {
    setIsMachineToolsEditOpen(false);
    setEditMachineTool('');
    setSelectedMachineId('');
  }
  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };
  const handleUploadSiteNames = async () => {
    if (!file) {
      alert("Please select a file to upload.");
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      const response = await fetch("https://backendaab.in/demoAabuilderDash/api/project_Names/bulk_upload", {
        method: "POST",
        body: formData,
      });
      const result = await response.text();
      alert(result);
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("File upload failed!");
    }
    refreshAllInputData();
  };
  const handleUploadVendorNames = async () => {
    if (!file) {
      alert("Please select a file to upload.");
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      const response = await fetch("https://backendaab.in/demoAabuilderDash/api/vendor_Names/bulk_upload", {
        method: "POST",
        body: formData,
      });
      const result = await response.text();
      alert(result);
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("File upload failed!");
    }
    refreshAllInputData();
  };
  const handleUploadContractorNames = async () => {
    if (!file) {
      alert("Please select a file to upload.");
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      const response = await fetch("https://backendaab.in/demoAabuilderDash/api/contractor_Names/bulk_upload", {
        method: "POST",
        body: formData,
      });
      const result = await response.text();
      alert(result);
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("File upload failed!");
    }
    refreshAllInputData();
  };
  const handleUploadcategory = async () => {
    if (!file) {
      alert("Please select a file to upload.");
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      const response = await fetch("https://backendaab.in/demoAabuilderDash/api/expenses_categories/bulk_upload", {
        method: "POST",
        body: formData,
      });
      const result = await response.text();
      alert(result);
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("File upload failed!");
    }
    refreshAllInputData();
  };
  const handleUploadMachineTools = async () => {
    if (!file) {
      alert("Please select a file to upload.");
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      const response = await fetch("https://backendaab.in/demoAabuilderDash/api/machine_tools/bulk_upload", {
        method: "POST",
        body: formData,
      });
      const result = await response.text();
      alert(result);
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("File upload failed!");
    }
    refreshAllInputData();
  };
  const handleUploadAccountType = async () => {
    if (!file) {
      alert("Please select a file to upload.");
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      const response = await fetch("https://backendaab.in/demoAabuilderDash/api/account_type/bulk_upload", {
        method: "POST",
        body: formData,
      });
      const result = await response.text();
      alert(result);
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("File upload failed!");
    }
    refreshAllInputData();
  };
  const handleAllSiteNameDelete = async () => {
    const confirmed = window.confirm("Are you sure you want to delete all Site Names?");
    if (confirmed) {
      try {
        const response = await fetch("https://backendaab.in/demoAabuilderDash/api/project_Names/deleteAll", {
          method: "DELETE",
        });
        if (response.ok) {
          setSiteNames([]);
          alert("All site names have been deleted successfully.");
        } else {
          console.error("Failed to delete all area names. Status:", response.status);
          alert("Error deleting the area names. Please try again.");
        }
      } catch (error) {
        console.error("Error deleting all area names:", error);
        alert("An error occurred while deleting all area names.");
      }
    } else {
      console.log("Deletion cancelled.");
    }
  };
  const handleAllVendorNameDelete = async () => {
    const confirmed = window.confirm("Are you sure you want to delete all Site Names?");
    if (confirmed) {
      try {
        const response = await fetch("https://backendaab.in/demoAabuilderDash/api/vendor_Names/deleteAll", {
          method: "DELETE",
        });
        if (response.ok) {
          setVendorName([]);
          alert("All vendor names have been deleted successfully.");
        } else {
          console.error("Failed to delete all area names. Status:", response.status);
          alert("Error deleting the area names. Please try again.");
        }
      } catch (error) {
        console.error("Error deleting all area names:", error);
        alert("An error occurred while deleting all area names.");
      }
    } else {
      console.log("Deletion cancelled.");
    }
  };
  const handleAllContractorNameDelete = async () => {
    const confirmed = window.confirm("Are you sure you want to delete all Site Names?");
    if (confirmed) {
      try {
        const response = await fetch("https://backendaab.in/demoAabuilderDash/api/contractor_Names/deleteAll", {
          method: "DELETE",
        });
        if (response.ok) {
          setContractorName([]);
          alert("All contractor names have been deleted successfully.");
        } else {
          console.error("Failed to delete all area names. Status:", response.status);
          alert("Error deleting the area names. Please try again.");
        }
      } catch (error) {
        console.error("Error deleting all area names:", error);
        alert("An error occurred while deleting all area names.");
      }
    } else {
      console.log("Deletion cancelled.");
    }
  };
  const handleAllCategoryDelete = async () => {
    const confirmed = window.confirm("Are you sure you want to delete all Site Names?");
    if (confirmed) {
      try {
        const response = await fetch("https://backendaab.in/demoAabuilderDash/api/expenses_categories/deleteAll", {
          method: "DELETE",
        });
        if (response.ok) {
          setCategory([]);
          alert("All Category have been deleted successfully.");
        } else {
          console.error("Failed to delete all area names. Status:", response.status);
          alert("Error deleting the area names. Please try again.");
        }
      } catch (error) {
        console.error("Error deleting all area names:", error);
        alert("An error occurred while deleting all area names.");
      }
    } else {
      console.log("Deletion cancelled.");
    }
  };
  const handleAllMachineToolDelete = async () => {
    const confirmed = window.confirm("Are you sure you want to delete all Machine Tools?");
    if (confirmed) {
      try {
        const response = await fetch("https://backendaab.in/demoAabuilderDash/api/machine_tools/deleteAll", {
          method: "DELETE",
        });
        if (response.ok) {
          setMachineTool([]);
          alert("All Machine Tool have been deleted successfully.");
        } else {
          console.error("Failed to delete all area names. Status:", response.status);
          alert("Error deleting the area names. Please try again.");
        }
      } catch (error) {
        console.error("Error deleting all area names:", error);
        alert("An error occurred while deleting all area names.");
      }
    } else {
      console.log("Deletion cancelled.");
    }
  };
  const handleAllAccountTypes = async () => {
    const confirmed = window.confirm("Are you sure you want to delete all Machine Tools?");
    if (confirmed) {
      try {
        const response = await fetch("https://backendaab.in/demoAabuilderDash/api/account_type/deleteAll", {
          method: "DELETE",
        });
        if (response.ok) {
          setAccountType([]);
          alert("All Machine Tool have been deleted successfully.");
        } else {
          console.error("Failed to delete all area names. Status:", response.status);
          alert("Error deleting the area names. Please try again.");
        }
      } catch (error) {
        console.error("Error deleting all area names:", error);
        alert("An error occurred while deleting all area names.");
      }
    } else {
      console.log("Deletion cancelled.");
    }
  };
  const handleDeleteAllWeeklyTypes = async () => {
    const confirmed = window.confirm("Are you sure you want to delete all Machine Tools?");
    if (confirmed) {
      try {
        const response = await fetch("https://backendaab.in/demoAabuildersDash/api/weekly_types/deleteAll", {
          method: "DELETE",
        });
        if (response.ok) {
          setWeeklyTypes([]);
          alert("All Type have been deleted successfully.");
        } else {
          console.error("Failed to delete all Types. Status:", response.status);
          alert("Error deleting the Types. Please try again.");
        }
      } catch (error) {
        console.error("Error deleting all Types:", error);
        alert("An error occurred while deleting all Types.");
      }
    } else {
      console.log("Deletion cancelled.");
    }
  };
  useEffect(() => {
    fetchSiteNames();
  }, []);
  const fetchSiteNames = async () => {
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/project_Names/getAll');
      if (response.ok) {
        const data = await response.json();
        setSiteNames(data);
        console.log(data);
      } else {
        setMessage('Error fetching tile area names.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error fetching tile area names.');
    }
  };
  useEffect(() => {
    fetchVendorNames();
  }, []);
  const fetchVendorNames = async () => {
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/vendor_Names/getAll');
      if (response.ok) {
        const data = await response.json();
        setVendorNames(data);
      } else {
        setMessage('Error fetching tile area names.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error fetching tile area names.');
    }
  };
  useEffect(() => {
    fetchContractorNames();
  }, []);
  const fetchContractorNames = async () => {
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/contractor_Names/getAll');
      if (response.ok) {
        const data = await response.json();
        setContractorNames(data);
      } else {
        setMessage('Error fetching tile area names.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error fetching tile area names.');
    }
  };
  useEffect(() => {
    fetchCategories();
  }, []);
  const fetchCategories = async () => {
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/expenses_categories/getAll');
      if (response.ok) {
        const data = await response.json();
        setExpensesCategory(data);
      } else {
        setMessage('Error fetching tile area names.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error fetching tile area names.');
    }
  };
  useEffect(() => {
    fetchMachinTools();
  }, []);
  const fetchMachinTools = async () => {
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/machine_tools/getAll');
      if (response.ok) {
        const data = await response.json();
        setMachineToolsOptions(data);
      } else {
        setMessage('Error fetching tile area names.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error fetching tile area names.');
    }
  };
  useEffect(() => {
    fetchAccountType();
  }, []);
  const fetchAccountType = async () => {
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/account_type/getAll');
      if (response.ok) {
        const data = await response.json();
        setExpensesAccountType(data);
      } else {
        setMessage('Error fetching tile area names.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error fetching tile area names.');
    }
  };
  useEffect(() => {
    fetchWeeklyType();
  }, []);
  const fetchWeeklyType = async () => {
    try {
      const response = await fetch('https://backendaab.in/demoAabuildersDash/api/weekly_types/getAll');
      if (response.ok) {
        const data = await response.json();
        setWeeklyTypes(data);
      } else {
        setMessage('Error fetching tile area names.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error fetching tile area names.');
    }
  };
  const refreshAllInputData = () => {
    void fetchSiteNames();
    void fetchVendorNames();
    void fetchContractorNames();
    void fetchCategories();
    void fetchMachinTools();
    void fetchAccountType();
    void fetchWeeklyType();
    notifyOrbitModuleDataChanged('expense-entry');
  };
  const handleSubmitSiteNames = async (e) => {
    e.preventDefault();
    const newSiteNames = { siteName, siteNo };
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/project_Names/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newSiteNames),
      });
      if (response.ok) {
        setMessage('Site name saved successfully!');
        refreshAllInputData();
      } else {
        setMessage('Error saving area name.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error saving area name.');
    }
  };
  const handleSubmitMachineTools = async (e) => {
    e.preventDefault();
    const newMachineTool = { machineTool };
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/machine_tools/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newMachineTool),
      });
      if (response.ok) {
        setMessage('Area name saved successfully!');
        setMachineTool('');
        refreshAllInputData();
      } else {
        setMessage('Error saving area name.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error saving area name.');
    }
  };
  const handleSubmitAccountTypes = async (e) => {
    e.preventDefault();
    const newAccountType = { accountType };
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/account_type/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newAccountType),
      });
      if (response.ok) {
        setMessage('Account Type saved successfully!');
        setAccountType('');
        refreshAllInputData();
      } else {
        setMessage('Error saving area name.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error saving area name.');
    }
  };
  const handleSubmitWeeklyTypes = async (e) => {
    e.preventDefault();
    const newWeeklyType = { type: weeklyType };
    try {
      const response = await fetch('https://backendaab.in/demoAabuildersDash/api/weekly_types/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newWeeklyType),
      });
      if (response.ok) {
        setMessage('Weekly Type saved successfully!');
        setWeeklyType('');
        refreshAllInputData();
      } else {
        setMessage('Error saving area name.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error saving area name.');
    }
  };
  const handleSubmitVendorName = async (e) => {
    e.preventDefault();
    const newVendorName = { vendorName };
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/vendor_Names/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newVendorName),
      });
      if (response.ok) {
        setMessage('Area name saved successfully!');
        setVendorName('');
        refreshAllInputData();
      } else {
        setMessage('Error saving area name.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error saving area name.');
    }
  };
  const handleSubmitContractorName = async (e) => {
    e.preventDefault();
    const newContractorName = { contractorName };
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/contractor_Names/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newContractorName),
      });
      if (response.ok) {
        setMessage('Area name saved successfully!');
        setContractorName('');
        refreshAllInputData();
      } else {
        setMessage('Error saving area name.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error saving area name.');
    }
  };
  const handleSubmitCategory = async (e) => {
    e.preventDefault();
    const newCategory = { category };
    try {
      const response = await fetch('https://backendaab.in/demoAabuilderDash/api/expenses_categories/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newCategory),
      });
      if (response.ok) {
        setMessage('Area name saved successfully!');
        setCategory('');
        refreshAllInputData();
      } else {
        setMessage('Error saving area name.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('Error saving area name.');
    }
  };
  const handleSiteNameDelete = async (id) => {
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/project_Names/delete/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        alert("Site Name deleted successfully!!!");
        refreshAllInputData();
      } else {
        console.error("Failed to delete the site name. Status:", response.status);
        alert("Error deleting the site name. Please try again.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while deleting the Site Name.");
    }
  };
  const handleEditSiteName = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/project_Names/edit/${selectedSiteId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ siteName: editSiteName, siteNo: editSiteNo }),
      });
      if (response.ok) {
        closeEditSiteNamePopup();
        refreshAllInputData();
      } else {
        console.error('Failed to update floor name');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  const handleEditVendorName = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/vendor_Names/edit/${selectedVendorId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ vendorName: editVendorName }),
      });
      if (response.ok) {
        closeEditVendorPopup();
        refreshAllInputData();
      } else {
        console.error('Failed to update floor name');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  const handleEditContractorName = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/contractor_Names/edit/${selectedContractorId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ contractorName: editContractorName }),
      });
      if (response.ok) {
        closeEditContractorPopup();
        refreshAllInputData();
      } else {
        console.error('Failed to update floor name');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  const handleEditCategoriesName = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/expenses_categories/edit/${selectedCategoryId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ category: editCategory }),
      });
      if (response.ok) {
        closeEditCategoryPopup();
        refreshAllInputData();
      } else {
        console.error('Failed to update floor name');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  const handleEditAccountTypes = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/account_type/edit/${selectedAccountTypeId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ accountType: editAccountType }),
      });
      if (response.ok) {
        closeEditAccountTypePopup();
        refreshAllInputData();
      } else {
        console.error('Failed to update floor name');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  const handleEditWeeklyTypes = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`https://backendaab.in/demoAabuildersDash/api/weekly_types/edit/${selectedWeeklyTypeId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ type: editWeeklyType }),
      });
      if (response.ok) {
        closeEditWeeklyTypePopup();
        refreshAllInputData();
      } else {
        console.error('Failed to update floor name');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  const handleEditMachineTools = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/machine_tools/edit/${selectedMachineId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ machineTool: editMachineTool }),
      });
      if (response.ok) {
        closeEditMachineToolsPopup();
        refreshAllInputData();
      } else {
        console.error('Failed to update floor name');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  const handleVendorNameDelete = async (id) => {
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/vendor_Names/delete/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        alert("Vendor Name deleted successfully!!!");
        refreshAllInputData();
      } else {
        console.error("Failed to delete the vendor name. Status:", response.status);
        alert("Error deleting the vendor name. Please try again.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while deleting the vendor Name.");
    }
  };
  const handleContractorNameDelete = async (id) => {
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/contractor_Names/delete/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        alert("Contractor Name deleted successfully!!!");
        refreshAllInputData();
      } else {
        console.error("Failed to delete the Contractor name. Status:", response.status);
        alert("Error deleting the Contractor name. Please try again.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while deleting the Contractor Name.");
    }
  };
  const handleCategoriesDelete = async (id) => {
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/expenses_categories/delete/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        alert("Categories deleted successfully!!!");
        refreshAllInputData();
      } else {
        console.error("Failed to delete the Categories. Status:", response.status);
        alert("Error deleting the Categories. Please try again.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while deleting the Contractor Name.");
    }
  };
  const handleAccountTypeDelete = async (id) => {
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/account_type/delete/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        alert("Account Type deleted successfully!!!");
        refreshAllInputData();
      } else {
        console.error("Failed to delete the Account Type. Status:", response.status);
        alert("Error deleting the Account Type. Please try again.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while deleting the Contractor Name.");
    }
  };
  const handleWeeklyTypeDelete = async (id) => {
    try {
      const response = await fetch(`https://backendaab.in/demoAabuildersDash/api/weekly_types/delete/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        alert("Weekly Type deleted successfully!!!");
        refreshAllInputData();
      } else {
        console.error("Failed to delete the Account Type. Status:", response.status);
        alert("Error deleting the Account Type. Please try again.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while deleting the Contractor Name.");
    }
  };
  const handleMachineToolsDelete = async (id) => {
    try {
      const response = await fetch(`https://backendaab.in/demoAabuilderDash/api/machine_tools/delete/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        alert("Machine Tools deleted successfully!!!");
        refreshAllInputData();
      } else {
        console.error("Failed to delete the Machine Tools. Status:", response.status);
        alert("Error deleting the Machine Tools. Please try again.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred while deleting the Contractor Name.");
    }
  };
  const filteredSiteNames = siteNames.filter((item) =>
    item.siteName.toLowerCase().includes(siteNameSearch.toLowerCase()) ||
    item.siteNo.toLowerCase().includes(siteNameSearch.toLowerCase())
  );
  const filteredVendorNames = vendorNames.filter((item) =>
    item.vendorName.toLowerCase().includes(vendorNameSearch.toLowerCase())
  );
  const filteredContractorNames = contractorNames.filter((item) =>
    item.contractorName.toLowerCase().includes(contractorNameSearch.toLowerCase())
  );
  const filteredCategories = expensesCategory.filter((item) =>
    item.category.toLowerCase().includes(expensesCategorySearch.toLowerCase())
  );
  const filteredMachineTools = machineToolsOptions.filter((item) =>
    item.machineTool.toLowerCase().includes(machineToolsSearch.toLowerCase())
  );
  const filteredAccountType = expensesAccountType.filter((item) =>
    item.accountType.toLowerCase().includes(accountTypeSearch.toLowerCase())
  );
  const filteredWeeklyType = weeklyTypes.filter((item) =>
    item.type.toLowerCase().includes(weeklyTypeSearch.toLowerCase())
  );
  useEffect(() => {
    if (isSiteNamesOpen && !isSiteNoInitialized) {
      const lastSiteNo = Math.max(
        ...filteredSiteNames.map(item => Number(item.siteNo)).filter(n => !isNaN(n)),
        0
      );
      setSiteNo((lastSiteNo + 1).toString());
      setIsSiteNoInitialized(true); // Mark it as initialized
    }
    if (!isSiteNamesOpen) {
      setIsSiteNoInitialized(false); // Reset when popup is closed
    }
  }, [isSiteNamesOpen, filteredSiteNames]);

  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);
  const [expandedCells, setExpandedCells] = useState({});

  const toggleExpandedCell = (cellKey) => {
    setExpandedCells((prev) => ({
      ...prev,
      [cellKey]: !prev[cellKey],
    }));
  };

  const interactiveDragSelectors =
    'input, textarea, button, select, a, label, [role="button"], [contenteditable="true"], .prevent-drag-scroll';

  const shouldSkipDragScroll = (target) => {
    if (!target || typeof target.closest !== 'function') return false;
    return Boolean(target.closest(interactiveDragSelectors));
  };

  const handleMouseDown = (e) => {
    if (shouldSkipDragScroll(e.target)) {
      setIsDragging(false);
      return;
    }
    setIsDragging(true);
    setStartX(e.pageX - e.currentTarget.offsetLeft);
    setScrollLeft(e.currentTarget.scrollLeft);
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    e.preventDefault();
    const x = e.pageX - e.currentTarget.offsetLeft;
    const walk = (x - startX) * 2;
    e.currentTarget.scrollLeft = scrollLeft - walk;
  };

  const handleTouchStart = (e) => {
    if (shouldSkipDragScroll(e.target)) {
      setIsDragging(false);
      return;
    }
    setIsDragging(true);
    setStartX(e.touches[0].pageX - e.currentTarget.offsetLeft);
    setScrollLeft(e.currentTarget.scrollLeft);
  };

  const handleTouchMove = (e) => {
    if (!isDragging) return;
    e.preventDefault();
    const x = e.touches[0].pageX - e.currentTarget.offsetLeft;
    const walk = (x - startX) * 2;
    e.currentTarget.scrollLeft = scrollLeft - walk;
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  return (
    <div className='flex flex-col h-[calc(100vh-104px)] px-[18px] pt-[18px] pb-[18px] overflow-hidden bg-[#FAF6ED]'>
      <div className=" flex flex-col flex-1 min-h-0 px-[18px] pt-[18px] pb-[18px] overflow-hidden bg-white">
        <div
          className="flex-1 min-h-0 lg:flex space-x-[18px] lg:w-full md:w-[32rem] w-[20rem] overflow-x-auto overflow-y-hidden no-scrollbar scrollbar-none select-none"
          style={{ cursor: isDragging ? 'grabbing' : 'default' }}
          onMouseDown={handleMouseDown}
          onMouseLeave={handleMouseLeave}
          onMouseUp={handleMouseUp}
          onMouseMove={handleMouseMove}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          <div>
            <div className="flex items-center mb-[6px] lg:mt-0 mt-3">
              <input
                type="text"
                className=" border-[#BF9853] border-2 border-opacity-25 rounded-full text-[14px] pl-[16px] flex-1 w-44 h-[40px] focus:outline-none"
                placeholder="Project Name"
                value={siteNameSearch}
                onChange={(e) => setSiteNameSearch(e.target.value)}
              />
              <button className="-ml-8 mt-5 transform -translate-y-1/2 text-gray-500">
                <img src={search} alt='search' className=' w-5 h-5' />
              </button>
              <button className="text-black font-bold px-1 ml-4"
                onClick={openSiteNames}>
                <img src={Add} alt='add' className='w-[30px] h-[30px]' />
              </button>
            </div>
            <button onClick={openSiteNamesModals} className="text-[#E4572E] flex mb-[8px]"><img src={imports} alt='import' className=' w-6 h-5 bg-transparent pr-2 mt-[6px]' /><h1 className='mt-1.5 text-[14px] font-semibold'>Import file</h1></button>
            <div className='rounded-lg border border-gray-200 border-l-8 border-l-[#BF9853]'>
              <div className="bg-[#FAF6ED]">
                <table className="table-fixed lg:w-[340px] w-full">
                  <thead className='bg-[#FAF6ED]'>
                    <tr className="border-b h-[40px]">
                      <th className="pl-[12px] pr-[12px] text-left w-[50px] text-[16px] font-bold">P.ID</th>
                      <th className="pl-0 pr-[8px] text-left text-[16px] font-bold">
                        <div className="flex items-center justify-between gap-[12px]">
                          <span>Project Name</span>
                          <button type="button" onClick={handleAllSiteNameDelete} className="inline-flex shrink-0 items-center justify-center">
                            <img src={deleteIcon} alt='del' className='w-4 h-4' />
                          </button>
                        </div>
                      </th>
                    </tr>
                  </thead>
                </table>
              </div>
              <div className="overflow-y-auto max-h-[calc(100vh-300px)] no-scrollbar scrollbar-none scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                <table className="table-fixed lg:w-[340px] w-full">
                  <tbody>
                    {filteredSiteNames.map((item, index) => (
                      <tr key={item.id} className="border-b odd:bg-white text-[14px] even:bg-[#FAF6ED] h-[40px]">
                        <td className="pl-[12px] pr-[12px] text-left font-semibold w-[50px]">{item.siteNo}</td>
                        <td className="pl-0 pr-[8px] text-left group font-semibold max-w-0">
                          <div className="flex pr-[4px] items-center min-w-0">
                            <span
                              onClick={() => toggleExpandedCell(`${item.id}-siteName`)}
                              className={`block min-w-0 flex-1 cursor-pointer ${expandedCells[`${item.id}-siteName`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                              title={item.siteName}
                            >
                              {item.siteName}
                            </span>
                          <div className="flex shrink-0 space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 ">
                            <button type="button" >
                              <img src={edit} alt="add" className="w-4 h-4" type="button" onClick={() => openEditSiteNamePopup(item)} />
                            </button>
                            <button >
                              <img src={deleteIcon} alt="delete" className="w-4 h-4" onClick={() => handleSiteNameDelete(item.id)} />
                            </button>
                          </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div>
            <div className="flex items-center mb-[6px] lg:mt-0 mt-3">
              <input
                type="text"
                className=" border-[#BF9853] border-2 border-opacity-25 rounded-full text-[14px] pl-[16px] flex-1 w-44 h-[40px] focus:outline-none"
                placeholder="Vendor Name"
                value={vendorNameSearch}
                onChange={(e) => setVendorNameSearch(e.target.value)}
              />
              <button className="-ml-8 mt-5 transform -translate-y-1/2 text-gray-500">
                <img src={search} alt='search' className=' w-5 h-5' />
              </button>
              <button className="text-black font-bold px-1 ml-4"
                onClick={openvendorNames}>
                <img src={Add} alt='add' className='w-[30px] h-[30px]' />
              </button>
            </div>
            <button onClick={openVendorNamesModals} className="text-[#E4572E] flex mb-[8px]"><img src={imports} alt='import' className=' w-6 h-5 bg-transparent pr-2 mt-[6px]' />
              <h1 className='mt-1.5  text-[14px] font-semibold'>Import file</h1>
            </button>
            <div className='rounded-lg border border-gray-200 border-l-8 border-l-[#BF9853]'>
              <div className="bg-[#FAF6ED]">
                <table className="table-auto lg:w-[320px] ">
                  <thead className='bg-[#FAF6ED]'>
                    <tr className="border-b h-[40px]">
                      <th className="pl-[12px] pr-[12px] text-left lg:w-16 text-[16px] font-bold">S.No</th>
                      <th className="pl-0 pr-[8px] text-left lg:w-72 text-[16px] font-bold">
                        <div className="flex items-center justify-between gap-[12px]">
                          <span>Vendor Name</span>
                          <button type="button" onClick={handleAllVendorNameDelete} className="inline-flex shrink-0 items-center justify-center">
                            <img src={deleteIcon} alt='del' className='w-4 h-4' />
                          </button>
                        </div>
                      </th>
                    </tr>
                  </thead>
                </table>
              </div>
              <div className="overflow-y-auto max-h-[calc(100vh-300px)] no-scrollbar scrollbar-none scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                <table className="table-fixed lg:w-[320px] w-full">
                  <tbody>
                    {filteredVendorNames.map((item, index) => (
                      <tr key={item.id} className="border-b odd:bg-white text-[14px] even:bg-[#FAF6ED] h-[40px]">
                        <td className="pl-[12px] pr-[12px] text-left font-semibold w-[64px]">
                          {(vendorNames.findIndex(v => v.id === item.id) + 1).toString().padStart(2, '0')}
                        </td>
                        <td className="pl-0 pr-[8px] text-left group font-semibold max-w-0">
                          <div className="flex items-center min-w-0">
                            <span
                              onClick={() => toggleExpandedCell(`${item.id}-vendorName`)}
                              className={`block min-w-0 flex-1 cursor-pointer ${expandedCells[`${item.id}-vendorName`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                              title={item.vendorName}
                            >
                              {item.vendorName}
                            </span>
                          <div className="flex shrink-0 space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 ">
                            <button type="button" >
                              <img src={edit} alt="add" className="w-4 h-4" type="button" onClick={() => openEditVendorPopup(item)} />
                            </button>
                            <button >
                              <img src={deleteIcon} alt="delete" className="w-4 h-4" onClick={() => handleVendorNameDelete(item.id)} />
                            </button>
                          </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div>
            <div className="flex items-center mb-[6px] lg:mt-0 mt-3">
              <input
                type="text"
                className=" border-[#BF9853] border-2 border-opacity-25 rounded-full text-[14px] pl-[16px] flex-1 w-44 h-[40px] focus:outline-none"
                placeholder="Contractor Name"
                value={contractorNameSearch}
                onChange={(e) => setContractorNameSearch(e.target.value)}
              />
              <button className="-ml-8 mt-5 transform -translate-y-1/2 text-gray-500">
                <img src={search} alt='search' className=' w-5 h-5' />
              </button>
              <button className="text-black font-bold px-1 ml-4"
                onClick={openContractorNames}>
                <img src={Add} alt='add' className='w-[30px] h-[30px]' />
              </button>
            </div>
            <button onClick={openContractorNamesModals} className="text-[#E4572E] flex mb-[8px]"><img src={imports} alt='import' className=' w-6 h-5 bg-transparent pr-2 mt-[6px]' /><h1 className='mt-1.5 text-[14px] font-semibold'>Import file</h1></button>
            <div className='rounded-lg border border-gray-200 border-l-8 border-l-[#BF9853]'>
              <div className="bg-[#FAF6ED]">
                <table className="table-auto lg:w-[320px] ">
                  <thead className='bg-[#FAF6ED]'>
                    <tr className="border-b h-[40px]">
                      <th className="pl-[12px] pr-[12px] text-left lg:w-16 text-[16px] font-bold">S.No</th>
                      <th className="pl-0 pr-[8px] text-left lg:w-72 text-[16px] font-bold">
                        <div className="flex items-center justify-between gap-[12px]">
                          <span>Contractor Name</span>
                          <button type="button" onClick={handleAllContractorNameDelete} className="inline-flex shrink-0 items-center justify-center">
                            <img src={deleteIcon} alt='del' className='w-4 h-4' />
                          </button>
                        </div>
                      </th>
                    </tr>
                  </thead>
                </table>
              </div>
              <div className="overflow-y-auto max-h-[calc(100vh-300px)] no-scrollbar scrollbar-none scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                <table className="table-fixed lg:w-[320px] w-full">
                  <tbody>
                    {filteredContractorNames.map((item, index) => (
                      <tr key={item.id} className="border-b odd:bg-white text-[14px] even:bg-[#FAF6ED] h-[40px]">
                        <td className="pl-[12px] pr-[12px] text-left font-semibold w-[64px]">{(contractorNames.findIndex(c => c.id === item.id) + 1).toString().padStart(2, '0')}</td>
                        <td className="pl-0 pr-[8px] text-left group font-semibold max-w-0">
                          <div className="flex items-center min-w-0">
                            <span
                              onClick={() => toggleExpandedCell(`${item.id}-contractorName`)}
                              className={`block min-w-0 flex-1 cursor-pointer ${expandedCells[`${item.id}-contractorName`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                              title={item.contractorName}
                            >
                              {item.contractorName}
                            </span>
                          <div className="flex shrink-0 space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 ">
                            <button type="button" >
                              <img src={edit} alt="add" className="w-4 h-4" type="button" onClick={() => openEditContractorPopup(item)} />
                            </button>
                            <button >
                              <img src={deleteIcon} alt="delete" className="w-4 h-4" onClick={() => handleContractorNameDelete(item.id)} />
                            </button>
                          </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div>
            <div className="flex items-center mb-[6px] lg:mt-0 mt-3">
              <input
                type="text"
                className=" border-[#BF9853] border-2 border-opacity-25 rounded-full text-[14px] pl-[16px] flex-1 w-44 h-[40px] focus:outline-none"
                placeholder="Category"
                value={expensesCategorySearch}
                onChange={(e) => setExpensesCategorySearch(e.target.value)}
              />
              <button className="-ml-8 mt-5 transform -translate-y-1/2 text-gray-500">
                <img src={search} alt='search' className=' w-5 h-5' />
              </button>
              <button className="text-black font-bold px-1 ml-4"
                onClick={openCategory}>
                <img src={Add} alt='add' className='w-[30px] h-[30px]' />
              </button>
            </div>
            <button onClick={openCategoryModels} className="text-[#E4572E] flex mb-[8px]"><img src={imports} alt='import' className=' w-6 h-5 bg-transparent pr-2 mt-[6px]' /><h1 className='mt-1.5 text-[14px] font-semibold'>Import file</h1></button>
            <div className='rounded-lg border border-gray-200 border-l-8 border-l-[#BF9853]'>
              <div className="bg-[#FAF6ED]">
                <table className="table-auto lg:w-[280px] ">
                  <thead className='bg-[#FAF6ED]'>
                    <tr className="border-b h-[40px]">
                      <th className="pl-[12px] pr-[12px] text-left lg:w-16 text-[16px] font-bold">S.No</th>
                      <th className="pl-[0px] pr-[8px] text-left lg:w-72 text-[16px] font-bold">
                        <div className="flex items-center justify-between gap-[12px]">
                          <span>Category</span>
                          <button type="button" onClick={handleAllCategoryDelete} className="inline-flex shrink-0 items-center justify-center">
                            <img src={deleteIcon} alt='del' className='w-4 h-4' />
                          </button>
                        </div>
                      </th>
                    </tr>
                  </thead>
                </table>
              </div>
              <div className="overflow-y-auto max-h-[calc(100vh-300px)] no-scrollbar scrollbar-none scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                <table className="table-fixed lg:w-[280px] w-full">
                  <tbody>
                    {filteredCategories.map((item, index) => (
                      <tr key={item.id} className="border-b odd:bg-white text-[14px] even:bg-[#FAF6ED] h-[40px]">
                        <td className="pl-[12px] pr-[12px] text-left font-semibold w-[64px]">{(expensesCategory.findIndex(c => c.id === item.id) + 1).toString().padStart(2, '0')}</td>
                        <td className="pl-[0px] pr-[8px] text-left group font-semibold max-w-0">
                          <div className="flex items-center min-w-0">
                            <span
                              onClick={() => toggleExpandedCell(`${item.id}-category`)}
                              className={`block min-w-0 flex-1 cursor-pointer ${expandedCells[`${item.id}-category`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                              title={item.category}
                            >
                              {item.category}
                            </span>
                          <div className="flex shrink-0 space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 ">
                            <button type="button" >
                              <img src={edit} alt="add" className="w-4 h-4" type="button" onClick={() => openEditCategoryPopup(item)} />
                            </button>
                            <button >
                              <img src={deleteIcon} alt="delete" className="w-4 h-4" onClick={() => handleCategoriesDelete(item.id)} />
                            </button>
                          </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div>
            <div className="flex items-center mb-[6px] lg:mt-0 mt-3">
              <input
                type="text"
                className=" border-[#BF9853] border-2 border-opacity-25 rounded-full text-[14px] pl-[16px] flex-1 w-44 h-[40px] focus:outline-none"
                placeholder="Machine Tools"
                value={machineToolsSearch}
                onChange={(e) => setMachineToolsSearch(e.target.value)}
              />
              <button className="-ml-8 mt-5 transform -translate-y-1/2 text-gray-500">
                <img src={search} alt='search' className=' w-5 h-5' />
              </button>
              <button className="text-black font-bold px-1 ml-4"
                onClick={openMachineTools}>
                <img src={Add} alt='add' className='w-[30px] h-[30px]' />
              </button>
            </div>
            <button onClick={openMachineToolsModels} className="text-[#E4572E] flex mb-[8px]"><img src={imports} alt='import' className=' w-6 h-5 bg-transparent pr-2 mt-[6px]' /><h1 className='mt-1.5 text-[14px] font-semibold'>Import file</h1></button>
            <div className='rounded-lg border border-gray-200 border-l-8 border-l-[#BF9853]'>
              <div className="bg-[#FAF6ED]">
                <table className="table-auto lg:w-[280px] ">
                  <thead className='bg-[#FAF6ED]'>
                    <tr className="border-b h-[40px]">
                      <th className="pl-[12px] pr-[12px] text-left lg:w-16 text-[16px] font-bold">S.No</th>
                      <th className="pl-[0px] pr-[8px] text-left lg:w-72 text-[16px] font-bold">
                        <div className="flex items-center justify-between gap-[12px]">
                          <span>Machine Tools</span>
                          <button type="button" onClick={handleAllMachineToolDelete} className="inline-flex shrink-0 items-center justify-center">
                            <img src={deleteIcon} alt='del' className='w-4 h-4' />
                          </button>
                        </div>
                      </th>
                    </tr>
                  </thead>
                </table>
              </div>
              <div className="overflow-y-auto max-h-[calc(100vh-300px)] no-scrollbar scrollbar-none scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                <table className="table-fixed lg:w-[280px] w-full">
                  <tbody>
                    {filteredMachineTools.map((item, index) => (
                      <tr key={item.id} className="border-b odd:bg-white text-[14px] even:bg-[#FAF6ED] h-[40px]">
                        <td className="pl-[12px] pr-[12px] text-left font-semibold w-[64px]">{(machineToolsOptions.findIndex(tool => tool.id === item.id) + 1).toString().padStart(2, '0')}</td>
                        <td className="pl-[0px] pr-[8px] text-left group font-semibold max-w-0">
                          <div className="flex items-center min-w-0">
                            <span
                              onClick={() => toggleExpandedCell(`${item.id}-machineTool`)}
                              className={`block min-w-0 flex-1 cursor-pointer ${expandedCells[`${item.id}-machineTool`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                              title={item.machineTool}
                            >
                              {item.machineTool}
                            </span>
                          <div className="flex shrink-0 space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 ">
                            <button type="button" >
                              <img src={edit} alt="add" className="w-4 h-4" type="button" onClick={() => openEditMachineToolsPopup(item)} />
                            </button>
                            <button >
                              <img src={deleteIcon} alt="delete" className="w-4 h-4" onClick={() => handleMachineToolsDelete(item.id)} />
                            </button>
                          </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div>
            <div className="flex items-center mb-[6px] lg:mt-0 mt-3">
              <input
                type="text"
                className=" border-[#BF9853] border-2 border-opacity-25 rounded-full text-[14px] pl-[16px] flex-1 w-44 h-[40px] focus:outline-none"
                placeholder="Account Type"
                value={accountTypeSearch}
                onChange={(e) => setAccountTypeSearch(e.target.value)}
              />
              <button className="-ml-8 mt-5 transform -translate-y-1/2 text-gray-500">
                <img src={search} alt='search' className=' w-5 h-5' />
              </button>
              <button className="text-black font-bold px-1 ml-4"
                onClick={openAccountTypes}>
                <img src={Add} alt='add' className='w-[30px] h-[30px]' />
              </button>
            </div>
            <button onClick={openAccountTypesModels} className="text-[#E4572E] flex mb-[8px]"><img src={imports} alt='import' className=' w-6 h-5 bg-transparent pr-2 mt-[6px]' /><h1 className='mt-1.5 text-[14px] font-semibold'>Import file</h1></button>
            <div className='rounded-lg border border-gray-200 border-l-8 border-l-[#BF9853]'>
              <div className="bg-[#FAF6ED]">
                <table className="table-auto lg:w-[280px] ">
                  <thead className='bg-[#FAF6ED]'>
                    <tr className="border-b h-[40px]">
                      <th className="pl-[12px] pr-[12px] text-left lg:w-16 text-[16px] font-bold">S.No</th>
                      <th className="pl-[0px] pr-[8px] text-left lg:w-72 text-[16px] font-bold">
                        <div className="flex items-center justify-between gap-[12px]">
                          <span>Account Type</span>
                          <button type="button" onClick={handleAllAccountTypes} className="inline-flex shrink-0 items-center justify-center">
                            <img src={deleteIcon} alt='del' className='w-4 h-4' />
                          </button>
                        </div>
                      </th>
                    </tr>
                  </thead>
                </table>
              </div>
              <div className="overflow-y-auto max-h-[calc(100vh-300px)] no-scrollbar scrollbar-none scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                <table className="table-fixed lg:w-[280px] w-full">
                  <tbody>
                    {filteredAccountType.map((item, index) => (
                      <tr key={item.id} className="border-b odd:bg-white text-[14px] even:bg-[#FAF6ED] h-[40px]">
                        <td className="pl-[12px] pr-[12px] text-left font-semibold w-[64px]">{(expensesAccountType.findIndex(acc => acc.id === item.id) + 1).toString().padStart(2, '0')}</td>
                        <td className="pl-[0px] pr-[8px] text-left group font-semibold max-w-0">
                          <div className="flex items-center min-w-0">
                            <span
                              onClick={() => toggleExpandedCell(`${item.id}-accountType`)}
                              className={`block min-w-0 flex-1 cursor-pointer ${expandedCells[`${item.id}-accountType`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                              title={item.accountType}
                            >
                              {item.accountType}
                            </span>
                          <div className="flex shrink-0 space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 ">
                            <button type="button" >
                              <img src={edit} alt="add" className="w-4 h-4" type="button" onClick={() => openEditAccountTypePopup(item)} />
                            </button>
                            <button >
                              <img src={deleteIcon} alt="delete" className="w-4 h-4" onClick={() => handleAccountTypeDelete(item.id)} />
                            </button>
                          </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div>
            <div className="flex items-center mb-[6px] lg:mt-0 mt-3">
              <input
                type="text"
                className=" border-[#BF9853] border-2 border-opacity-25 rounded-full text-[14px] pl-[16px] flex-1 w-44 h-[40px] focus:outline-none"
                placeholder="Type"
                value={weeklyTypeSearch}
                onChange={(e) => setWeeklyTypeSearch(e.target.value)}
              />
              <button className="-ml-8 mt-5 transform -translate-y-1/2 text-gray-500">
                <img src={search} alt='search' className=' w-5 h-5' />
              </button>
              <button className="text-black font-bold px-1 ml-4"
                onClick={openWeeklyTypes}>
                <img src={Add} alt='add' className='w-[30px] h-[30px]' />
              </button>
            </div>
            <button className="text-[#E4572E] flex mb-[8px]"><img src={imports} alt='import' className=' w-6 h-5 bg-transparent pr-2 mt-[6px]' /><h1 className='mt-[6px] text-[14px] font-semibold'>Import file</h1></button>
            <div className='rounded-lg border border-gray-200 border-l-8 border-l-[#BF9853]'>
              <div className="bg-[#FAF6ED]">
                <table className="table-auto lg:w-[280px] ">
                  <thead className='bg-[#FAF6ED]'>
                    <tr className="border-b h-[40px]">
                      <th className="pl-[12px] pr-[12px] text-left lg:w-16 text-[16px] font-bold">S.No</th>
                      <th className="pl-[0px] pr-[8px] text-left lg:w-72 text-[16px] font-bold">
                        <div className="flex items-center justify-between gap-[12px]">
                          <span>Type</span>
                          <button type="button" onClick={handleDeleteAllWeeklyTypes} className="inline-flex shrink-0 items-center justify-center">
                            <img src={deleteIcon} alt='del' className='w-4 h-4' />
                          </button>
                        </div>
                      </th>
                    </tr>
                  </thead>
                </table>
              </div>
              <div className="overflow-y-auto max-h-[calc(100vh-300px)] no-scrollbar scrollbar-none scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                <table className="table-fixed lg:w-[280px] w-full">
                  <tbody>
                    {filteredWeeklyType.map((item, index) => (
                      <tr key={item.id} className="border-b odd:bg-white text-[14px] even:bg-[#FAF6ED] h-[40px]">
                        <td className="pl-[12px] pr-[12px] text-left font-semibold w-[64px]">{(weeklyTypes.findIndex(acc => acc.id === item.id) + 1).toString().padStart(2, '0')}</td>
                        <td className="pl-[0px] pr-[8px] text-left group font-semibold max-w-0">
                          <div className="flex items-center min-w-0">
                            <span
                              onClick={() => toggleExpandedCell(`${item.id}-weeklyType`)}
                              className={`block min-w-0 flex-1 cursor-pointer ${expandedCells[`${item.id}-weeklyType`] ? 'whitespace-normal break-words' : 'truncate whitespace-nowrap overflow-hidden'}`}
                              title={item.type}
                            >
                              {item.type}
                            </span>
                          <div className="flex shrink-0 space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 ">
                            <button type="button" >
                              <img src={edit} alt="add" className="w-4 h-4" type="button" onClick={() => openEditWeeklyTypePopup(item)} />
                            </button>
                            <button >
                              <img src={deleteIcon} alt="delete" className="w-4 h-4" onClick={() => handleWeeklyTypeDelete(item.id)} />
                            </button>
                          </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        {isVendorEditOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999]" >
            <div className="bg-white rounded-md w-[30rem] h-60 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeEditVendorPopup}>
                  <img src={cross} alt='close' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleEditVendorName}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[15.5rem]">Vendor Name</label>
                  <input
                    type="text"
                    value={editVendorName}
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded-lg h-14 focus:outline-none"
                    placeholder="Enter Vendor Name"
                    onChange={(e) => setEditVendorName(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-8 ml-12">
                  <button
                    type="submit"
                    className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold"
                  >
                    Submit
                  </button>
                  <button
                    type="button"
                    className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]"
                    onClick={closeEditVendorPopup}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isEditSiteNameOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999]" >
            <div className="bg-white rounded-md w-[30rem] px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeEditSiteNamePopup}>
                  <img src={cross} alt='close' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleEditSiteName}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[17.5rem]">Site Name</label>
                  <input
                    type="text"
                    value={editSiteName}
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded-lg h-14 focus:outline-none"
                    placeholder="Enter Site Name"
                    onChange={(e) => setEditSiteName(e.target.value)}
                    required
                  />
                </div>
                <div className="mb-4 ">
                  <label className="block text-lg font-medium mb-2 -ml-[19rem]">Site No</label>
                  <input
                    type="text"
                    value={editSiteNo}
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded-lg h-14 focus:outline-none"
                    placeholder="Enter Site No"
                    onChange={(e) => setEditSiteNo(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-4 ml-12 mb-3">
                  <button
                    type="submit"
                    className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold"
                  >
                    Submit
                  </button>
                  <button
                    type="button"
                    className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]"
                    onClick={closeEditSiteNamePopup}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isContractorEditOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999]" >
            <div className="bg-white rounded-md w-[30rem] h-60 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeEditContractorPopup}>
                  <img src={cross} alt='close' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleEditContractorName}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[13.5rem]">Contractor Name</label>
                  <input
                    type="text"
                    value={editContractorName}
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded-lg h-14 focus:outline-none"
                    placeholder="Enter Contractor Name"
                    onChange={(e) => setEditContractorName(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-8 ml-12">
                  <button
                    type="submit"
                    className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold"
                  >
                    Submit
                  </button>
                  <button
                    type="button"
                    className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]"
                    onClick={closeEditContractorPopup}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isCategoriesEditOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999]" >
            <div className="bg-white rounded-md w-[30rem] h-60 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeEditCategoryPopup}>
                  <img src={cross} alt='close' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleEditCategoriesName}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[17.5rem]">Category</label>
                  <input
                    type="text"
                    value={editCategory}
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded-lg h-14 focus:outline-none"
                    placeholder="Enter Category"
                    onChange={(e) => setEditCategory(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-8 ml-12">
                  <button
                    type="submit"
                    className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold"
                  >
                    Submit
                  </button>
                  <button
                    type="button"
                    className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]"
                    onClick={closeEditCategoryPopup}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isAccountTypeEditOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999]" >
            <div className="bg-white rounded-md w-[30rem] h-60 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeEditAccountTypePopup}>
                  <img src={cross} alt='close' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleEditAccountTypes}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[15rem]">Account Type</label>
                  <input
                    type="text"
                    value={editAccountType}
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded-lg h-14 focus:outline-none"
                    placeholder="Enter Account Type"
                    onChange={(e) => setEditAccountType(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-8 ml-12">
                  <button
                    type="submit"
                    className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold"
                  >
                    Submit
                  </button>
                  <button
                    type="button"
                    className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]"
                    onClick={closeEditAccountTypePopup}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isEditWeeklyTypeOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999]" >
            <div className="bg-white rounded-md w-[30rem] h-60 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeEditWeeklyTypePopup}>
                  <img src={cross} alt='close' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleEditWeeklyTypes}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[15rem]">Type</label>
                  <input
                    type="text"
                    value={editWeeklyType}
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded-lg h-14 focus:outline-none"
                    placeholder="Enter Account Type"
                    onChange={(e) => setEditWeeklyType(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-8 ml-12">
                  <button
                    type="submit"
                    className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold"
                  >
                    Submit
                  </button>
                  <button
                    type="button"
                    className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]"
                    onClick={closeEditWeeklyTypePopup}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isMachineToolsEditOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999]" >
            <div className="bg-white rounded-md w-[30rem] h-60 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeEditMachineToolsPopup}>
                  <img src={cross} alt='close' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleEditMachineTools}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[17rem]">Machine Tools</label>
                  <input
                    type="text"
                    value={editMachineTool}
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded-lg h-14 focus:outline-none"
                    placeholder="Enter Machine Tools"
                    onChange={(e) => setEditMachineTool(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-8 ml-12">
                  <button
                    type="submit"
                    className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold"
                  >
                    Submit
                  </button>
                  <button
                    type="button"
                    className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]"
                    onClick={closeEditMachineToolsPopup}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isSiteNamesOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999] ">
            <div className="bg-white rounded-md w-[30rem] h-80 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeSiteNames}>
                  <img src={cross} alt='cross' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleSubmitSiteNames}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[17rem]">Site Name </label>
                  <input
                    type="text"
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded h-14 focus:outline-none"
                    placeholder="Enter Site Name"
                    onChange={(e) => setSiteName(e.target.value)}
                    required
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[18.5rem]">Site No </label>
                  <input
                    type="text"
                    value={siteNo}
                    onChange={(e) => setSiteNo(e.target.value)}
                    placeholder="Enter Site No"
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded h-14 focus:outline-none"
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-8 ml-12">
                  <button type="submit" className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold">
                    Submit
                  </button>
                  <button type="button" className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]" onClick={closeSiteNames}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isMachineToolsOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999] ">
            <div className="bg-white rounded-md w-[30rem] h-52 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeMachineTools}>
                  <img src={cross} alt='cross' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleSubmitMachineTools}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[15rem]">Machine Tools </label>
                  <input
                    type="text"
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded h-14 focus:outline-none"
                    placeholder="Enter Tools Name"
                    onChange={(e) => setMachineTool(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-4 ml-12">
                  <button type="submit" className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold">
                    Submit
                  </button>
                  <button type="button" className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]" onClick={closeMachineTools}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isAccountTypesOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999] ">
            <div className="bg-white rounded-md w-[30rem] h-52 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeAccountTypes}>
                  <img src={cross} alt='cross' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleSubmitAccountTypes}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-60">Account Type</label>
                  <input
                    type="text"
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded h-14 focus:outline-none"
                    placeholder="Enter Account Type"
                    onChange={(e) => setAccountType(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-4 ml-12">
                  <button type="submit" className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold">
                    Submit
                  </button>
                  <button type="button" className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]" onClick={closeAccountTypes}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isWeeklyTypeOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999] ">
            <div className="bg-white rounded-md w-[30rem] h-52 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeWeeklyTypes}>
                  <img src={cross} alt='cross' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleSubmitWeeklyTypes}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-60">Type</label>
                  <input
                    type="text"
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded h-14 focus:outline-none"
                    placeholder="Enter Type"
                    onChange={(e) => setWeeklyType(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-4 ml-12">
                  <button type="submit" className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold">
                    Submit
                  </button>
                  <button type="button" className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]" onClick={closeWeeklyTypes}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isVendorNameOpens && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999] ">
            <div className="bg-white rounded-md w-[30rem] h-52 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closevendorNames}>
                  <img src={cross} alt='cross' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleSubmitVendorName}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[16rem]">Vendor Name</label>
                  <input
                    type="text"
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded h-14 focus:outline-none"
                    placeholder="Enter Vendor Name"
                    onChange={(e) => setVendorName(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-4 ml-12">
                  <button type="submit" className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold">
                    Submit
                  </button>
                  <button type="button" className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]" onClick={closevendorNames}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isContractorNameOpens && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999] ">
            <div className="bg-white rounded-md w-[30rem] h-52 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeContractorNames}>
                  <img src={cross} alt='cross' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleSubmitContractorName}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-[13.5rem]">Contractor Name</label>
                  <input
                    type="text"
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded h-14 focus:outline-none"
                    placeholder="Enter Contractor Name"
                    onChange={(e) => setContractorName(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-4 ml-12">
                  <button type="submit" className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold">
                    Submit
                  </button>
                  <button type="button" className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]" onClick={closeContractorNames}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {isCategoryOpens && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[9999] ">
            <div className="bg-white rounded-md w-[30rem] h-52 px-2 py-2">
              <div>
                <button className="text-red-500 ml-[95%]" onClick={closeCategory}>
                  <img src={cross} alt='cross' className='w-5 h-5' />
                </button>
              </div>
              <form onSubmit={handleSubmitCategory}>
                <div className="mb-4">
                  <label className="block text-lg font-medium mb-2 -ml-72">Category</label>
                  <input
                    type="text"
                    className="w-96 ml-4 border border-[#FAF6ED] border-r-[0.25rem] border-l-[0.25rem] border-b-[0.25rem] border-t-[0.25rem] p-2 rounded h-14 focus:outline-none"
                    placeholder="Enter Category"
                    onChange={(e) => setCategory(e.target.value)}
                    required
                  />
                </div>
                <div className="flex space-x-2 mt-4 ml-12">
                  <button type="submit" className="btn bg-[#BF9853] text-white px-8 py-2 rounded-lg hover:bg-yellow-800 font-semibold">
                    Submit
                  </button>
                  <button type="button" className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853]" onClick={closeCategory}>
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
        {confirmDelete && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-[9999]">
            <div className="bg-white p-4 rounded">
              <h2>Confirm Deletion</h2>
              <p>Are you sure you want to delete this tile?</p>
              <div className="flex space-x-4">
                <button className="bg-red-500 text-white p-2 rounded">
                  Yes, Delete
                </button>
                <button className="bg-gray-300 p-2 rounded">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
        <ModalSiteName
          isOpen={isSiteNamesModelOpens}
          onClose={closeSiteNamesModals}
          onFileChange={handleFileChange}
          onUpload={handleUploadSiteNames}
        />
        <ModalVendorName
          isOpen={isVendorNameModelOpens}
          onClose={closeVendorNamesModals}
          onFileChange={handleFileChange}
          onUpload={handleUploadVendorNames}
        />
        <ModalContractorName
          isOpen={isContractorNameModelOpens}
          onClose={closeContractorNamesModals}
          onFileChange={handleFileChange}
          onUpload={handleUploadContractorNames}
        />
        <ModalCategory
          isOpen={isCategoryModelOpens}
          onClose={closeCategoryModels}
          onFileChange={handleFileChange}
          onUpload={handleUploadcategory}
        />
        <ModalMachineTools
          isOpen={isMachineToolsModelOpen}
          onClose={closeMachineToolModels}
          onFileChange={handleFileChange}
          onUpload={handleUploadMachineTools}
        />
        <ModalAccountTypes
          isOpen={isAccountTypesModelOpen}
          onClose={closeAccountTypesModels}
          onFileChange={handleFileChange}
          onUpload={handleUploadAccountType}
        />
      </div>
    </div>
  );
};
export default DTableView;
function ModalSiteName({ isOpen, onClose, onFileChange, onUpload }) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]">
      <div className="bg-white p-5 rounded-lg text-center w-96 shadow-lg">
        <h2 className="mb-4 text-xl text-gray-800">Upload Bulk Data</h2>
        <div className="mb-5">
          <input
            type="file"
            onChange={onFileChange}
            accept=".csv, .sql"
            className="w-full p-3 mb-4 border border-gray-300 rounded-md"
          />
          <div className="flex justify-between">
            <button
              onClick={onUpload}
              className="px-8 py-2 bg-[#BF9853] text-white rounded-lg cursor-pointer  transition-colors"
            >
              Upload
            </button>
            <button
              onClick={onClose}
              className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853] transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
function ModalVendorName({ isOpen, onClose, onFileChange, onUpload }) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]">
      <div className="bg-white p-5 rounded-lg text-center w-96 shadow-lg">
        <h2 className="mb-4 text-xl text-gray-800">Upload Bulk Data</h2>
        <div className="mb-5">
          <input
            type="file"
            onChange={onFileChange}
            accept=".csv, .sql"
            className="w-full p-3 mb-4 border border-gray-300 rounded-md"
          />
          <div className="flex justify-between">
            <button
              onClick={onUpload}
              className="px-8 py-2 bg-[#BF9853] text-white rounded-lg cursor-pointer  transition-colors"
            >
              Upload
            </button>
            <button
              onClick={onClose}
              className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853] transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
function ModalContractorName({ isOpen, onClose, onFileChange, onUpload }) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]">
      <div className="bg-white p-5 rounded-lg text-center w-96 shadow-lg">
        <h2 className="mb-4 text-xl text-gray-800">Upload Bulk Data</h2>
        <div className="mb-5">
          <input
            type="file"
            onChange={onFileChange}
            accept=".csv, .sql"
            className="w-full p-3 mb-4 border border-gray-300 rounded-md"
          />
          <div className="flex justify-between">
            <button
              onClick={onUpload}
              className="px-8 py-2 bg-[#BF9853] text-white rounded-lg cursor-pointer  transition-colors"
            >
              Upload
            </button>
            <button
              onClick={onClose}
              className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853] transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
function ModalCategory({ isOpen, onClose, onFileChange, onUpload }) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]">
      <div className="bg-white p-5 rounded-lg text-center w-96 shadow-lg">
        <h2 className="mb-4 text-xl text-gray-800">Upload Bulk Data</h2>
        <div className="mb-5">
          <input
            type="file"
            onChange={onFileChange}
            accept=".csv, .sql"
            className="w-full p-3 mb-4 border border-gray-300 rounded-md"
          />
          <div className="flex justify-between">
            <button
              onClick={onUpload}
              className="px-8 py-2 bg-[#BF9853] text-white rounded-lg cursor-pointer  transition-colors"
            >
              Upload
            </button>
            <button
              onClick={onClose}
              className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853] transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
function ModalMachineTools({ isOpen, onClose, onFileChange, onUpload }) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]">
      <div className="bg-white p-5 rounded-lg text-center w-96 shadow-lg">
        <h2 className="mb-4 text-xl text-gray-800">Upload Bulk Data</h2>
        <div className="mb-5">
          <input
            type="file"
            onChange={onFileChange}
            accept=".csv, .sql"
            className="w-full p-3 mb-4 border border-gray-300 rounded-md"
          />
          <div className="flex justify-between">
            <button
              onClick={onUpload}
              className="px-8 py-2 bg-[#BF9853] text-white rounded-lg cursor-pointer  transition-colors"
            >
              Upload
            </button>
            <button
              onClick={onClose}
              className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853] transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
function ModalAccountTypes({ isOpen, onClose, onFileChange, onUpload }) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]">
      <div className="bg-white p-5 rounded-lg text-center w-96 shadow-lg">
        <h2 className="mb-4 text-xl text-gray-800">Upload Bulk Data</h2>
        <div className="mb-5">
          <input
            type="file"
            onChange={onFileChange}
            accept=".csv, .sql"
            className="w-full p-3 mb-4 border border-gray-300 rounded-md"
          />
          <div className="flex justify-between">
            <button
              onClick={onUpload}
              className="px-8 py-2 bg-[#BF9853] text-white rounded-lg cursor-pointer  transition-colors"
            >
              Upload
            </button>
            <button
              onClick={onClose}
              className="px-8 py-2 border rounded-lg text-[#BF9853] border-[#BF9853] transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}