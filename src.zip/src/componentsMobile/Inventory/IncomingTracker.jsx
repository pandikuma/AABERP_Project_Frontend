import React, { useState, useEffect, useRef } from 'react';
import SearchableDropdown from '../PurchaseOrder/SearchableDropdown';
import SelectVendorModal from '../PurchaseOrder/SelectVendorModal';
import DatePickerModal from '../PurchaseOrder/DatePickerModal';
import Filter from '../Images/Filter.png'
import Close from '../Images/close.png'
import Edit from '../Images/edit1.png';
import Search from '../Images/Search.png'
import { getIncomingTrackerPrefetchCache } from './incomingTrackerPrefetch';
import { fetchUserModulePermissions } from '../utils/fetchUserModulePermissions';

const IncomingTracker = ({ user, onTabChange }) => {
  // Prevent whole-page scroll; keep only inner containers scrollable
  useEffect(() => {
    const prevBodyOverflow = document.body.style.overflow;
    const prevHtmlOverflow = document.documentElement.style.overflow;

    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';

    return () => {
      document.body.style.overflow = prevBodyOverflow;
      document.documentElement.style.overflow = prevHtmlOverflow;
    };
  }, []);

  // Resolve module permissions (Create/Edit/Delete) for mobile create actions.
  const [modulePermissions, setModulePermissions] = useState([]);
  useEffect(() => {
    const moduleName = 'Inventory';
    const resolvedUserRoles =
      user?.userRoles ||
      (() => {
        try {
          const stored = JSON.parse(localStorage.getItem('user') || '{}');
          return stored?.userRoles || [];
        } catch {
          return [];
        }
      })();

    fetchUserModulePermissions(resolvedUserRoles, moduleName)
      .then(setModulePermissions)
      .catch(() => setModulePermissions([]));
  }, [user?.userRoles]);

  const canCreate = modulePermissions.includes('Create');
  const canEdit = modulePermissions.includes('Edit');

  const [activeStatus, setActiveStatus] = useState('live'); // 'live', 'closed', or 'history'
  const [incomingRecords, setIncomingRecords] = useState([]);
  const [filteredRecords, setFilteredRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [vendorData, setVendorData] = useState([]);
  const [siteData, setSiteData] = useState([]);
  const [allPurchaseOrders, setAllPurchaseOrders] = useState([]);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [showDetailView, setShowDetailView] = useState(false);
  const [poItemName, setPoItemName] = useState([]);
  const [poBrand, setPoBrand] = useState([]);
  const [poModel, setPoModel] = useState([]);
  const [poType, setPoType] = useState([]);
  const [categoryOptions, setCategoryOptions] = useState([]);
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [filterCategory, setFilterCategory] = useState('');
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [filterDate, setFilterDate] = useState(() => new Date().toLocaleDateString('en-GB'));
  const [selectedLiveCardId, setSelectedLiveCardId] = useState(null);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [filterVendorName, setFilterVendorName] = useState('');
  const [filterStockingLocation, setFilterStockingLocation] = useState('');
  const [filterPONo, setFilterPONo] = useState('');
  const [showVendorDropdown, setShowVendorDropdown] = useState(false);
  const [showLocationDropdown, setShowLocationDropdown] = useState(false);
  const [swipeStates, setSwipeStates] = useState({});
  const [expandedClosedCardId, setExpandedClosedCardId] = useState(null);
  /** Sync coordinates on touch (React state updates too late for first touchmove). */
  const swipeTrackRef = useRef({});
  const expandedClosedCardIdRef = useRef(null);
  const trackerCardRefs = useRef({});
  /** After a horizontal mouse drag on Live cards, block the synthetic click so selection does not toggle. */
  const suppressLiveCardClickRef = useRef(false);
  const finalizeIncomingTrackerSwipeRef = useRef(() => {});
  const pointerSwipeRef = useRef({ activeRecordId: null, pointerId: null, startX: 0, startY: 0, currentX: 0, currentY: 0 });

  /** Left drag past this (px) locks the row open so Edit stays visible & clickable. */
  const minSwipeOpenPx = 16;
  /** Right-drag to collapse when row is already open */
  const minSwipeDistance = 32;

  useEffect(() => {
    expandedClosedCardIdRef.current = expandedClosedCardId;
  }, [expandedClosedCardId]);

  const activeStatusRef = useRef(activeStatus);
  useEffect(() => {
    activeStatusRef.current = activeStatus;
  }, [activeStatus]);

  const openEditForRow = (recordId) => {
    // keep ref in sync immediately (render uses state, but handlers rely on ref)
    expandedClosedCardIdRef.current = recordId;
    setExpandedClosedCardId(recordId);
  };

  const closeEditForRow = (recordId) => {
    if (expandedClosedCardIdRef.current === recordId) {
      expandedClosedCardIdRef.current = null;
    }
    setExpandedClosedCardId(null);
  };

  const handlePointerDown = (e, recordId) => {
    if (!e) return;
    // Left mouse only for mouse pointers
    if (e.pointerType === 'mouse' && e.button !== 0) return;

    try {
      e.currentTarget?.setPointerCapture?.(e.pointerId);
    } catch (_) {
      // ignore
    }

    pointerSwipeRef.current = {
      activeRecordId: recordId,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      currentX: e.clientX,
      currentY: e.clientY,
    };

    // Seed swipe state so UI can animate immediately
    setSwipeStates(prev => ({
      ...prev,
      [recordId]: {
        startX: e.clientX,
        startY: e.clientY,
        currentX: e.clientX,
        currentY: e.clientY,
        isSwiping: false,
      }
    }));
  };

  const handlePointerMove = (e) => {
    const ps = pointerSwipeRef.current;
    if (!ps?.activeRecordId) return;
    if (ps.pointerId !== e.pointerId) return;

    const recordId = ps.activeRecordId;
    ps.currentX = e.clientX;
    ps.currentY = e.clientY;

    const deltaX = ps.currentX - ps.startX;
    const deltaY = Math.abs(ps.currentY - ps.startY);
    const absDeltaX = Math.abs(deltaX);
    const isExpanded = expandedClosedCardIdRef.current === recordId;

    // Only treat as swipe when it is mostly horizontal
    if (absDeltaX <= deltaY) return;

    // Lock open as soon as user swipes left enough; close only on a clear right swipe when open.
    if (deltaX < 0 && absDeltaX >= minSwipeOpenPx && !isExpanded) {
      openEditForRow(recordId);
    } else if (isExpanded && deltaX > 0 && absDeltaX >= minSwipeDistance) {
      closeEditForRow(recordId);
    }

    // Prevent the browser from selecting text / dragging images while swiping
    if (e.cancelable) e.preventDefault();

    setSwipeStates(prev => ({
      ...prev,
      [recordId]: {
        ...(prev[recordId] || {}),
        startX: ps.startX,
        startY: ps.startY,
        currentX: ps.currentX,
        currentY: ps.currentY,
        isSwiping: true,
      }
    }));
  };

  const handlePointerUpOrCancel = (e) => {
    const ps = pointerSwipeRef.current;
    if (!ps?.activeRecordId) return;
    if (ps.pointerId !== e.pointerId) return;

    const recordId = ps.activeRecordId;
    const deltaX = ps.currentX - ps.startX;
    const deltaY = Math.abs(ps.currentY - ps.startY);
    const absDeltaX = Math.abs(deltaX);

    // If it was a real horizontal drag, suppress the click on Live cards
    if (activeStatusRef.current === 'live' && absDeltaX > 8 && absDeltaX >= deltaY * 0.55) {
      suppressLiveCardClickRef.current = true;
    }

    // If user swiped left enough and it isn't open yet, open it (do NOT auto-close on release).
    if (deltaX < 0 && absDeltaX >= minSwipeOpenPx && expandedClosedCardIdRef.current !== recordId) {
      openEditForRow(recordId);
    }
    // If user swiped right enough while open, close it.
    if (expandedClosedCardIdRef.current === recordId && deltaX > 0 && absDeltaX >= minSwipeDistance) {
      closeEditForRow(recordId);
    }

    pointerSwipeRef.current = { activeRecordId: null, pointerId: null, startX: 0, startY: 0, currentX: 0, currentY: 0 };

    // Clear transient swipe tracking state (keep expandedClosedCardId)
    setSwipeStates(prev => {
      const next = { ...prev };
      delete next[recordId];
      return next;
    });
  };

  // Hydrate from prefetched in-memory cache (if available) to avoid waiting on network.
  useEffect(() => {
    const cached = getIncomingTrackerPrefetchCache();
    if (Array.isArray(cached?.vendors) && vendorData.length === 0) setVendorData(cached.vendors);
    if (Array.isArray(cached?.sites) && siteData.length === 0) setSiteData(cached.sites);
    if (Array.isArray(cached?.purchaseOrders) && allPurchaseOrders.length === 0) setAllPurchaseOrders(cached.purchaseOrders);
    if (Array.isArray(cached?.poItemNames) && poItemName.length === 0) setPoItemName(cached.poItemNames);
    if (Array.isArray(cached?.poBrands) && poBrand.length === 0) setPoBrand(cached.poBrands);
    if (Array.isArray(cached?.poModels) && poModel.length === 0) setPoModel(cached.poModels);
    if (Array.isArray(cached?.poTypes) && poType.length === 0) setPoType(cached.poTypes);
    if (Array.isArray(cached?.poCategories) && categoryOptions.length === 0) {
      const options = (cached.poCategories || []).map(item => ({
        value: item.category || item.categoryName || item.name || '',
        label: item.category || item.categoryName || item.name || '',
        id: item.id || item._id || null,
      }));
      setCategoryOptions(options);
    }
  }, []);
  const getRecordDate = (entry) => new Date(entry?.date || entry?.created_at || entry?.createdAt || 0).getTime();
  const getLatestEntry = (record) => {
    const entries = Array.isArray(record?.mergedEntries) && record.mergedEntries.length > 0
      ? record.mergedEntries
      : [record];
    return entries.reduce((latest, current) => {
      return getRecordDate(current) > getRecordDate(latest) ? current : latest;
    }, entries[0]);
  };
  const handleClosedCardSwipeStart = (event, recordId) => {
    const touch = event.touches ? event.touches[0] : { clientX: event.clientX, clientY: event.clientY };
    const startY = touch.clientY || event.clientY || 0;
    const g = {
      startX: touch.clientX,
      startY,
      currentX: touch.clientX,
      currentY: startY,
      isSwiping: false,
    };
    swipeTrackRef.current[recordId] = g;
    setSwipeStates(prev => ({
      ...prev,
      [recordId]: { ...g },
    }));
  };
  const handleClosedCardSwipeMove = (event, recordId) => {
    const g = swipeTrackRef.current[recordId];
    if (!g) return;
    const touch = event.touches ? event.touches[0] : { clientX: event.clientX, clientY: event.clientY };
    const currentY = touch.clientY || event.clientY || 0;
    // Always record latest pointer (release uses this for delta; otherwise currentX never moves if drag stays diagonal)
    g.currentX = touch.clientX;
    g.currentY = currentY;
    const deltaX = touch.clientX - g.startX;
    const deltaY = Math.abs(currentY - (g.startY || 0));
    const absDeltaX = Math.abs(deltaX);
    if (absDeltaX <= deltaY) return;
    const isExpanded = expandedClosedCardIdRef.current === recordId;

    // On touch: lock open as soon as we cross threshold (mobile UX)
    if (event.touches && deltaX < 0 && absDeltaX >= minSwipeOpenPx && !isExpanded) {
      openEditForRow(recordId);
    }

    // On touch: close only on an intentional right swipe when already open
    if (event.touches && isExpanded && deltaX > 0 && absDeltaX >= minSwipeDistance) {
      closeEditForRow(recordId);
    }

    if (deltaX < 0 || (isExpanded && deltaX > 0)) {
      if (event.preventDefault) {
        event.preventDefault();
      }
      g.isSwiping = true;
      setSwipeStates(prev => ({
        ...prev,
        [recordId]: {
          ...g,
          startX: g.startX,
          startY: g.startY,
          currentX: g.currentX,
          currentY: g.currentY,
          isSwiping: true,
        },
      }));
    }
  };

  const finalizeIncomingTrackerSwipe = (recordId) => {
    const state = swipeTrackRef.current[recordId];
    if (!state) return;
    const startX = state.startX;
    const startY = state.startY || 0;
    const deltaX = state.currentX - startX;
    const deltaY = Math.abs((state.currentY || 0) - startY);
    const absDeltaX = Math.abs(deltaX);
    delete swipeTrackRef.current[recordId];

    // Obvious list scroll only (long vertical, almost no horizontal)
    if (deltaY > 55 && absDeltaX < 12) {
      setSwipeStates(prev => {
        const newState = { ...prev };
        delete newState[recordId];
        return newState;
      });
      return;
    }

    if (activeStatusRef.current === 'live' && absDeltaX > 8 && absDeltaX >= deltaY * 0.55) {
      suppressLiveCardClickRef.current = true;
    }

    const isOpen = expandedClosedCardIdRef.current === recordId;

    // Requirement: once opened, it must stay open until user swipes right to close.
    if (!isOpen && deltaX < 0 && absDeltaX >= minSwipeOpenPx) {
      openEditForRow(recordId);
    } else if (isOpen && deltaX > 0 && absDeltaX >= minSwipeDistance) {
      closeEditForRow(recordId);
    }

    setSwipeStates(prev => {
      const newState = { ...prev };
      delete newState[recordId];
      return newState;
    });
  };

  finalizeIncomingTrackerSwipeRef.current = finalizeIncomingTrackerSwipe;

  const handleClosedCardSwipeEnd = (recordId) => {
    finalizeIncomingTrackerSwipe(recordId);
  };

  // Pointer events handle both mobile + desktop swipes; no global mouse/touch listeners needed.

  const handleEditIncomingRecord = (record) => {
    const latestEntry = getLatestEntry(record);
    if (!latestEntry) return;
    const inventoryItem = {
      ...latestEntry,
      isEditMode: true,
      fromHistory: true,
    };
    localStorage.setItem('editingInventory', JSON.stringify(inventoryItem));
    if (typeof onTabChange === 'function') {
      onTabChange('incoming');
    } else {
      localStorage.setItem('inventoryActiveTab', 'incoming');
    }
    setExpandedClosedCardId(null);
    setSelectedLiveCardId(null);
    window.dispatchEvent(new CustomEvent('editInventory', { detail: inventoryItem }));
  };
  useEffect(() => {
    setExpandedClosedCardId(null);
    setSwipeStates({});
    swipeTrackRef.current = {};
  }, [activeStatus]);

  // Fetch vendor data
  useEffect(() => {
    const fetchVendors = async () => {
      try {
        const response = await fetch('https://backendaab.in/demoAabuilderDash/api/vendor_Names/getAll');
        if (response.ok) {
          const data = await response.json();
          setVendorData(data);
        }
      } catch (error) {
        console.error('Error fetching vendors:', error);
      }
    };
    fetchVendors();
  }, []);

  // Fetch site data
  useEffect(() => {
    const fetchSites = async () => {
      try {
        const response = await fetch("https://backendaab.in/demoAabuilderDash/api/project_Names/getAll", {
          method: "GET",
          credentials: "include",
          headers: {
            "Content-Type": "application/json"
          }
        });
        if (response.ok) {
          const data = await response.json();
          setSiteData(data);
        }
      } catch (error) {
        console.error('Error fetching sites:', error);
      }
    };
    fetchSites();
  }, []);

  // Fetch all purchase orders
  useEffect(() => {
    const fetchPurchaseOrders = async () => {
      try {
        const response = await fetch('https://backendaab.in/demoAabuildersDash/api/purchase_orders/getAll');
        if (response.ok) {
          const data = await response.json();
          setAllPurchaseOrders(data);
        }
      } catch (error) {
        console.error('Error fetching purchase orders:', error);
      }
    };
    // Only needed for fallback frontend comparison OR when detail view needs PO context.
    // If backend provides live/closed classification, we can skip this expensive call initially.
    const resolvedVendorId = resolveVendorIdForIncomingApi?.();
    const shouldFetch =
      activeStatus === 'history' ||
      showDetailView === true ||
      resolvedVendorId === null ||
      resolvedVendorId === undefined ||
      String(resolvedVendorId).trim() === '';

    if (shouldFetch) {
      fetchPurchaseOrders();
    }
  }, [activeStatus, showDetailView, filterVendorName, user]);

  // Fetch PO item names, brands, models, types, and categories
  useEffect(() => {
    const fetchPOData = async () => {
      try {
        const [itemNamesRes, brandsRes, modelsRes, typesRes, categoriesRes] = await Promise.all([
          fetch('https://backendaab.in/demoAabuildersDash/api/po_itemNames/getAll'),
          fetch('https://backendaab.in/demoAabuildersDash/api/po_brand/getAll'),
          fetch('https://backendaab.in/demoAabuildersDash/api/po_model/getAll'),
          fetch('https://backendaab.in/demoAabuildersDash/api/po_type/getAll'),
          fetch('https://backendaab.in/demoAabuildersDash/api/po_category/getAll')
        ]);

        if (itemNamesRes.ok) {
          const data = await itemNamesRes.json();
          setPoItemName(data);
        }
        if (brandsRes.ok) {
          const data = await brandsRes.json();
          setPoBrand(data);
        }
        if (modelsRes.ok) {
          const data = await modelsRes.json();
          setPoModel(data);
        }
        if (typesRes.ok) {
          const data = await typesRes.json();
          setPoType(data);
        }
        if (categoriesRes.ok) {
          const data = await categoriesRes.json();
          const options = (data || []).map(item => ({
            value: item.category || item.categoryName || item.name || '',
            label: item.category || item.categoryName || item.name || '',
            id: item.id || item._id || null,
          }));
          setCategoryOptions(options);
        }
      } catch (error) {
        console.error('Error fetching PO data:', error);
      }
    };
    // Same idea as above: these are only needed for fallback comparison and detail rendering.
    const resolvedVendorId = resolveVendorIdForIncomingApi?.();
    const shouldFetch =
      activeStatus === 'history' ||
      showDetailView === true ||
      resolvedVendorId === null ||
      resolvedVendorId === undefined ||
      String(resolvedVendorId).trim() === '';

    if (shouldFetch) {
      fetchPOData();
    }
  }, [activeStatus, showDetailView, filterVendorName, user]);

  // Helper function to find name by ID
  const findNameById = (array, id, fieldName) => {
    if (!array || !id) return '';
    const found = array.find(item => String(item.id || item._id) === String(id));
    return found ? (found[fieldName] || found.name || '') : '';
  };

  const resolveItemName = (itemId) => {
    return findNameById(poItemName, itemId, 'itemName') || findNameById(poItemName, itemId, 'name') || '';
  };

  const resolveBrandName = (brandId) => {
    return findNameById(poBrand, brandId, 'brand') || findNameById(poBrand, brandId, 'brandName') || findNameById(poBrand, brandId, 'name') || '';
  };

  const resolveModelName = (modelId) => {
    return findNameById(poModel, modelId, 'model') || findNameById(poModel, modelId, 'modelName') || findNameById(poModel, modelId, 'name') || '';
  };

  const resolveTypeName = (typeId) => {
    return findNameById(poType, typeId, 'typeColor') || findNameById(poType, typeId, 'type') || findNameById(poType, typeId, 'typeName') || findNameById(poType, typeId, 'name') || '';
  };

  const resolveCategoryName = (categoryId) => {
    return findNameById(categoryOptions, categoryId, 'category') || findNameById(categoryOptions, categoryId, 'name') || findNameById(categoryOptions, categoryId, 'label') || '';
  };
  const resolveVendorIdForIncomingApi = () => {
    if (filterVendorName.trim()) {
      const selectedVendor = vendorData.find(
        (vendor) => (vendor.vendorName || '').toLowerCase() === filterVendorName.toLowerCase()
      );
      if (selectedVendor?.id !== undefined && selectedVendor?.id !== null) {
        return selectedVendor.id;
      }
    }
    const userVendorId = user?.vendor_id ?? user?.vendorId ?? null;
    if (userVendorId !== undefined && userVendorId !== null && String(userVendorId).trim() !== '') {
      return userVendorId;
    }
    return null;
  };
  const getIncomingEndpointByStatus = (status) => {
    const baseUrl = 'https://backendaab.in/demoAabuildersDash/api/inventory';
    if (status === 'live' || status === 'closed') {
      const vendorId = resolveVendorIdForIncomingApi();
      if (vendorId !== null && vendorId !== undefined && String(vendorId).trim() !== '') {
        const endpoint = status === 'live' ? 'getIncomingLive' : 'getIncomingClosed';
        return `${baseUrl}/${endpoint}?vendorId=${encodeURIComponent(vendorId)}`;
      }
    }
    return `${baseUrl}/getIncoming`;
  };

  // Helper function to extract numeric value from eno
  const getNumericEno = (eno) => {
    if (!eno) return 0;
    if (typeof eno === 'number') {
      return eno;
    }
    const str = String(eno);
    const match = str.match(/\d+/);
    return match ? parseInt(match[0], 10) : 0;
  };

  // Check if an incoming record has balance quantity
  const checkBalanceQuantity = (incomingRecord, poData) => {
    if (!poData || !poData.purchaseTable && !poData.purchase_table && !poData.items) {
      return false; // No PO data, consider as closed
    }
    const poItems = poData.purchaseTable || poData.purchase_table || poData.items || [];
    const inventoryItems = incomingRecord.inventoryItems || incomingRecord.inventory_items || [];
    // Create a map of inventory items by composite key
    const inventoryMap = {};
    inventoryItems.forEach(invItem => {
      const itemId = invItem.item_id || invItem.itemId || null;
      const categoryId = invItem.category_id || invItem.categoryId || null;
      const modelId = invItem.model_id || invItem.modelId || null;
      const brandId = invItem.brand_id || invItem.brandId || null;
      const typeId = invItem.type_id || invItem.typeId || null;
      const quantity = Math.abs(invItem.quantity || 0);
      if (itemId !== null && itemId !== undefined) {
        const compositeKey = `${itemId || 'null'}-${categoryId || 'null'}-${modelId || 'null'}-${brandId || 'null'}-${typeId || 'null'}`;
        inventoryMap[compositeKey] = (inventoryMap[compositeKey] || 0) + quantity;
      }
    });
    // Check each PO item for balance
    for (const poItem of poItems) {
      const poItemId = poItem.item_id || poItem.itemId || null;
      const poCategoryId = poItem.category_id || poItem.categoryId || null;
      const poModelId = poItem.model_id || poItem.modelId || null;
      const poBrandId = poItem.brand_id || poItem.brandId || null;
      const poTypeId = poItem.type_id || poItem.typeId || null;
      const poQuantity = poItem.quantity || 0;
      if (poItemId !== null && poItemId !== undefined) {
        const compositeKey = `${poItemId || 'null'}-${poCategoryId || 'null'}-${poModelId || 'null'}-${poBrandId || 'null'}-${poTypeId || 'null'}`;
        const inventoryQty = inventoryMap[compositeKey] || 0;
        const balanceQty = poQuantity - inventoryQty;
        // If there's any balance quantity, this record is "live"
        if (balanceQty > 0) {
          return true;
        }
      }
    }
    // All items are fully received
    return false;
  };
  // Fetch and process incoming records
  useEffect(() => {
    const fetchIncomingRecords = async () => {
      try {
        setLoading(true);
        const response = await fetch(getIncomingEndpointByStatus(activeStatus), {
          method: 'GET',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json'
          }
        });
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const inventoryData = await response.json();
        const apiVendorId = resolveVendorIdForIncomingApi();
        const useLiveClosedApi = (activeStatus === 'live' || activeStatus === 'closed') &&
          apiVendorId !== null &&
          apiVendorId !== undefined &&
          String(apiVendorId).trim() !== '';
        // Process each incoming record (only those with PO numbers)
        const processedRecords = await Promise.all(
          inventoryData
            .filter(record => {
              // Only process records with valid PO numbers (exclude NO_PO, empty, or null)
              const recordPurchaseNo = record.purchase_no || record.purchaseNo || record.purchase_number || '';
              const purchaseNoStr = String(recordPurchaseNo).trim();
              // Exclude empty, null, 'NO_PO', 'no_po', 'non po', 'NON PO', etc.
              return purchaseNoStr !== '' &&
                purchaseNoStr.toUpperCase() !== 'NO_PO' &&
                purchaseNoStr.toLowerCase() !== 'non po';
            })
            .map(async (record) => {
              const purchaseNo = record.purchase_no || record.purchaseNo || record.purchase_number || '';
              const poNumberStr = String(purchaseNo).replace('#', '').trim();
              let hasBalance;
              if (!useLiveClosedApi) {
                // Fallback mode (when live/closed APIs can't be used): recompute pending/closed state in frontend.
                // Find matching PO
                let poData = null;
                if (poNumberStr && allPurchaseOrders.length > 0) {
                  const targetEno = getNumericEno(poNumberStr);
                  const vendorId = record.vendor_id || record.vendorId;
                  const vendorPOs = vendorId
                    ? allPurchaseOrders.filter(p => String(p.vendor_id || p.vendorId) === String(vendorId))
                    : allPurchaseOrders;
                  const matchingPOs = vendorPOs.filter(p => {
                    const poEno = getNumericEno(p.eno || p.ENO || p.poNumber || p.po_number || '');
                    return poEno === targetEno && poEno !== 0;
                  });
                  if (matchingPOs.length > 0) {
                    // Get the most recent PO with items
                    const posWithItems = matchingPOs.filter(p => {
                      const items = p.purchaseTable || p.purchase_table || p.items || [];
                      return items.length > 0;
                    });
                    if (posWithItems.length > 0) {
                      poData = posWithItems.reduce((latest, current) => {
                        const latestId = parseInt(latest.id || latest._id || 0);
                        const currentId = parseInt(current.id || current._id || 0);
                        return currentId > latestId ? current : latest;
                      });
                    } else if (matchingPOs.length > 0) {
                      poData = matchingPOs.reduce((latest, current) => {
                        const latestId = parseInt(latest.id || latest._id || 0);
                        const currentId = parseInt(current.id || current._id || 0);
                        return currentId > latestId ? current : latest;
                      });
                    }
                  }
                }
                hasBalance = checkBalanceQuantity(record, poData);
              }
              // Get vendor name
              const vendorId = record.vendor_id || record.vendorId;
              const vendor = vendorData.find(v => v.id === vendorId);
              const vendorName = vendor ? vendor.vendorName : 'Unknown Vendor';
              // Get stocking location name
              const stockingLocationId = record.stocking_location_id || record.stockingLocationId;
              const site = siteData.find(s => s.id === stockingLocationId);
              const stockingLocation = site ? site.siteName : 'Unknown Location';
              // Calculate total items and quantity (include items with 0 quantity)
              const inventoryItems = record.inventoryItems || record.inventory_items || [];
              const numberOfItems = inventoryItems.length;
              const totalQuantity = inventoryItems.reduce((sum, item) => {
                return sum + Math.abs(item.quantity || 0);
              }, 0);
              // Calculate total amount
              const totalAmount = inventoryItems.reduce((sum, item) => {
                return sum + Math.abs(item.amount || 0);
              }, 0);
              // Format date
              const itemDate = record.date || record.created_at || record.createdAt;
              const dateObj = new Date(itemDate);
              const formattedDate = dateObj.toLocaleDateString('en-GB', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric'
              });
              const formattedTime = dateObj.toLocaleTimeString('en-GB', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: true
              });
              // Get entry number
              const entryNumber = record.eno || record.ENO || record.entry_number || record.entryNumber || record.id || '';
              // Get po_closed_status
              const poClosedStatus = record.po_closed_status || record.poClosedStatus || false;
              return {
                ...record,
                entryNumber,
                purchaseNo,
                vendorName,
                stockingLocation,
                numberOfItems,
                totalQuantity,
                totalAmount,
                formattedDate,
                formattedTime,
                hasBalance,
                poClosedStatus,
                isToday: formattedDate === new Date().toLocaleDateString('en-GB', {
                  day: '2-digit',
                  month: '2-digit',
                  year: 'numeric'
                })
              };
            })
        );
        setIncomingRecords(processedRecords);
      } catch (error) {
        console.error('Error fetching incoming records:', error);
      } finally {
        setLoading(false);
      }
    };
    // Fetch immediately on tab/filter change.
    // Vendor/site/purchase-order datasets are only for enrichment/fallback and should not block the initial list load.
    fetchIncomingRecords();
  }, [vendorData, siteData, allPurchaseOrders, activeStatus, filterVendorName, user]);
  // Function to merge records by purchase_no and vendorName
  const mergeRecords = (records) => {
    const mergedMap = {};
    records.forEach(record => {
      // Normalize purchase_no for comparison (remove #, trim, convert to string)
      const purchaseNo = String(record.purchaseNo || '').replace('#', '').trim();
      const vendorName = String(record.vendorName || '').trim();
      // Create a unique key based on purchase_no and vendorName
      // If purchase_no is different, they should NOT be merged
      const key = `${purchaseNo}_${vendorName}`;
      // Only merge if both purchase_no and vendorName match exactly
      if (!mergedMap[key]) {
        const inventoryItems = record.inventoryItems || record.inventory_items || [];
        mergedMap[key] = {
          ...record,
          mergedEntries: [record],
          totalMergedQuantity: record.totalQuantity,
          totalMergedItems: record.numberOfItems,
          totalMergedAmount: record.totalAmount,
          allInventoryItems: [...inventoryItems], // Include all items, even with 0 quantity
          earliestDate: record.date || record.created_at || record.createdAt,
          latestDate: record.date || record.created_at || record.createdAt,
        };
      } else {
        // Merge with existing record (same purchase_no AND vendorName - guaranteed by key)
        const merged = mergedMap[key];
        merged.mergedEntries.push(record);
        merged.totalMergedQuantity += record.totalQuantity;
        merged.totalMergedItems += record.numberOfItems;
        merged.totalMergedAmount += record.totalAmount;
        // Combine inventory items from all merged entries (include items with 0 quantity)
        const inventoryItems = record.inventoryItems || record.inventory_items || [];
        merged.allInventoryItems = [...(merged.allInventoryItems || []), ...inventoryItems];
        const recordDate = new Date(record.date || record.created_at || record.createdAt);
        const earliestDate = new Date(merged.earliestDate);
        const latestDate = new Date(merged.latestDate);
        if (recordDate < earliestDate) {
          merged.earliestDate = record.date || record.created_at || record.createdAt;
        }
        if (recordDate > latestDate) {
          merged.latestDate = record.date || record.created_at || record.createdAt;
        }
      }
    });
    return Object.values(mergedMap);
  };
  // Function to close PO
  const closePO = async (recordId, purchaseNo, vendorId) => {
    try {
      const response = await fetch(`https://backendaab.in/demoAabuildersDash/api/inventory/close_po/${recordId}?poClosedStatus=true`, {
        method: 'PUT',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        // Save to ClosedPORecords
        const closedBy = (user && user.username) || '';
        const timestamp = new Date().toISOString();

        if (canCreate) {
          try {
            await fetch('https://backendaab.in/demoAabuildersDash/api/closed_po_records/save', {
              method: 'POST',
              credentials: 'include',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                purchase_no: purchaseNo || '',
                vendor_id: vendorId || 0,
                closed_by: closedBy,
                timestamp: timestamp
              })
            });
          } catch (error) {
            console.error('Error saving closed PO record:', error);
            // Don't fail the whole operation if this fails
          }
        } else {
          console.warn('Skipping closed_po_records/save - user lacks Create permission');
        }
        // Refresh the incoming records
        const fetchIncomingRecords = async () => {
          try {
            setLoading(true);
            const response = await fetch(getIncomingEndpointByStatus(activeStatus), {
              method: 'GET',
              credentials: 'include',
              headers: {
                'Content-Type': 'application/json'
              }
            });

            if (!response.ok) {
              throw new Error('Network response was not ok');
            }

            const inventoryData = await response.json();
            const apiVendorId = resolveVendorIdForIncomingApi();
            const useLiveClosedApi = (activeStatus === 'live' || activeStatus === 'closed') &&
              apiVendorId !== null &&
              apiVendorId !== undefined &&
              String(apiVendorId).trim() !== '';

            const processedRecords = await Promise.all(
              inventoryData
                .filter(record => {
                  const recordPurchaseNo = record.purchase_no || record.purchaseNo || record.purchase_number || '';
                  const purchaseNoStr = String(recordPurchaseNo).trim();
                  return purchaseNoStr !== '' &&
                    purchaseNoStr.toUpperCase() !== 'NO_PO' &&
                    purchaseNoStr.toLowerCase() !== 'non po';
                })
                .map(async (record) => {
                  const purchaseNo = record.purchase_no || record.purchaseNo || record.purchase_number || '';
                  const poNumberStr = String(purchaseNo).replace('#', '').trim();

                  let hasBalance;
                  if (!useLiveClosedApi) {
                    let poData = null;
                    if (poNumberStr && allPurchaseOrders.length > 0) {
                      const targetEno = getNumericEno(poNumberStr);
                      const vendorId = record.vendor_id || record.vendorId;

                      const vendorPOs = vendorId
                        ? allPurchaseOrders.filter(p => String(p.vendor_id || p.vendorId) === String(vendorId))
                        : allPurchaseOrders;

                      const matchingPOs = vendorPOs.filter(p => {
                        const poEno = getNumericEno(p.eno || p.ENO || p.poNumber || p.po_number || '');
                        return poEno === targetEno && poEno !== 0;
                      });

                      if (matchingPOs.length > 0) {
                        const posWithItems = matchingPOs.filter(p => {
                          const items = p.purchaseTable || p.purchase_table || p.items || [];
                          return items.length > 0;
                        });

                        if (posWithItems.length > 0) {
                          poData = posWithItems.reduce((latest, current) => {
                            const latestId = parseInt(latest.id || latest._id || 0);
                            const currentId = parseInt(current.id || current._id || 0);
                            return currentId > latestId ? current : latest;
                          });
                        } else if (matchingPOs.length > 0) {
                          poData = matchingPOs.reduce((latest, current) => {
                            const latestId = parseInt(latest.id || latest._id || 0);
                            const currentId = parseInt(current.id || current._id || 0);
                            return currentId > latestId ? current : latest;
                          });
                        }
                      }
                    }

                    hasBalance = checkBalanceQuantity(record, poData);
                  }

                  const vendorId = record.vendor_id || record.vendorId;
                  const vendor = vendorData.find(v => v.id === vendorId);
                  const vendorName = vendor ? vendor.vendorName : 'Unknown Vendor';

                  const stockingLocationId = record.stocking_location_id || record.stockingLocationId;
                  const site = siteData.find(s => s.id === stockingLocationId);
                  const stockingLocation = site ? site.siteName : 'Unknown Location';

                  const inventoryItems = record.inventoryItems || record.inventory_items || [];
                  const numberOfItems = inventoryItems.length;
                  const totalQuantity = inventoryItems.reduce((sum, item) => {
                    return sum + Math.abs(item.quantity || 0);
                  }, 0);

                  const totalAmount = inventoryItems.reduce((sum, item) => {
                    return sum + Math.abs(item.amount || 0);
                  }, 0);

                  const itemDate = record.date || record.created_at || record.createdAt;
                  const dateObj = new Date(itemDate);
                  const formattedDate = dateObj.toLocaleDateString('en-GB', {
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric'
                  });
                  const formattedTime = dateObj.toLocaleTimeString('en-GB', {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                  });

                  const entryNumber = record.eno || record.ENO || record.entry_number || record.entryNumber || record.id || '';
                  const poClosedStatus = record.po_closed_status || record.poClosedStatus || false;

                  return {
                    ...record,
                    entryNumber,
                    purchaseNo,
                    vendorName,
                    stockingLocation,
                    numberOfItems,
                    totalQuantity,
                    totalAmount,
                    formattedDate,
                    formattedTime,
                    hasBalance,
                    poClosedStatus,
                    isToday: formattedDate === new Date().toLocaleDateString('en-GB', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric'
                    })
                  };
                })
            );

            setIncomingRecords(processedRecords);
            setSelectedLiveCardId(null);
          } catch (error) {
            console.error('Error refreshing incoming records:', error);
          } finally {
            setLoading(false);
          }
        };

        await fetchIncomingRecords();
      } else {
        console.error('Failed to close PO');
      }
    } catch (error) {
      console.error('Error closing PO:', error);
    }
  };

  // Filter records based on status and search
  useEffect(() => {
    let filtered = incomingRecords;
    const apiVendorId = resolveVendorIdForIncomingApi();
    const useLiveClosedApi = (activeStatus === 'live' || activeStatus === 'closed') &&
      apiVendorId !== null &&
      apiVendorId !== undefined &&
      String(apiVendorId).trim() !== '';
    // Filter by status (live/closed/history)
    if (activeStatus === 'live') {
      // First merge records with same purchase_no and vendorName
      filtered = mergeRecords(filtered);
      // Only recompute pending/closed state in fallback mode.
      if (!useLiveClosedApi) {
        // Then recalculate hasBalance for merged records and filter
        filtered = filtered.map(mergedRecord => {
          // Get PO data for the merged record (use first entry's PO data)
          const firstEntry = mergedRecord.mergedEntries?.[0] || mergedRecord;
          const purchaseNo = mergedRecord.purchaseNo || firstEntry.purchaseNo || '';
          const poNumberStr = String(purchaseNo).replace('#', '').trim();
          const vendorId = mergedRecord.vendor_id || mergedRecord.vendorId || firstEntry.vendor_id || firstEntry.vendorId;
          let poData = null;
          if (poNumberStr && allPurchaseOrders.length > 0) {
            const targetEno = getNumericEno(poNumberStr);
            const vendorPOs = vendorId
              ? allPurchaseOrders.filter(p => String(p.vendor_id || p.vendorId) === String(vendorId))
              : allPurchaseOrders;
            const matchingPOs = vendorPOs.filter(p => {
              const poEno = getNumericEno(p.eno || p.ENO || p.poNumber || p.po_number || '');
              return poEno === targetEno && poEno !== 0;
            });
            if (matchingPOs.length > 0) {
              const posWithItems = matchingPOs.filter(p => {
                const items = p.purchaseTable || p.purchase_table || p.items || [];
                return items.length > 0;
              });
              if (posWithItems.length > 0) {
                poData = posWithItems.reduce((latest, current) => {
                  const latestId = parseInt(latest.id || latest._id || 0);
                  const currentId = parseInt(current.id || current._id || 0);
                  return currentId > latestId ? current : latest;
                });
              } else if (matchingPOs.length > 0) {
                poData = matchingPOs.reduce((latest, current) => {
                  const latestId = parseInt(latest.id || latest._id || 0);
                  const currentId = parseInt(current.id || current._id || 0);
                  return currentId > latestId ? current : latest;
                });
              }
            }
          }
          // Create a merged record object with all inventory items for balance check
          const mergedRecordForBalance = {
            ...mergedRecord,
            inventoryItems: mergedRecord.allInventoryItems || mergedRecord.inventoryItems || mergedRecord.inventory_items || [],
            inventory_items: mergedRecord.allInventoryItems || mergedRecord.inventoryItems || mergedRecord.inventory_items || []
          };
          // Recalculate hasBalance based on merged totals
          const hasBalance = checkBalanceQuantity(mergedRecordForBalance, poData);
          return {
            ...mergedRecord,
            hasBalance
          };
        }).filter(record => {
          // Show records that have pending stock AND are not closed
          const hasBalance = record.hasBalance === true;
          const isNotClosed = record.poClosedStatus !== true;
          return hasBalance && isNotClosed;
        });
      }
    } else if (activeStatus === 'closed') {
      // First merge records with same purchase_no and vendorName
      filtered = mergeRecords(filtered);
      // Only recompute pending/closed state in fallback mode.
      if (!useLiveClosedApi) {
        // Then recalculate hasBalance for merged records and filter
        filtered = filtered.map(mergedRecord => {
          // Get PO data for the merged record (use first entry's PO data)
          const firstEntry = mergedRecord.mergedEntries?.[0] || mergedRecord;
          const purchaseNo = mergedRecord.purchaseNo || firstEntry.purchaseNo || '';
          const poNumberStr = String(purchaseNo).replace('#', '').trim();
          const vendorId = mergedRecord.vendor_id || mergedRecord.vendorId || firstEntry.vendor_id || firstEntry.vendorId;
          let poData = null;
          if (poNumberStr && allPurchaseOrders.length > 0) {
            const targetEno = getNumericEno(poNumberStr);
            const vendorPOs = vendorId
              ? allPurchaseOrders.filter(p => String(p.vendor_id || p.vendorId) === String(vendorId))
              : allPurchaseOrders;
            const matchingPOs = vendorPOs.filter(p => {
              const poEno = getNumericEno(p.eno || p.ENO || p.poNumber || p.po_number || '');
              return poEno === targetEno && poEno !== 0;
            });
            if (matchingPOs.length > 0) {
              const posWithItems = matchingPOs.filter(p => {
                const items = p.purchaseTable || p.purchase_table || p.items || [];
                return items.length > 0;
              });
              if (posWithItems.length > 0) {
                poData = posWithItems.reduce((latest, current) => {
                  const latestId = parseInt(latest.id || latest._id || 0);
                  const currentId = parseInt(current.id || current._id || 0);
                  return currentId > latestId ? current : latest;
                });
              } else if (matchingPOs.length > 0) {
                poData = matchingPOs.reduce((latest, current) => {
                  const latestId = parseInt(latest.id || latest._id || 0);
                  const currentId = parseInt(current.id || current._id || 0);
                  return currentId > latestId ? current : latest;
                });
              }
            }
          }
          // Create a merged record object with all inventory items for balance check
          const mergedRecordForBalance = {
            ...mergedRecord,
            inventoryItems: mergedRecord.allInventoryItems || mergedRecord.inventoryItems || mergedRecord.inventory_items || [],
            inventory_items: mergedRecord.allInventoryItems || mergedRecord.inventoryItems || mergedRecord.inventory_items || []
          };
          // Recalculate hasBalance based on merged totals
          const hasBalance = checkBalanceQuantity(mergedRecordForBalance, poData);
          return {
            ...mergedRecord,
            hasBalance
          };
        }).filter(record => {
          // Show records that either:
          // 1. Have no pending stock (hasBalance === false), OR
          // 2. Are marked as closed (po_closed_status === true)
          const hasNoBalance = record.hasBalance === false;
          const isClosed = record.poClosedStatus === true;
          return hasNoBalance || isClosed;
        });
      }
    } else if (activeStatus === 'history') {
      // History shows all records separately (no merging)
      // No additional filtering needed
    }
    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(record => {
        return (
          record.vendorName?.toLowerCase().includes(query) ||
          record.stockingLocation?.toLowerCase().includes(query) ||
          String(record.purchaseNo || record.entryNumber)?.includes(query)
        );
      });
    }
    // Filter by vendor name
    if (filterVendorName.trim()) {
      filtered = filtered.filter(record => {
        return record.vendorName?.toLowerCase() === filterVendorName.toLowerCase();
      });
    }
    // Filter by stocking location
    if (filterStockingLocation.trim()) {
      filtered = filtered.filter(record => {
        return record.stockingLocation?.toLowerCase() === filterStockingLocation.toLowerCase();
      });
    }
    // Filter by PO number
    if (filterPONo.trim()) {
      filtered = filtered.filter(record => {
        const poNo = String(record.purchaseNo || record.entryNumber || '').replace('#', '').trim();
        return poNo === filterPONo.replace('#', '').trim();
      });
    }
    // Sort by date (newest first)
    filtered.sort((a, b) => {
      const dateA = new Date(a.latestDate || a.date || a.created_at || a.createdAt);
      const dateB = new Date(b.latestDate || b.date || b.created_at || b.createdAt);
      return dateB - dateA;
    });
    setFilteredRecords(filtered);
  }, [incomingRecords, activeStatus, searchQuery, allPurchaseOrders, filterVendorName, filterStockingLocation, filterPONo, user, vendorData]);
  return (
    <div className="bg-white flex flex-col h-full overflow-hidden">
      {/* Back Button - Show when detail view is open */}
      {showDetailView && selectedRecord && (
        <div className="flex pb-[4px]">
          <button
            type="button"
            onClick={() => {
              setShowDetailView(false);
              setSelectedRecord(null);
            }}
            className="flex items-center gap-[8px] text-[14px] font-medium text-black"
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M15 18L9 12L15 6" stroke="#000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span>Back</span>
          </button>
        </div>
      )}
      {/* Date and Category Buttons - Hide when detail view is open */}
      {!showDetailView && (
        <div className="pt-[8px]">
          <div className="flex items-center justify-between pb-[8px] border-b border-[#E0E0E0]">
            {/* Date Button */}
            <button
              type="button"
              className="text-[12px] font-semibold text-black"
              onClick={() => setShowDatePicker(true)}
            >
              {filterDate || 'Date'}
            </button>
            {/* Category Button */}
            <div className="flex items-center gap-[4px]">
              <button
                type="button"
                className=" text-[12px] font-semibold text-black leading-normal cursor-pointer hover:opacity-80 transition-opacity"
                onClick={() => setShowCategoryModal(true)}
              >
                {filterCategory || 'Category'}
              </button>
              {filterCategory && (
                <button
                  type="button"
                  aria-label="Clear category"
                  title="Clear"
                  onClick={(e) => {
                    e.stopPropagation();
                    setFilterCategory('');
                  }}
                  className="w-4 h-4 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors"
                >
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9 3L3 9M3 3L9 9" stroke="#848484" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
      {/* Live/Closed/History Toggle - Always visible */}
      <div className="pb-[8px] pt-[8px]">
        <div className="flex items-center gap-[8px]">
          {/* Live/Closed/History Tabs */}
          <div className="flex bg-gray-100 items-center rounded-md h-[32px] flex-1">
            <button
              type="button"
              onClick={() => {
                setActiveStatus('live');
                setSelectedLiveCardId(null);
                setShowDetailView(false);
                setSelectedRecord(null);
                setSearchQuery('');
                setFilterVendorName('');
                setFilterStockingLocation('');
                setFilterPONo('');
              }}
              className={`flex-1 ml-[2px] h-[28px] rounded text-[12px] font-semibold leading-normal duration-1000 ease-out transition-colors ${activeStatus === 'live'
                ? 'bg-white text-black'
                : 'bg-gray-100 text-gray-600'
                }`}
            >
              Live
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveStatus('closed');
                setSelectedLiveCardId(null);
                setShowDetailView(false);
                setSelectedRecord(null);
                setSearchQuery('');
                setFilterVendorName('');
                setFilterStockingLocation('');
                setFilterPONo('');
              }}
              className={`flex-1 h-[28px] rounded text-[12px] font-semibold leading-normal transition-colors duration-1000 ease-out ${activeStatus === 'closed'
                ? 'bg-white text-black'
                : 'bg-gray-100 text-gray-600'
                }`}
            >
              Closed
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveStatus('history');
                setSelectedLiveCardId(null);
                setShowDetailView(false);
                setSelectedRecord(null);
                setSearchQuery('');
                setFilterVendorName('');
                setFilterStockingLocation('');
                setFilterPONo('');
              }}
              className={`flex-1 mr-[2px] h-[28px] rounded text-[12px] font-semibold leading-normal transition-colors duration-1000 ease-out ${activeStatus === 'history'
                ? 'bg-white text-black'
                : 'bg-gray-100 text-gray-600'
                }`}
            >
              History
            </button>
          </div>
        </div>
      </div>
      {/* Search Bar */}
      {!showDetailView && (
        <div className="">
          <div className="relative">
            <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
              <img src={Search} alt="Search" className="w-[12px] h-[12px]" />
            </div>
            <input
              type="text"
              placeholder="Search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-[40px] pl-[30px] pr-[16px] border border-gray-300 rounded-full text-[14px] bg-white focus:outline-none focus:border-gray-400"
            />
          </div>
        </div>
      )}

      {/* Filter Button */}
      {!showDetailView && (
        <div className="flex justify-between items-center gap-[4px] px-0 mt-[8px] mb-[8px] flex-shrink-0">
          <div className="flex items-center gap-[4px] min-w-0">
            <button
              type="button"
              onClick={() => setShowFilterModal(true)}
              className="flex items-center gap-[4px] px-[6px] py-[2px] flex-shrink-0"
            >
              <img src={Filter} alt="Filter" className="w-[13px] h-[11px]" />
              {!(filterVendorName || filterStockingLocation || filterPONo) && (
                <span className="text-[12px] font-medium text-black flex-shrink-0">Filter</span>
              )}
            </button>

            {(filterVendorName || filterStockingLocation || filterPONo) && (
              <div
                className="flex items-center gap-[4px] overflow-x-auto no-scrollbar scrollbar-none min-w-0 scrollbar-hide"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              >
                <div className="flex items-center gap-[4px] flex-nowrap">
                  {filterVendorName && (
                    <div className="flex items-center border px-[6px] py-[2px] rounded-full flex-shrink-0">
                      <span className="text-[11px] font-medium text-black">Vendor</span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setFilterVendorName('');
                        }}
                        className="w-4 h-4 flex items-center justify-center hover:bg-gray-300 rounded-full transition-colors"
                      >
                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M7.5 2.5L2.5 7.5M2.5 2.5L7.5 7.5" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      </button>
                    </div>
                  )}
                  {filterStockingLocation && (
                    <div className="flex items-center border px-[6px] py-[2px] rounded-full flex-shrink-0">
                      <span className="text-[11px] font-medium text-black">Stocking Location</span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setFilterStockingLocation('');
                        }}
                        className="w-4 h-4 flex items-center justify-center hover:bg-gray-300 rounded-full transition-colors"
                      >
                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M7.5 2.5L2.5 7.5M2.5 2.5L7.5 7.5" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      </button>
                    </div>
                  )}
                  {filterPONo && (
                    <div className="flex items-center border px-[6px] py-[2px] rounded-full flex-shrink-0">
                      <span className="text-[11px] font-medium text-black">PO. No</span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setFilterPONo('');
                        }}
                        className="w-4 h-4 flex items-center justify-center hover:bg-gray-300 rounded-full transition-colors"
                      >
                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M7.5 2.5L2.5 7.5M2.5 2.5L7.5 7.5" stroke="#000" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Records List */}
      <div className="flex-1 overflow-y-auto no-scrollbar scrollbar-none scrollbar-hide pb-[16px]">
        {showDetailView && selectedRecord ? (
          /* Detail View - Inline below search bar */
          <div className="bg-white flex flex-col flex-1" style={{ fontFamily: "'Manrope', sans-serif" }}>
            {/* Purchase Order Info Card */}
            <div className="flex-shrink-0 p-[8px] bg-white border border-gray-200 rounded-lg mb-2">
              <div className="space-y-2">
                <div className="flex items-start">
                  <p className="text-[12px] font-medium text-[#3f3f3f] w-[120px]">Vendor Name</p>
                  <p className="text-[12px] font-medium text-black mx-1">:</p>
                  <p className="text-[12px] font-medium text-[#a6a6a6] flex-1">{selectedRecord.vendorName}</p>
                </div>
                <div className="flex items-start">
                  <p className="text-[12px] font-medium text-[#3f3f3f] w-[120px]">Stocking Location</p>
                  <p className="text-[12px] font-medium text-black mx-1">:</p>
                  <p className="text-[12px] font-medium text-[#a6a6a6] flex-1">{selectedRecord.stockingLocation}</p>
                </div>
                <div className="flex items-start">
                  <p className="text-[12px] font-medium text-[#3f3f3f] w-[120px]">Purchase Order</p>
                  <p className="text-[12px] font-medium text-black mx-1">:</p>
                  <p className="text-[12px] font-medium text-[#a6a6a6] flex-1">#{selectedRecord.purchaseNo || selectedRecord.entryNumber}</p>
                </div>
              </div>
            </div>

            {/* Items Summary */}
            <div className="flex-shrink-0 mb-4 flex items-center gap-[8px] border-b border-[#E0E0E0] pb-[8px]">
              <p className="text-[14px] font-medium text-black">Items</p>
              <input
                type="text"
                value={selectedRecord.numberOfItems || selectedRecord.totalMergedItems || 0}
                readOnly
                className="w-[30px] h-[30px] border border-[rgba(0,0,0,0.16)] rounded-full px-[8px] text-[12px] font-medium text-black bg-gray-200 text-center"
              />
              <div className="ml-auto">
                <span className="text-[14px] font-medium text-black">Total Amount: </span>
                <span className="text-[14px] font-semibold text-[#BF9853]">
                  {(() => {
                    // Calculate total from all items (amount * quantity)
                    const receivedItems = selectedRecord.allInventoryItems || selectedRecord.inventoryItems || selectedRecord.inventory_items || [];
                    const totalAmount = receivedItems.reduce((sum, item) => {
                      const amount = Math.abs(item.amount || 0);
                      const quantity = Math.abs(item.quantity || 0);
                      return sum + (amount * quantity);
                    }, 0);
                    return `₹${totalAmount.toLocaleString('en-IN')}`;
                  })()}
                </span>
              </div>
            </div>

            {/* Items List */}
            <div className=" overflow-y-auto no-scrollbar scrollbar-none scrollbar-hide pb-[56px]" style={{ maxHeight: '400px' }}>
              {(() => {
                // First, try to use allInventoryItems/inventoryItems for received items
                const receivedItems = selectedRecord.allInventoryItems || selectedRecord.inventoryItems || selectedRecord.inventory_items || [];

                // Find the matching PO data
                let poData = null;
                if (allPurchaseOrders.length > 0) {
                  const purchaseNo = selectedRecord.purchaseNo || selectedRecord.purchase_no || '';
                  const poNumberStr = String(purchaseNo).replace('#', '').trim();
                  const targetEno = getNumericEno(poNumberStr);
                  const vendorId = selectedRecord.vendor_id || selectedRecord.vendorId;
                  const vendorPOs = vendorId
                    ? allPurchaseOrders.filter(p => String(p.vendor_id || p.vendorId) === String(vendorId))
                    : allPurchaseOrders;
                  const matchingPOs = vendorPOs.filter(p => {
                    const poEno = getNumericEno(p.eno || p.ENO || p.poNumber || p.po_number || '');
                    return poEno === targetEno && poEno !== 0;
                  });
                  if (matchingPOs.length > 0) {
                    const posWithItems = matchingPOs.filter(p => {
                      const items = p.purchaseTable || p.purchase_table || p.items || [];
                      return items.length > 0;
                    });
                    if (posWithItems.length > 0) {
                      poData = posWithItems.reduce((latest, current) => {
                        const latestId = parseInt(latest.id || latest._id || 0);
                        const currentId = parseInt(current.id || current._id || 0);
                        return currentId > latestId ? current : latest;
                      });
                    } else if (matchingPOs.length > 0) {
                      poData = matchingPOs.reduce((latest, current) => {
                        const latestId = parseInt(latest.id || latest._id || 0);
                        const currentId = parseInt(current.id || current._id || 0);
                        return currentId > latestId ? current : latest;
                      });
                    }
                  }
                }

                // Create a map of received items by composite key
                const receivedMap = {};
                receivedItems.forEach(item => {
                  const itemId = item.item_id || item.itemId || null;
                  const categoryId = item.category_id || item.categoryId || null;
                  const modelId = item.model_id || item.modelId || null;
                  const brandId = item.brand_id || item.brandId || null;
                  const typeId = item.type_id || item.typeId || null;
                  if (itemId !== null && itemId !== undefined) {
                    const compositeKey = `${itemId || 'null'}-${categoryId || 'null'}-${modelId || 'null'}-${brandId || 'null'}-${typeId || 'null'}`;
                    if (!receivedMap[compositeKey]) {
                      receivedMap[compositeKey] = [];
                    }
                    receivedMap[compositeKey].push(item);
                  }
                });

                // Get items to display: from PO if available, otherwise from received items
                const itemsToDisplay = [];
                if (poData && (poData.purchaseTable || poData.purchase_table || poData.items)) {
                  const poItems = poData.purchaseTable || poData.purchase_table || poData.items || [];
                  poItems.forEach((poItem, index) => {
                    const itemId = poItem.item_id || poItem.itemId || null;
                    const categoryId = poItem.category_id || poItem.categoryId || null;
                    const modelId = poItem.model_id || poItem.modelId || null;
                    const brandId = poItem.brand_id || poItem.brandId || null;
                    const typeId = poItem.type_id || poItem.typeId || null;
                    const compositeKey = `${itemId || 'null'}-${categoryId || 'null'}-${modelId || 'null'}-${brandId || 'null'}-${typeId || 'null'}`;
                    const receivedItemsList = receivedMap[compositeKey] || [];

                    // Get received quantity
                    let receivedQty = 0;
                    if (receivedItemsList.length > 0) {
                      receivedQty = receivedItemsList.reduce((sum, item) => sum + Math.abs(item.quantity || 0), 0);
                    }

                    // Get PO quantity
                    const poQuantity = Math.abs(poItem.quantity || 0);

                    // Use received item if available
                    if (receivedItemsList.length > 0) {
                      receivedItemsList.forEach(item => {
                        itemsToDisplay.push({
                          ...item,
                          poQuantity: poQuantity // Store PO quantity for comparison
                        });
                      });
                    } else if (activeStatus === 'live') {
                      // Create item display from PO with 0 quantity only in Live tab
                      itemsToDisplay.push({
                        ...poItem,
                        quantity: 0,
                        amount: 0,
                        poQuantity: poQuantity, // Store PO quantity
                        poItem: true // Mark as PO item without receipt
                      });
                    }
                  });
                } else {
                  // No PO data, use received items as fallback
                  itemsToDisplay.push(...receivedItems);
                }

                const hashString = (str) => {
                  let hash = 0;
                  for (let i = 0; i < str.length; i++) {
                    const char = str.charCodeAt(i);
                    hash = ((hash << 5) - hash) + char;
                    hash = hash & hash; // Convert to 32-bit integer
                  }
                  return Math.abs(hash);
                };

                const getCategoryColor = (category) => {
                  if (!category) return 'bg-[#E3F2FD] text-[#1976D2]';

                  // Define a palette of color combinations
                  const colorPalette = [
                    'bg-[#E3F2FD] text-[#1976D2]', // Light blue
                    'bg-[#E8F5E9] text-[#2E7D32]', // Light green
                    'bg-[#FFF3E0] text-[#F57C00]', // Light orange
                    'bg-[#F3E5F5] text-[#7B1FA2]', // Light purple
                    'bg-[#FCE4EC] text-[#C2185B]', // Light pink
                    'bg-[#E0F2F1] text-[#00695C]', // Light teal
                    'bg-[#FFF9C4] text-[#F57F17]', // Light yellow
                    'bg-[#E1BEE7] text-[#6A1B9A]', // Light lavender
                    'bg-[#FFE0B2] text-[#E65100]', // Light deep orange
                    'bg-[#BBDEFB] text-[#0D47A1]', // Light indigo
                    'bg-[#C8E6C9] text-[#1B5E20]', // Light dark green
                    'bg-[#FFCCBC] text-[#BF360C]', // Light deep orange red
                  ];

                  // Hash the category name to get a consistent index
                  const hash = hashString(category.toLowerCase());
                  const colorIndex = hash % colorPalette.length;

                  return colorPalette[colorIndex];
                };

                // Sort items so that items with quantity 0 appear first
                const sortedItems = [...itemsToDisplay].sort((a, b) => {
                  const quantityA = Math.abs(a.quantity || 0);
                  const quantityB = Math.abs(b.quantity || 0);
                  if (quantityA === 0 && quantityB !== 0) return -1;
                  if (quantityA !== 0 && quantityB === 0) return 1;
                  return 0;
                });

                return sortedItems.map((item, index) => {
                  const itemId = item.item_id || item.itemId || null;
                  const brandId = item.brand_id || item.brandId || null;
                  const modelId = item.model_id || item.modelId || null;
                  const typeId = item.type_id || item.typeId || null;
                  const categoryId = item.category_id || item.categoryId || null;

                  let itemName = item.itemName || item.item_name || '';
                  let brand = item.brandName || item.brand_name || item.brand || '';
                  let model = item.modelName || item.model_name || item.model || '';
                  let type = item.typeName || item.type_name || item.type || '';
                  let category = item.categoryName || item.category_name || item.category || '';

                  // Resolve names from IDs if not available
                  if (!itemName && itemId) {
                    itemName = resolveItemName(itemId);
                  }
                  if (!brand && brandId) {
                    brand = resolveBrandName(brandId);
                  }
                  if (!model && modelId) {
                    model = resolveModelName(modelId);
                  }
                  if (!type && typeId) {
                    type = resolveTypeName(typeId);
                  }
                  if (!category && categoryId) {
                    category = resolveCategoryName(categoryId);
                  }

                  const quantity = Math.abs(item.quantity || 0);
                  const amount = Math.abs(item.amount || 0);
                  const unit = item.unit || '';
                  const poQuantity = item.poQuantity || 0;

                  // Check if quantity matches PO quantity (different if they don't match)
                  const isQuantityDifferent = quantity !== poQuantity;
                  const isQuantityZero = quantity === 0;

                  return (
                    <div key={index} className={`bg-white border rounded-[8px] p-[12px] ${isQuantityZero ? 'border-[#FF6B6B] border-2' : 'border-[#E0E0E0]'}`}>
                      <div className=" ">
                        <div className="flex items-center justify-between">
                          <p className="text-[14px] font-semibold text-black">{itemName}</p>
                          <span className={`text-[10px] font-medium px-[10px] py-[4px] rounded-full ${getCategoryColor(category)}`}>
                            {(category || 'Electricals').toUpperCase()}
                          </span>
                        </div>
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-[12px] font-medium text-gray-600">
                            {model ? `${model}` : ''}
                          </p>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-[12px] font-medium text-gray-600">
                            {brand ? `${brand}` : ''} {type ? `${type}` : ''}
                          </p>
                          <p className="text-[14px] font-semibold text-black">
                            ₹{amount.toLocaleString('en-IN')}
                          </p>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className={`text-[12px] font-medium ${isQuantityDifferent ? 'text-[#FF6B6B]' : 'text-[#BF9853]'}`}>
                            Quantity {quantity}{unit}
                          </p>
                          <p className="text-[14px] font-semibold text-black">
                             ₹{(amount * quantity).toLocaleString('en-IN')}
                          </p>
                          
                        </div>
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        ) : loading ? (
          <div className="flex items-center justify-center py-[32px]">
            <p className="text-gray-500">Loading...</p>
          </div>
        ) : filteredRecords.length === 0 ? (
          <div className="flex items-center justify-center py-[32px]">
            <p className="text-gray-500">
              {activeStatus === 'live'
                ? 'No live incoming records with pending quantities'
                : activeStatus === 'closed'
                  ? 'No closed incoming records'
                  : 'No history records found'}
            </p>
          </div>
        ) : (
          <div className={activeStatus === 'history' ? 'space-y-0' : 'shadow-md'}>
            {filteredRecords.map((record) => {
              const displayDate = activeStatus === 'history'
                ? record.formattedDate
                : (record.latestDate ? new Date(record.latestDate).toLocaleDateString('en-GB', {
                  day: '2-digit',
                  month: '2-digit',
                  year: 'numeric'
                }) : record.formattedDate);

              const displayTime = activeStatus !== 'history' && record.formattedTime
                ? record.formattedTime
                : (record.latestDate ? new Date(record.latestDate).toLocaleTimeString('en-GB', {
                  hour: '2-digit',
                  minute: '2-digit',
                  hour12: true
                }) : '');

              const displayQuantity = activeStatus === 'history'
                ? record.totalQuantity
                : (record.totalMergedQuantity || record.totalQuantity);

              const displayItems = activeStatus === 'history'
                ? record.numberOfItems
                : (record.totalMergedItems || record.numberOfItems);

              if (activeStatus === 'history') {
                // History tab — tap row for detail only (no swipe edit; edit is Live/Closed cards only)
                return (
                  <div
                    key={record.id || record._id || `${record.purchaseNo}_${record.vendorName}_${displayDate}`}
                    className="flex items-center justify-between py-[12px] px-[16px] border-b border-gray-200 cursor-pointer hover:bg-gray-50"
                    onClick={() => {
                      setSelectedRecord(record);
                      setShowDetailView(true);
                    }}
                  >
                    <div className="flex items-center gap-[8px]">
                      <span className="text-[12px] font-semibold text-[#BF9853] -ml-[3px]">
                        #{record.purchaseNo || record.entryNumber}
                      </span>
                      <span className="text-[12px] font-semibold text-black">
                        , {record.vendorName}
                      </span>
                      <span className="text-[12px] text-gray-500 ml-2">
                        {displayDate}
                      </span>
                    </div>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M6 12L10 8L6 4" stroke="#9E9E9E" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                );
              } else {
                // Live and Closed tabs - detailed card format
                const recordId = record.id || record._id || `${record.purchaseNo}_${record.vendorName}`;
                const isSelected = activeStatus === 'live' && selectedLiveCardId === recordId;
                const supportsSwipeEdit = activeStatus === 'closed' || activeStatus === 'live';
                const isClickable = activeStatus === 'live';
                const swipeState = swipeStates[recordId];
                const isExpanded = expandedClosedCardId === recordId;
                let swipeOffset = 0;
                if (supportsSwipeEdit && swipeState && swipeState.isSwiping) {
                  const deltaX = swipeState.currentX - swipeState.startX;
                  swipeOffset = Math.max(-48, Math.min(0, deltaX));
                } else if (supportsSwipeEdit && isExpanded) {
                  swipeOffset = -48;
                }
                return (
                  <div key={recordId}>
                    <div className="relative overflow-hidden shadow-lg border border-[#E0E0E0] border-opacity-30 bg-[#F8F8F8] rounded-[8px] min-w-[330px]">
                      {supportsSwipeEdit && (
                        <div
                          className="absolute right-0 top-[0px] flex gap-[8px] flex-shrink-0 z-20"
                          style={{
                            opacity: isExpanded || (swipeState && swipeState.isSwiping && swipeOffset < -20) ? 1 : 0,
                            transform: swipeOffset < 0
                              ? `translateX(${Math.max(0, 48 + swipeOffset)}px)`
                              : 'translateX(48px)',
                            transition: (swipeState && swipeState.isSwiping) ? 'none' : 'opacity 0.2s ease-out, transform 0.3s ease-out',
                            pointerEvents:
                              isExpanded || (swipeState && swipeState.isSwiping && swipeOffset <= -18)
                                ? 'auto'
                                : 'none'
                          }}
                        >
                          <button
                            type="button"
                            disabled={!canEdit}
                            className={`action-button w-[48px] h-[95px] bg-[#007233] rounded-[6px] flex items-center justify-center gap-[6px] hover:bg-[#22a882] transition-colors shadow-sm ${!canEdit ? 'opacity-50 cursor-not-allowed hover:bg-[#007233]' : ''}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (canEdit) handleEditIncomingRecord(record);
                            }}
                            onMouseDown={(e) => e.stopPropagation()}
                            title="Edit"
                          >
                            <img src={Edit} alt="Edit" className="w-[18px] h-[18px]" />
                          </button>
                        </div>
                      )}
                      <div
                        ref={(el) => {
                          if (!supportsSwipeEdit) return;
                          if (el) trackerCardRefs.current[recordId] = el;
                          else delete trackerCardRefs.current[recordId];
                        }}
                        className={`bg-white rounded-lg px-[12px] py-[12px] relative z-10 flex flex-col transition-all duration-300 ease-out select-none ${isClickable ? 'cursor-pointer hover:bg-gray-50' : ''} ${isSelected ? 'border-[#007233]' : 'border-gray-200'}`}
                        style={{
                          ...(isSelected ? { borderWidth: '1px', borderColor: '#007233' } : {}),
                          ...(supportsSwipeEdit ? {
                            transform: `translateX(${swipeOffset}px)`,
                            transition: (swipeState && swipeState.isSwiping) ? 'none' : 'transform 0.3s ease-out',
                            touchAction: 'pan-y',
                            userSelect: (swipeState && swipeState.isSwiping) ? 'none' : 'auto',
                            WebkitUserSelect: (swipeState && swipeState.isSwiping) ? 'none' : 'auto',
                            MozUserSelect: (swipeState && swipeState.isSwiping) ? 'none' : 'auto',
                            msUserSelect: (swipeState && swipeState.isSwiping) ? 'none' : 'auto'
                          } : {})
                        }}
                        onClick={isClickable ? () => {
                          if (suppressLiveCardClickRef.current) {
                            suppressLiveCardClickRef.current = false;
                            return;
                          }
                          if (selectedLiveCardId === recordId) {
                            setSelectedLiveCardId(null);
                          } else {
                            setSelectedLiveCardId(recordId);
                          }
                        } : undefined}
                        onPointerDown={supportsSwipeEdit ? (e) => handlePointerDown(e, recordId) : undefined}
                        onPointerMove={supportsSwipeEdit ? handlePointerMove : undefined}
                        onPointerUp={supportsSwipeEdit ? handlePointerUpOrCancel : undefined}
                        onPointerCancel={supportsSwipeEdit ? handlePointerUpOrCancel : undefined}
                      >
                        {/* Green Checkmark Icon - Top Left */}
                        {isSelected && (
                          <div className="absolute top-[0px] left-[-1px]">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <circle cx="10" cy="10" r="10" fill="#007233" />
                              <path d="M6 10L9 13L14 7" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                          </div>
                        )}
                        <div className="flex flex-col gap-[2px]">
                          <div className="flex items-start justify-between mb-[2px]">
                            <div className="flex-1 min-w-0">
                              <div
                                className="flex items-center gap-[8px] cursor-pointer hover:opacity-80"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedRecord(record);
                                  setShowDetailView(true);
                                }}
                              >
                                <span className="text-[12px] font-semibold text-black leading-snug">
                                  #{record.purchaseNo || record.entryNumber}
                                </span>
                                <span className="text-[12px] font-semibold text-black leading-snug">
                                  , {record.vendorName}
                                </span>
                              </div>
                            </div>
                            <div className="flex flex-col items-end flex-shrink-0 ml-2">
                              <p className="text-[11px] font-medium text-gray-600 leading-snug">
                                No. of Items - {displayItems}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-start justify-between mb-[2px]">
                            <p className="text-[12px] text-gray-600 leading-snug mb-0.5 break-words flex-1 min-w-0">
                              {record.stockingLocation}
                            </p>
                            <div className="flex-shrink-0 ml-2" />
                          </div>

                          <div className="flex items-start justify-between">
                            <p className="text-[11px] font-medium text-[#777777] leading-snug break-words flex-1 min-w-0">
                              {record.created_date_time && new Date(record.created_date_time).toLocaleString('en-GB', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: true
                              })}
                            </p>
                            <p className="text-[12px] font-semibold text-[#BF9853] leading-snug flex-shrink-0 ml-2">
                              Quantity - {displayQuantity}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )
              }
            })}
          </div>
        )}
      </div>
      {/* Close PO Button - Above bottom footer */}
      {!showDetailView && activeStatus === 'live' && selectedLiveCardId && (
        <div className="flex-shrink-0 flex justify-end py-[12px]">
          <button
            type="button"
            onClick={async () => {
              const selectedRecord = filteredRecords.find(record => {
                const recordId = record.id || record._id || `${record.purchaseNo}_${record.vendorName}`;
                return recordId === selectedLiveCardId;
              });
              if (selectedRecord) {
                const entriesToClose = selectedRecord.mergedEntries || [selectedRecord];
                const purchaseNo = selectedRecord.purchaseNo || selectedRecord.purchase_no || '';
                const vendorId = selectedRecord.vendor_id || selectedRecord.vendorId || 0;
                const closedBy = (user && user.username) || '';
                const timestamp = new Date().toISOString();
                try {
                  // Close all entries
                  const closePromises = entriesToClose.map(async (entry) => {
                    const recordIdToClose = entry.id || entry._id;
                    if (recordIdToClose) {
                      const response = await fetch(`https://backendaab.in/demoAabuildersDash/api/inventory/close_po/${recordIdToClose}?poClosedStatus=true`, {
                        method: 'PUT',
                        credentials: 'include',
                        headers: {
                          'Content-Type': 'application/json'
                        }
                      });
                      return response.ok;
                    }
                    return false;
                  });
                  await Promise.all(closePromises);
                  // Save to ClosedPORecords (only once per purchase_no)
                  if (purchaseNo) {
                    if (canCreate) {
                      try {
                        await fetch('https://backendaab.in/demoAabuildersDash/api/closed_po_records/save', {
                          method: 'POST',
                          credentials: 'include',
                          headers: {
                            'Content-Type': 'application/json'
                          },
                          body: JSON.stringify({
                            purchase_no: purchaseNo,
                            vendor_id: vendorId,
                            closed_by: closedBy,
                            timestamp: timestamp
                          })
                        });
                      } catch (error) {
                        console.error('Error saving closed PO record:', error);
                        // Don't fail the whole operation if this fails
                      }
                    } else {
                      console.warn('Skipping closed_po_records/save - user lacks Create permission');
                    }
                  }
                  // Refresh data once after all closes
                  setLoading(true);
                  const response = await fetch(getIncomingEndpointByStatus(activeStatus), {
                    method: 'GET',
                    credentials: 'include',
                    headers: {
                      'Content-Type': 'application/json'
                    }
                  });
                  if (response.ok) {
                    const inventoryData = await response.json();
                    const apiVendorId = resolveVendorIdForIncomingApi();
                    const useLiveClosedApi = (activeStatus === 'live' || activeStatus === 'closed') &&
                      apiVendorId !== null &&
                      apiVendorId !== undefined &&
                      String(apiVendorId).trim() !== '';
                    const processedRecords = await Promise.all(
                      inventoryData
                        .filter(record => {
                          const recordPurchaseNo = record.purchase_no || record.purchaseNo || record.purchase_number || '';
                          const purchaseNoStr = String(recordPurchaseNo).trim();
                          return purchaseNoStr !== '' &&
                            purchaseNoStr.toUpperCase() !== 'NO_PO' &&
                            purchaseNoStr.toLowerCase() !== 'non po';
                        })
                        .map(async (record) => {
                          const purchaseNo = record.purchase_no || record.purchaseNo || record.purchase_number || '';
                          const poNumberStr = String(purchaseNo).replace('#', '').trim();
                          let hasBalance;
                          if (!useLiveClosedApi) {
                            let poData = null;
                            if (poNumberStr && allPurchaseOrders.length > 0) {
                              const targetEno = getNumericEno(poNumberStr);
                              const vendorId = record.vendor_id || record.vendorId;
                              const vendorPOs = vendorId
                                ? allPurchaseOrders.filter(p => String(p.vendor_id || p.vendorId) === String(vendorId))
                                : allPurchaseOrders;
                              const matchingPOs = vendorPOs.filter(p => {
                                const poEno = getNumericEno(p.eno || p.ENO || p.poNumber || p.po_number || '');
                                return poEno === targetEno && poEno !== 0;
                              });
                              if (matchingPOs.length > 0) {
                                const posWithItems = matchingPOs.filter(p => {
                                  const items = p.purchaseTable || p.purchase_table || p.items || [];
                                  return items.length > 0;
                                });
                                if (posWithItems.length > 0) {
                                  poData = posWithItems.reduce((latest, current) => {
                                    const latestId = parseInt(latest.id || latest._id || 0);
                                    const currentId = parseInt(current.id || current._id || 0);
                                    return currentId > latestId ? current : latest;
                                  });
                                } else if (matchingPOs.length > 0) {
                                  poData = matchingPOs.reduce((latest, current) => {
                                    const latestId = parseInt(latest.id || latest._id || 0);
                                    const currentId = parseInt(current.id || current._id || 0);
                                    return currentId > latestId ? current : latest;
                                  });
                                }
                              }
                            }

                            hasBalance = checkBalanceQuantity(record, poData);
                          }
                          const vendorId = record.vendor_id || record.vendorId;
                          const vendor = vendorData.find(v => v.id === vendorId);
                          const vendorName = vendor ? vendor.vendorName : 'Unknown Vendor';
                          const stockingLocationId = record.stocking_location_id || record.stockingLocationId;
                          const site = siteData.find(s => s.id === stockingLocationId);
                          const stockingLocation = site ? site.siteName : 'Unknown Location';
                          const inventoryItems = record.inventoryItems || record.inventory_items || [];
                          const numberOfItems = inventoryItems.length;
                          const totalQuantity = inventoryItems.reduce((sum, item) => {
                            return sum + Math.abs(item.quantity || 0);
                          }, 0);
                          const totalAmount = inventoryItems.reduce((sum, item) => {
                            return sum + Math.abs(item.amount || 0);
                          }, 0);
                          const itemDate = record.date || record.created_at || record.createdAt;
                          const dateObj = new Date(itemDate);
                          const formattedDate = dateObj.toLocaleDateString('en-GB', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric'
                          });
                          const formattedTime = dateObj.toLocaleTimeString('en-GB', {
                            hour: '2-digit',
                            minute: '2-digit',
                            hour12: true
                          });
                          const entryNumber = record.eno || record.ENO || record.entry_number || record.entryNumber || record.id || '';
                          const poClosedStatus = record.po_closed_status || record.poClosedStatus || false;
                          return {
                            ...record,
                            entryNumber,
                            purchaseNo,
                            vendorName,
                            stockingLocation,
                            numberOfItems,
                            totalQuantity,
                            totalAmount,
                            formattedDate,
                            formattedTime,
                            hasBalance,
                            poClosedStatus,
                            isToday: formattedDate === new Date().toLocaleDateString('en-GB', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric'
                            })
                          };
                        })
                    );
                    setIncomingRecords(processedRecords);
                    setSelectedLiveCardId(null);
                  }
                } catch (error) {
                  console.error('Error closing PO:', error);
                } finally {
                  setLoading(false);
                }
              }
            }}
            className="w-[100px] bg-black text-white py-[12px] rounded-full text-[14px] font-medium"
          >
            Close PO
          </button>
        </div>
      )}
      {/* Filter Modal */}
      {showFilterModal && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-[100] flex items-end justify-center"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setShowFilterModal(false);
              setShowVendorDropdown(false);
              setShowLocationDropdown(false);
            }
          }}
        >
          <div
            className="bg-white w-full h-[240px] rounded-t-3xl shadow-lg"
            style={{ maxHeight: '60vh' }}
            onClick={(e) => e.stopPropagation()} >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-[24px] pt-[16px] pb-3 border-b border-[rgba(0,0,0,0.08)] flex-shrink-0">
              <h2 className="text-[16px] font-semibold text-black">Select Filters</h2>
              <button
                type="button"
                onClick={() => {
                  setShowFilterModal(false);
                  setShowVendorDropdown(false);
                  setShowLocationDropdown(false);
                }}
                className="text-red-500 hover:text-red-700"
              >
                <img src={Close} alt="Close" className="w-[11px] h-[11px]" />
              </button>
            </div>
            {/* Modal Content */}
            <div className="flex-1 overflow-y-auto px-[24px] py-3">
              {/* Vendor Name */}
              <div className="space-y-[6px]">
                <div className="relative">
                  <label className="block text-[13px] font-medium text-black mb-0.5">Vendor Name</label>
                  <SearchableDropdown
                    value={filterVendorName}
                    onChange={(value) => {
                      setFilterVendorName(value);
                      setShowVendorDropdown(false);
                      setShowLocationDropdown(false);
                    }}
                    options={vendorData.map((v) => v.vendorName || v.name || '').filter(Boolean)}
                    placeholder="Select"
                    fieldName="Vendor Name"
                    showAddNew={false}
                    showAllOptions={true}
                  />
                </div>
                {/* Stocking Location */}
                <div className="relative flex items-center gap-[12px]">
                  <div className="flex-1 min-w-0">
                    <label className="text-[13px] font-medium text-black mb-0.5">Stocking Location</label>
                    <SearchableDropdown
                      value={filterStockingLocation}
                      onChange={(value) => {
                        setFilterStockingLocation(value);
                        setShowVendorDropdown(false);
                        setShowLocationDropdown(false);
                      }}
                      options={siteData.map((s) => s.siteName || s.name || '').filter(Boolean)}
                      placeholder="Select"
                      fieldName="Stocking Location"
                      showAddNew={false}
                      showAllOptions={true}
                    />
                  </div>
                  {/* PO. No */}
                  <div className="relative flex-1 min-w-0">
                    <label className="block text-[13px] font-medium text-black mb-0.5">PO. No</label>
                    <SearchableDropdown
                      value={filterPONo}
                      onChange={(value) => {
                        setFilterPONo(String(value).replace('#', ''));
                        setShowVendorDropdown(false);
                        setShowLocationDropdown(false);
                      }}
                      options={Array.from(new Set(incomingRecords.map(r => r.purchaseNo || r.entryNumber).filter(Boolean))).map((poNo) => String(poNo).replace('#', ''))}
                      placeholder="Enter"
                      fieldName="PO. No"
                      showAddNew={false}
                      showAllOptions={true}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      <SelectVendorModal
        isOpen={showCategoryModal}
        onClose={() => setShowCategoryModal(false)}
        onSelect={(value) => {
          setFilterCategory(value);
          setShowCategoryModal(false);
        }}
        selectedValue={filterCategory}
        options={Array.from(new Set(categoryOptions.map((c) => c.value || c.label || '').filter(Boolean)))}
        fieldName="Category"
        showStarIcon={false}
      />
      <DatePickerModal
        isOpen={showDatePicker}
        onClose={() => setShowDatePicker(false)}
        initialDate={filterDate}
        onConfirm={(picked) => {
          setFilterDate(picked);
          setShowDatePicker(false);
        }}
      />
    </div>
  );
};
export default IncomingTracker;